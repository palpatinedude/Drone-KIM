#ifndef __c1_flightControlSystem_h__
#define __c1_flightControlSystem_h__

/* Forward Declarations */
#ifndef c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG
#define c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG

typedef struct c1_tag_sGaAmWJmK5HvPUvd2k3PkCG c1_sGaAmWJmK5HvPUvd2k3PkCG;

#endif                                 /* c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH
#define c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH

typedef struct c1_tag_skA4KFEZ4HPkJJBOYCrevdH c1_skA4KFEZ4HPkJJBOYCrevdH;

#endif                                 /* c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH */

#ifndef c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE
#define c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE

typedef struct c1_tag_sG4eiVjMQ0O8d9Qp49KylpE c1_sG4eiVjMQ0O8d9Qp49KylpE;

#endif                                 /* c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE */

#ifndef c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F
#define c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F

typedef struct c1_tag_smzGQHcQ1fZcSCW5rtLpn4F c1_smzGQHcQ1fZcSCW5rtLpn4F;

#endif                                 /* c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC
#define c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC

typedef struct c1_tag_sKGJXMD9VfgqCU44Gm9fvGC c1_sKGJXMD9VfgqCU44Gm9fvGC;

#endif                                 /* c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC */

#ifndef c1_typedef_c1_cell_0
#define c1_typedef_c1_cell_0

typedef struct c1_tag_wFA83RKAeigZpPO9RtFl3E c1_cell_0;

#endif                                 /* c1_typedef_c1_cell_0 */

#ifndef c1_typedef_c1_cell_1
#define c1_typedef_c1_cell_1

typedef struct c1_tag_yMC1lSkUnB6oeajoT9xJQ c1_cell_1;

#endif                                 /* c1_typedef_c1_cell_1 */

#ifndef c1_typedef_c1_cell_wrap_2
#define c1_typedef_c1_cell_wrap_2

typedef struct c1_tag_QUrJGLT4DsCLhnuPIs5e8F c1_cell_wrap_2;

#endif                                 /* c1_typedef_c1_cell_wrap_2 */

#ifndef c1_typedef_c1_cell_wrap_4
#define c1_typedef_c1_cell_wrap_4

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_4;

#endif                                 /* c1_typedef_c1_cell_wrap_4 */

#ifndef c1_typedef_c1_cell_wrap_3
#define c1_typedef_c1_cell_wrap_3

typedef struct c1_tag_6jR4RtbHdjyG00WYqgD5nF c1_cell_wrap_3;

#endif                                 /* c1_typedef_c1_cell_wrap_3 */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_njgfiHhWBCqqqpWsKZxr7F c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_typedef_c1_cell_7
#define c1_typedef_c1_cell_7

typedef struct c1_tag_vCroJ4nSCwjPwQBS7RhjeC c1_cell_7;

#endif                                 /* c1_typedef_c1_cell_7 */

#ifndef c1_typedef_c1_cell_8
#define c1_typedef_c1_cell_8

typedef struct c1_tag_FWAx9YmgCYqLkaFiyAr9e c1_cell_8;

#endif                                 /* c1_typedef_c1_cell_8 */

#ifndef c1_typedef_c1_rtString_1
#define c1_typedef_c1_rtString_1

typedef struct c1_tag_f0FJd1n2NNMv9YVafSuVeE c1_rtString_1;

#endif                                 /* c1_typedef_c1_rtString_1 */

#ifndef c1_typedef_c1_b_rtString_1
#define c1_typedef_c1_b_rtString_1

typedef struct c1_tag_fxrtQpZcildDTGvn3QeHJH c1_b_rtString_1;

#endif                                 /* c1_typedef_c1_b_rtString_1 */

#ifndef c1_typedef_c1_rtString_3
#define c1_typedef_c1_rtString_3

typedef struct c1_tag_IxcxAQynSj3lj3aD5ZhcOB c1_rtString_3;

#endif                                 /* c1_typedef_c1_rtString_3 */

#ifndef c1_typedef_c1_b_rtString_3
#define c1_typedef_c1_b_rtString_3

typedef struct c1_tag_J08upOd3Kq88GzikYAcy5D c1_b_rtString_3;

#endif                                 /* c1_typedef_c1_b_rtString_3 */

#ifndef c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD
#define c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD

typedef struct c1_tag_tw11suyEaFwu2LBMIAhmwD c1_s_tw11suyEaFwu2LBMIAhmwD;

#endif                                 /* c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD */

#ifndef c1_typedef_c1_cell_wrap_10
#define c1_typedef_c1_cell_wrap_10

typedef struct c1_tag_425jfUs7oa9tknWqXmaAC c1_cell_wrap_10;

#endif                                 /* c1_typedef_c1_cell_wrap_10 */

#ifndef c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_typedef_c1_cell_11
#define c1_typedef_c1_cell_11

typedef struct c1_tag_yMfj6323Zqv19VFnWGoHjH c1_cell_11;

#endif                                 /* c1_typedef_c1_cell_11 */

#ifndef c1_typedef_c1_rtString
#define c1_typedef_c1_rtString

typedef struct c1_tag_QOv9lUObtGr5VOJHSjWYHE c1_rtString;

#endif                                 /* c1_typedef_c1_rtString */

#ifndef c1_typedef_c1_rtString_2
#define c1_typedef_c1_rtString_2

typedef struct c1_tag_2Z7wBlxjO7amAEeUUaGPcG c1_rtString_2;

#endif                                 /* c1_typedef_c1_rtString_2 */

#ifndef c1_typedef_c1_c_rtString_1
#define c1_typedef_c1_c_rtString_1

typedef struct c1_tag_AUQiMqLxBjYJC2klX95aiG c1_c_rtString_1;

#endif                                 /* c1_typedef_c1_c_rtString_1 */

#ifndef c1_typedef_c1_c_rtString_3
#define c1_typedef_c1_c_rtString_3

typedef struct c1_tag_lKQV0Lroo9ddhTRqEONsXH c1_c_rtString_3;

#endif                                 /* c1_typedef_c1_c_rtString_3 */

#ifndef c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH
#define c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH

typedef struct c1_tag_jdcdw0PiMBCTdeBOpodFZH c1_s_jdcdw0PiMBCTdeBOpodFZH;

#endif                                 /* c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH */

#ifndef c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa
#define c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa

typedef struct c1_tag_7kqyh9yPSX1r9g9o63IGa c1_s_7kqyh9yPSX1r9g9o63IGa;

#endif                                 /* c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa */

#ifndef c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD
#define c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD

typedef struct c1_tag_rs0J7tUaO8r8RV5HCYwLTD c1_s_rs0J7tUaO8r8RV5HCYwLTD;

#endif                                 /* c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD */

#ifndef c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD
#define c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD

typedef struct c1_tag_PziPEzZoKKixmpD5T9qTcD c1_s_PziPEzZoKKixmpD5T9qTcD;

#endif                                 /* c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD
#define c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD

typedef struct c1_tag_1nlLkVeIuST25DF6il3ApD c1_s_1nlLkVeIuST25DF6il3ApD;

#endif                                 /* c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD */

#ifndef c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF
#define c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF

typedef struct c1_tag_uzuPWHtc1cM7ZRTfbsKeiF c1_s_uzuPWHtc1cM7ZRTfbsKeiF;

#endif                                 /* c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL
#define c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL

typedef struct c1_tag_qRxSe9N4qwJIjT7M2BxNL c1_s_qRxSe9N4qwJIjT7M2BxNL;

#endif                                 /* c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL */

#ifndef c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH
#define c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH

typedef struct c1_tag_4dijvwFFQt8JouTajf5bDH c1_s_4dijvwFFQt8JouTajf5bDH;

#endif                                 /* c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH */

#ifndef c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG
#define c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG

typedef struct c1_tag_3krQGJUZiHCKKXkfwgRDoG c1_s_3krQGJUZiHCKKXkfwgRDoG;

#endif                                 /* c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG */

#ifndef c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF
#define c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF

typedef struct c1_tag_lv60kHidgCVN68cHDjBCkF c1_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF */

/* Type Definitions */
#ifndef c1_struct_c1_tag_sGaAmWJmK5HvPUvd2k3PkCG
#define c1_struct_c1_tag_sGaAmWJmK5HvPUvd2k3PkCG

struct c1_tag_sGaAmWJmK5HvPUvd2k3PkCG
{
  uint32_T nanflag;
  uint32_T ComparisonMethod;
};

#endif                                 /* c1_struct_c1_tag_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG
#define c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG

typedef struct c1_tag_sGaAmWJmK5HvPUvd2k3PkCG c1_sGaAmWJmK5HvPUvd2k3PkCG;

#endif                                 /* c1_typedef_c1_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c1_struct_c1_tag_skA4KFEZ4HPkJJBOYCrevdH
#define c1_struct_c1_tag_skA4KFEZ4HPkJJBOYCrevdH

struct c1_tag_skA4KFEZ4HPkJJBOYCrevdH
{
  uint32_T SafeEq;
  uint32_T Absolute;
  uint32_T NaNBias;
  uint32_T NaNWithFinite;
  uint32_T FiniteWithNaN;
  uint32_T NaNWithNaN;
};

#endif                                 /* c1_struct_c1_tag_skA4KFEZ4HPkJJBOYCrevdH */

#ifndef c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH
#define c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH

typedef struct c1_tag_skA4KFEZ4HPkJJBOYCrevdH c1_skA4KFEZ4HPkJJBOYCrevdH;

#endif                                 /* c1_typedef_c1_skA4KFEZ4HPkJJBOYCrevdH */

#ifndef c1_struct_c1_tag_sG4eiVjMQ0O8d9Qp49KylpE
#define c1_struct_c1_tag_sG4eiVjMQ0O8d9Qp49KylpE

struct c1_tag_sG4eiVjMQ0O8d9Qp49KylpE
{
  char_T op[3];
};

#endif                                 /* c1_struct_c1_tag_sG4eiVjMQ0O8d9Qp49KylpE */

#ifndef c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE
#define c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE

typedef struct c1_tag_sG4eiVjMQ0O8d9Qp49KylpE c1_sG4eiVjMQ0O8d9Qp49KylpE;

#endif                                 /* c1_typedef_c1_sG4eiVjMQ0O8d9Qp49KylpE */

#ifndef c1_struct_c1_tag_smzGQHcQ1fZcSCW5rtLpn4F
#define c1_struct_c1_tag_smzGQHcQ1fZcSCW5rtLpn4F

struct c1_tag_smzGQHcQ1fZcSCW5rtLpn4F
{
  boolean_T CaseSensitivity;
  char_T PartialMatching[6];
  boolean_T StructExpand;
  boolean_T IgnoreNulls;
  boolean_T SupportOverrides;
};

#endif                                 /* c1_struct_c1_tag_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F
#define c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F

typedef struct c1_tag_smzGQHcQ1fZcSCW5rtLpn4F c1_smzGQHcQ1fZcSCW5rtLpn4F;

#endif                                 /* c1_typedef_c1_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c1_struct_c1_tag_sKGJXMD9VfgqCU44Gm9fvGC
#define c1_struct_c1_tag_sKGJXMD9VfgqCU44Gm9fvGC

struct c1_tag_sKGJXMD9VfgqCU44Gm9fvGC
{
  boolean_T CaseSensitivity;
  boolean_T StructExpand;
  char_T PartialMatching[6];
  boolean_T IgnoreNulls;
};

#endif                                 /* c1_struct_c1_tag_sKGJXMD9VfgqCU44Gm9fvGC */

#ifndef c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC
#define c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC

typedef struct c1_tag_sKGJXMD9VfgqCU44Gm9fvGC c1_sKGJXMD9VfgqCU44Gm9fvGC;

#endif                                 /* c1_typedef_c1_sKGJXMD9VfgqCU44Gm9fvGC */

#ifndef c1_struct_c1_tag_wFA83RKAeigZpPO9RtFl3E
#define c1_struct_c1_tag_wFA83RKAeigZpPO9RtFl3E

struct c1_tag_wFA83RKAeigZpPO9RtFl3E
{
  char_T f1[6];
  char_T f2[6];
  char_T f3[4];
  char_T f4[5];
  char_T f5[5];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* c1_struct_c1_tag_wFA83RKAeigZpPO9RtFl3E */

#ifndef c1_typedef_c1_cell_0
#define c1_typedef_c1_cell_0

typedef struct c1_tag_wFA83RKAeigZpPO9RtFl3E c1_cell_0;

#endif                                 /* c1_typedef_c1_cell_0 */

#ifndef c1_struct_c1_tag_yMC1lSkUnB6oeajoT9xJQ
#define c1_struct_c1_tag_yMC1lSkUnB6oeajoT9xJQ

struct c1_tag_yMC1lSkUnB6oeajoT9xJQ
{
  char_T f1[4];
  char_T f2[9];
};

#endif                                 /* c1_struct_c1_tag_yMC1lSkUnB6oeajoT9xJQ */

#ifndef c1_typedef_c1_cell_1
#define c1_typedef_c1_cell_1

typedef struct c1_tag_yMC1lSkUnB6oeajoT9xJQ c1_cell_1;

#endif                                 /* c1_typedef_c1_cell_1 */

#ifndef c1_struct_c1_tag_QUrJGLT4DsCLhnuPIs5e8F
#define c1_struct_c1_tag_QUrJGLT4DsCLhnuPIs5e8F

struct c1_tag_QUrJGLT4DsCLhnuPIs5e8F
{
  char_T f1[2];
};

#endif                                 /* c1_struct_c1_tag_QUrJGLT4DsCLhnuPIs5e8F */

#ifndef c1_typedef_c1_cell_wrap_2
#define c1_typedef_c1_cell_wrap_2

typedef struct c1_tag_QUrJGLT4DsCLhnuPIs5e8F c1_cell_wrap_2;

#endif                                 /* c1_typedef_c1_cell_wrap_2 */

#ifndef c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB
#define c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB

struct c1_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef c1_typedef_c1_cell_wrap_4
#define c1_typedef_c1_cell_wrap_4

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_4;

#endif                                 /* c1_typedef_c1_cell_wrap_4 */

#ifndef c1_struct_c1_tag_6jR4RtbHdjyG00WYqgD5nF
#define c1_struct_c1_tag_6jR4RtbHdjyG00WYqgD5nF

struct c1_tag_6jR4RtbHdjyG00WYqgD5nF
{
  char_T f1[16];
};

#endif                                 /* c1_struct_c1_tag_6jR4RtbHdjyG00WYqgD5nF */

#ifndef c1_typedef_c1_cell_wrap_3
#define c1_typedef_c1_cell_wrap_3

typedef struct c1_tag_6jR4RtbHdjyG00WYqgD5nF c1_cell_wrap_3;

#endif                                 /* c1_typedef_c1_cell_wrap_3 */

#ifndef c1_struct_c1_tag_njgfiHhWBCqqqpWsKZxr7F
#define c1_struct_c1_tag_njgfiHhWBCqqqpWsKZxr7F

struct c1_tag_njgfiHhWBCqqqpWsKZxr7F
{
  char_T f1[15];
  char_T f2[15];
  char_T f3[12];
  char_T f4[11];
  char_T f5[16];
};

#endif                                 /* c1_struct_c1_tag_njgfiHhWBCqqqpWsKZxr7F */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_njgfiHhWBCqqqpWsKZxr7F c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_struct_c1_tag_vCroJ4nSCwjPwQBS7RhjeC
#define c1_struct_c1_tag_vCroJ4nSCwjPwQBS7RhjeC

struct c1_tag_vCroJ4nSCwjPwQBS7RhjeC
{
  char_T f1[6];
  char_T f2[8];
  char_T f3[7];
  char_T f4[13];
  char_T f5[13];
  char_T f6[10];
};

#endif                                 /* c1_struct_c1_tag_vCroJ4nSCwjPwQBS7RhjeC */

#ifndef c1_typedef_c1_cell_7
#define c1_typedef_c1_cell_7

typedef struct c1_tag_vCroJ4nSCwjPwQBS7RhjeC c1_cell_7;

#endif                                 /* c1_typedef_c1_cell_7 */

#ifndef c1_struct_c1_tag_FWAx9YmgCYqLkaFiyAr9e
#define c1_struct_c1_tag_FWAx9YmgCYqLkaFiyAr9e

struct c1_tag_FWAx9YmgCYqLkaFiyAr9e
{
  char_T f1[15];
  char_T f2[12];
  char_T f3[15];
  char_T f4[11];
};

#endif                                 /* c1_struct_c1_tag_FWAx9YmgCYqLkaFiyAr9e */

#ifndef c1_typedef_c1_cell_8
#define c1_typedef_c1_cell_8

typedef struct c1_tag_FWAx9YmgCYqLkaFiyAr9e c1_cell_8;

#endif                                 /* c1_typedef_c1_cell_8 */

#ifndef c1_struct_c1_tag_f0FJd1n2NNMv9YVafSuVeE
#define c1_struct_c1_tag_f0FJd1n2NNMv9YVafSuVeE

struct c1_tag_f0FJd1n2NNMv9YVafSuVeE
{
  char_T Value[7];
};

#endif                                 /* c1_struct_c1_tag_f0FJd1n2NNMv9YVafSuVeE */

#ifndef c1_typedef_c1_rtString_1
#define c1_typedef_c1_rtString_1

typedef struct c1_tag_f0FJd1n2NNMv9YVafSuVeE c1_rtString_1;

#endif                                 /* c1_typedef_c1_rtString_1 */

#ifndef c1_struct_c1_tag_fxrtQpZcildDTGvn3QeHJH
#define c1_struct_c1_tag_fxrtQpZcildDTGvn3QeHJH

struct c1_tag_fxrtQpZcildDTGvn3QeHJH
{
  char_T Value[7];
};

#endif                                 /* c1_struct_c1_tag_fxrtQpZcildDTGvn3QeHJH */

#ifndef c1_typedef_c1_b_rtString_1
#define c1_typedef_c1_b_rtString_1

typedef struct c1_tag_fxrtQpZcildDTGvn3QeHJH c1_b_rtString_1;

#endif                                 /* c1_typedef_c1_b_rtString_1 */

#ifndef c1_struct_c1_tag_IxcxAQynSj3lj3aD5ZhcOB
#define c1_struct_c1_tag_IxcxAQynSj3lj3aD5ZhcOB

struct c1_tag_IxcxAQynSj3lj3aD5ZhcOB
{
  char_T Value[8];
};

#endif                                 /* c1_struct_c1_tag_IxcxAQynSj3lj3aD5ZhcOB */

#ifndef c1_typedef_c1_rtString_3
#define c1_typedef_c1_rtString_3

typedef struct c1_tag_IxcxAQynSj3lj3aD5ZhcOB c1_rtString_3;

#endif                                 /* c1_typedef_c1_rtString_3 */

#ifndef c1_struct_c1_tag_J08upOd3Kq88GzikYAcy5D
#define c1_struct_c1_tag_J08upOd3Kq88GzikYAcy5D

struct c1_tag_J08upOd3Kq88GzikYAcy5D
{
  char_T Value[8];
};

#endif                                 /* c1_struct_c1_tag_J08upOd3Kq88GzikYAcy5D */

#ifndef c1_typedef_c1_b_rtString_3
#define c1_typedef_c1_b_rtString_3

typedef struct c1_tag_J08upOd3Kq88GzikYAcy5D c1_b_rtString_3;

#endif                                 /* c1_typedef_c1_b_rtString_3 */

#ifndef c1_struct_c1_tag_tw11suyEaFwu2LBMIAhmwD
#define c1_struct_c1_tag_tw11suyEaFwu2LBMIAhmwD

struct c1_tag_tw11suyEaFwu2LBMIAhmwD
{
  char_T Value[3];
};

#endif                                 /* c1_struct_c1_tag_tw11suyEaFwu2LBMIAhmwD */

#ifndef c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD
#define c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD

typedef struct c1_tag_tw11suyEaFwu2LBMIAhmwD c1_s_tw11suyEaFwu2LBMIAhmwD;

#endif                                 /* c1_typedef_c1_s_tw11suyEaFwu2LBMIAhmwD */

#ifndef c1_struct_c1_tag_425jfUs7oa9tknWqXmaAC
#define c1_struct_c1_tag_425jfUs7oa9tknWqXmaAC

struct c1_tag_425jfUs7oa9tknWqXmaAC
{
  real_T f1[9];
};

#endif                                 /* c1_struct_c1_tag_425jfUs7oa9tknWqXmaAC */

#ifndef c1_typedef_c1_cell_wrap_10
#define c1_typedef_c1_cell_wrap_10

typedef struct c1_tag_425jfUs7oa9tknWqXmaAC c1_cell_wrap_10;

#endif                                 /* c1_typedef_c1_cell_wrap_10 */

#ifndef c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG
#define c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG

struct c1_tag_a7TcNrdk5JZcy5uxGijaRG
{
  char_T f1[7];
  char_T f2[7];
};

#endif                                 /* c1_struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c1_typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c1_struct_c1_tag_yMfj6323Zqv19VFnWGoHjH
#define c1_struct_c1_tag_yMfj6323Zqv19VFnWGoHjH

struct c1_tag_yMfj6323Zqv19VFnWGoHjH
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[6];
};

#endif                                 /* c1_struct_c1_tag_yMfj6323Zqv19VFnWGoHjH */

#ifndef c1_typedef_c1_cell_11
#define c1_typedef_c1_cell_11

typedef struct c1_tag_yMfj6323Zqv19VFnWGoHjH c1_cell_11;

#endif                                 /* c1_typedef_c1_cell_11 */

#ifndef c1_struct_c1_tag_QOv9lUObtGr5VOJHSjWYHE
#define c1_struct_c1_tag_QOv9lUObtGr5VOJHSjWYHE

struct c1_tag_QOv9lUObtGr5VOJHSjWYHE
{
  char_T Value[7];
};

#endif                                 /* c1_struct_c1_tag_QOv9lUObtGr5VOJHSjWYHE */

#ifndef c1_typedef_c1_rtString
#define c1_typedef_c1_rtString

typedef struct c1_tag_QOv9lUObtGr5VOJHSjWYHE c1_rtString;

#endif                                 /* c1_typedef_c1_rtString */

#ifndef c1_struct_c1_tag_2Z7wBlxjO7amAEeUUaGPcG
#define c1_struct_c1_tag_2Z7wBlxjO7amAEeUUaGPcG

struct c1_tag_2Z7wBlxjO7amAEeUUaGPcG
{
  char_T Value[8];
};

#endif                                 /* c1_struct_c1_tag_2Z7wBlxjO7amAEeUUaGPcG */

#ifndef c1_typedef_c1_rtString_2
#define c1_typedef_c1_rtString_2

typedef struct c1_tag_2Z7wBlxjO7amAEeUUaGPcG c1_rtString_2;

#endif                                 /* c1_typedef_c1_rtString_2 */

#ifndef c1_struct_c1_tag_AUQiMqLxBjYJC2klX95aiG
#define c1_struct_c1_tag_AUQiMqLxBjYJC2klX95aiG

struct c1_tag_AUQiMqLxBjYJC2klX95aiG
{
  char_T Value[7];
};

#endif                                 /* c1_struct_c1_tag_AUQiMqLxBjYJC2klX95aiG */

#ifndef c1_typedef_c1_c_rtString_1
#define c1_typedef_c1_c_rtString_1

typedef struct c1_tag_AUQiMqLxBjYJC2klX95aiG c1_c_rtString_1;

#endif                                 /* c1_typedef_c1_c_rtString_1 */

#ifndef c1_struct_c1_tag_lKQV0Lroo9ddhTRqEONsXH
#define c1_struct_c1_tag_lKQV0Lroo9ddhTRqEONsXH

struct c1_tag_lKQV0Lroo9ddhTRqEONsXH
{
  char_T Value[8];
};

#endif                                 /* c1_struct_c1_tag_lKQV0Lroo9ddhTRqEONsXH */

#ifndef c1_typedef_c1_c_rtString_3
#define c1_typedef_c1_c_rtString_3

typedef struct c1_tag_lKQV0Lroo9ddhTRqEONsXH c1_c_rtString_3;

#endif                                 /* c1_typedef_c1_c_rtString_3 */

#ifndef c1_struct_c1_tag_jdcdw0PiMBCTdeBOpodFZH
#define c1_struct_c1_tag_jdcdw0PiMBCTdeBOpodFZH

struct c1_tag_jdcdw0PiMBCTdeBOpodFZH
{
  c1_cell_0 _data;
};

#endif                                 /* c1_struct_c1_tag_jdcdw0PiMBCTdeBOpodFZH */

#ifndef c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH
#define c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH

typedef struct c1_tag_jdcdw0PiMBCTdeBOpodFZH c1_s_jdcdw0PiMBCTdeBOpodFZH;

#endif                                 /* c1_typedef_c1_s_jdcdw0PiMBCTdeBOpodFZH */

#ifndef c1_struct_c1_tag_7kqyh9yPSX1r9g9o63IGa
#define c1_struct_c1_tag_7kqyh9yPSX1r9g9o63IGa

struct c1_tag_7kqyh9yPSX1r9g9o63IGa
{
  c1_cell_1 _data;
};

#endif                                 /* c1_struct_c1_tag_7kqyh9yPSX1r9g9o63IGa */

#ifndef c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa
#define c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa

typedef struct c1_tag_7kqyh9yPSX1r9g9o63IGa c1_s_7kqyh9yPSX1r9g9o63IGa;

#endif                                 /* c1_typedef_c1_s_7kqyh9yPSX1r9g9o63IGa */

#ifndef c1_struct_c1_tag_rs0J7tUaO8r8RV5HCYwLTD
#define c1_struct_c1_tag_rs0J7tUaO8r8RV5HCYwLTD

struct c1_tag_rs0J7tUaO8r8RV5HCYwLTD
{
  c1_cell_wrap_2 _data;
};

#endif                                 /* c1_struct_c1_tag_rs0J7tUaO8r8RV5HCYwLTD */

#ifndef c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD
#define c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD

typedef struct c1_tag_rs0J7tUaO8r8RV5HCYwLTD c1_s_rs0J7tUaO8r8RV5HCYwLTD;

#endif                                 /* c1_typedef_c1_s_rs0J7tUaO8r8RV5HCYwLTD */

#ifndef c1_struct_c1_tag_PziPEzZoKKixmpD5T9qTcD
#define c1_struct_c1_tag_PziPEzZoKKixmpD5T9qTcD

struct c1_tag_PziPEzZoKKixmpD5T9qTcD
{
  c1_sG4eiVjMQ0O8d9Qp49KylpE nontunableWorkspace;
};

#endif                                 /* c1_struct_c1_tag_PziPEzZoKKixmpD5T9qTcD */

#ifndef c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD
#define c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD

typedef struct c1_tag_PziPEzZoKKixmpD5T9qTcD c1_s_PziPEzZoKKixmpD5T9qTcD;

#endif                                 /* c1_typedef_c1_s_PziPEzZoKKixmpD5T9qTcD */

#ifndef c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD
#define c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD

struct c1_tag_HOps0FrfA6RiWumqewPwZD
{
  c1_cell_wrap_4 _data;
};

#endif                                 /* c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_struct_c1_tag_1nlLkVeIuST25DF6il3ApD
#define c1_struct_c1_tag_1nlLkVeIuST25DF6il3ApD

struct c1_tag_1nlLkVeIuST25DF6il3ApD
{
  c1_cell_wrap_3 _data;
};

#endif                                 /* c1_struct_c1_tag_1nlLkVeIuST25DF6il3ApD */

#ifndef c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD
#define c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD

typedef struct c1_tag_1nlLkVeIuST25DF6il3ApD c1_s_1nlLkVeIuST25DF6il3ApD;

#endif                                 /* c1_typedef_c1_s_1nlLkVeIuST25DF6il3ApD */

#ifndef c1_struct_c1_tag_uzuPWHtc1cM7ZRTfbsKeiF
#define c1_struct_c1_tag_uzuPWHtc1cM7ZRTfbsKeiF

struct c1_tag_uzuPWHtc1cM7ZRTfbsKeiF
{
  c1_cell_5 _data;
};

#endif                                 /* c1_struct_c1_tag_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF
#define c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF

typedef struct c1_tag_uzuPWHtc1cM7ZRTfbsKeiF c1_s_uzuPWHtc1cM7ZRTfbsKeiF;

#endif                                 /* c1_typedef_c1_s_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c1_struct_c1_tag_qRxSe9N4qwJIjT7M2BxNL
#define c1_struct_c1_tag_qRxSe9N4qwJIjT7M2BxNL

struct c1_tag_qRxSe9N4qwJIjT7M2BxNL
{
  c1_cell_7 _data;
};

#endif                                 /* c1_struct_c1_tag_qRxSe9N4qwJIjT7M2BxNL */

#ifndef c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL
#define c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL

typedef struct c1_tag_qRxSe9N4qwJIjT7M2BxNL c1_s_qRxSe9N4qwJIjT7M2BxNL;

#endif                                 /* c1_typedef_c1_s_qRxSe9N4qwJIjT7M2BxNL */

#ifndef c1_struct_c1_tag_4dijvwFFQt8JouTajf5bDH
#define c1_struct_c1_tag_4dijvwFFQt8JouTajf5bDH

struct c1_tag_4dijvwFFQt8JouTajf5bDH
{
  c1_cell_8 _data;
};

#endif                                 /* c1_struct_c1_tag_4dijvwFFQt8JouTajf5bDH */

#ifndef c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH
#define c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH

typedef struct c1_tag_4dijvwFFQt8JouTajf5bDH c1_s_4dijvwFFQt8JouTajf5bDH;

#endif                                 /* c1_typedef_c1_s_4dijvwFFQt8JouTajf5bDH */

#ifndef c1_struct_c1_tag_3krQGJUZiHCKKXkfwgRDoG
#define c1_struct_c1_tag_3krQGJUZiHCKKXkfwgRDoG

struct c1_tag_3krQGJUZiHCKKXkfwgRDoG
{
  c1_cell_wrap_10 _data;
};

#endif                                 /* c1_struct_c1_tag_3krQGJUZiHCKKXkfwgRDoG */

#ifndef c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG
#define c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG

typedef struct c1_tag_3krQGJUZiHCKKXkfwgRDoG c1_s_3krQGJUZiHCKKXkfwgRDoG;

#endif                                 /* c1_typedef_c1_s_3krQGJUZiHCKKXkfwgRDoG */

#ifndef c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD
#define c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD

struct c1_tag_tP4ysjhyvuYk36JuHDg8bD
{
  c1_s_a7TcNrdk5JZcy5uxGijaRG _data;
};

#endif                                 /* c1_struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c1_typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c1_struct_c1_tag_lv60kHidgCVN68cHDjBCkF
#define c1_struct_c1_tag_lv60kHidgCVN68cHDjBCkF

struct c1_tag_lv60kHidgCVN68cHDjBCkF
{
  c1_cell_11 _data;
};

#endif                                 /* c1_struct_c1_tag_lv60kHidgCVN68cHDjBCkF */

#ifndef c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF
#define c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF

typedef struct c1_tag_lv60kHidgCVN68cHDjBCkF c1_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* c1_typedef_c1_s_lv60kHidgCVN68cHDjBCkF */

#ifndef typedef_SFc1_flightControlSystemInstanceStruct
#define typedef_SFc1_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_JITStateAnimation[1];
  uint8_T c1_JITTransitionAnimation[1];
  real_T c1_redMask[19200];
  real_T c1_B[19200];
  real_T c1_dv[19200];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  uint8_T (*c1_R)[19200];
  real_T (*c1_binaryImage)[19200];
  uint8_T (*c1_G)[19200];
  uint8_T (*c1_b_B)[19200];
} SFc1_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc1_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
