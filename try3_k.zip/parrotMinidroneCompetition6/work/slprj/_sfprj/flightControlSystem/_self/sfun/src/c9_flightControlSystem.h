#ifndef __c9_flightControlSystem_h__
#define __c9_flightControlSystem_h__

/* Forward Declarations */
#ifndef c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG
#define c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG

typedef struct c9_tag_sGaAmWJmK5HvPUvd2k3PkCG c9_sGaAmWJmK5HvPUvd2k3PkCG;

#endif                                 /* c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC
#define c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC

typedef struct c9_tag_sc6f4Behc0Ffg9eeZ0XliHC c9_sc6f4Behc0Ffg9eeZ0XliHC;

#endif                                 /* c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC */

#ifndef c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG
#define c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG

typedef struct c9_tag_szuUIsjSIN6GWJW5YzVNVmG c9_szuUIsjSIN6GWJW5YzVNVmG;

#endif                                 /* c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE
#define c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE

typedef struct c9_tag_s9s8BC13iTohZXRbLMSIDHE c9_s9s8BC13iTohZXRbLMSIDHE;

#endif                                 /* c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE */

#ifndef c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE
#define c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE

typedef struct c9_tag_skZBV47kFp42DPFCMXy0uBE c9_skZBV47kFp42DPFCMXy0uBE;

#endif                                 /* c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE */

#ifndef c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD
#define c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c9_tag_0K68mFBjQDo1WRxKPpRFgD c9_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC
#define c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c9_tag_P9BqU0OiPAu5sFhUNvbXPC c9_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C
#define c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C

typedef struct c9_tag_s7x1Wx46WFovLWMRmX2SU0C c9_s7x1Wx46WFovLWMRmX2SU0C;

#endif                                 /* c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C */

#ifndef c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F
#define c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F

typedef struct c9_tag_smzGQHcQ1fZcSCW5rtLpn4F c9_smzGQHcQ1fZcSCW5rtLpn4F;

#endif                                 /* c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG
#define c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c9_tag_a7TcNrdk5JZcy5uxGijaRG c9_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c9_typedef_c9_cell_1
#define c9_typedef_c9_cell_1

typedef struct c9_tag_hIvE0H0Ni3BhTo6qVK2nUE c9_cell_1;

#endif                                 /* c9_typedef_c9_cell_1 */

#ifndef c9_typedef_c9_cell_2
#define c9_typedef_c9_cell_2

typedef struct c9_tag_25GdKeOSj3xov0ID48aFgC c9_cell_2;

#endif                                 /* c9_typedef_c9_cell_2 */

#ifndef c9_typedef_c9_cell_3
#define c9_typedef_c9_cell_3

typedef struct c9_tag_7Te4OFDdKI7zKK1PSL4sfF c9_cell_3;

#endif                                 /* c9_typedef_c9_cell_3 */

#ifndef c9_typedef_c9_cell_wrap_4
#define c9_typedef_c9_cell_wrap_4

typedef struct c9_tag_arNsAu0k4EKn3oJmOQ4PR c9_cell_wrap_4;

#endif                                 /* c9_typedef_c9_cell_wrap_4 */

#ifndef c9_typedef_c9_cell_5
#define c9_typedef_c9_cell_5

typedef struct c9_tag_4f3zucywOvoC0QgnMj36nF c9_cell_5;

#endif                                 /* c9_typedef_c9_cell_5 */

#ifndef c9_typedef_c9_cell_wrap_6
#define c9_typedef_c9_cell_wrap_6

typedef struct c9_tag_y2anywF90yUI9j7qH5yd3E c9_cell_wrap_6;

#endif                                 /* c9_typedef_c9_cell_wrap_6 */

#ifndef c9_typedef_c9_cell_wrap_7
#define c9_typedef_c9_cell_wrap_7

typedef struct c9_tag_ge1UD3YqHcNerzgtJ4AjXF c9_cell_wrap_7;

#endif                                 /* c9_typedef_c9_cell_wrap_7 */

#ifndef c9_typedef_c9_cell_8
#define c9_typedef_c9_cell_8

typedef struct c9_tag_EX2wxrf7UhZ6FVbfRZyo7B c9_cell_8;

#endif                                 /* c9_typedef_c9_cell_8 */

#ifndef c9_typedef_c9_cell_wrap_0
#define c9_typedef_c9_cell_wrap_0

typedef struct c9_tag_L5JvjW1A13FyCQi5N783sB c9_cell_wrap_0;

#endif                                 /* c9_typedef_c9_cell_wrap_0 */

#ifndef c9_typedef_c9_cell_wrap_9
#define c9_typedef_c9_cell_wrap_9

typedef struct c9_tag_6jR4RtbHdjyG00WYqgD5nF c9_cell_wrap_9;

#endif                                 /* c9_typedef_c9_cell_wrap_9 */

#ifndef c9_typedef_c9_cell_10
#define c9_typedef_c9_cell_10

typedef struct c9_tag_njgfiHhWBCqqqpWsKZxr7F c9_cell_10;

#endif                                 /* c9_typedef_c9_cell_10 */

#ifndef c9_typedef_c9_cell_11
#define c9_typedef_c9_cell_11

typedef struct c9_tag_wvqtwQNAx0JJ5IpvMHRcsG c9_cell_11;

#endif                                 /* c9_typedef_c9_cell_11 */

#ifndef c9_typedef_c9_cell_12
#define c9_typedef_c9_cell_12

typedef struct c9_tag_awFMsYYWj01uO3vmLPQJOE c9_cell_12;

#endif                                 /* c9_typedef_c9_cell_12 */

#ifndef c9_typedef_c9_cell_13
#define c9_typedef_c9_cell_13

typedef struct c9_tag_xOZlLoGvSrTJr14RWwCqHG c9_cell_13;

#endif                                 /* c9_typedef_c9_cell_13 */

#ifndef c9_typedef_c9_cell_14
#define c9_typedef_c9_cell_14

typedef struct c9_tag_WYClaNMLzsYbJFiV2mng6F c9_cell_14;

#endif                                 /* c9_typedef_c9_cell_14 */

#ifndef c9_typedef_c9_cell_15
#define c9_typedef_c9_cell_15

typedef struct c9_tag_BoX4lGjW7CLGNTo2OWmlp c9_cell_15;

#endif                                 /* c9_typedef_c9_cell_15 */

#ifndef c9_typedef_c9_cell_16
#define c9_typedef_c9_cell_16

typedef struct c9_tag_6CsBRVljdCQyAxGT7eZM3E c9_cell_16;

#endif                                 /* c9_typedef_c9_cell_16 */

#ifndef c9_typedef_c9_cell_18
#define c9_typedef_c9_cell_18

typedef struct c9_tag_URxaCoPZWr69Oy7fwnFxl c9_cell_18;

#endif                                 /* c9_typedef_c9_cell_18 */

#ifndef c9_typedef_c9_cell_19
#define c9_typedef_c9_cell_19

typedef struct c9_tag_yMfj6323Zqv19VFnWGoHjH c9_cell_19;

#endif                                 /* c9_typedef_c9_cell_19 */

#ifndef c9_typedef_c9_cell_20
#define c9_typedef_c9_cell_20

typedef struct c9_tag_kS8ceVSqQXZwOLTLRGuZQC c9_cell_20;

#endif                                 /* c9_typedef_c9_cell_20 */

#ifndef c9_typedef_c9_cell_21
#define c9_typedef_c9_cell_21

typedef struct c9_tag_Se3bDHKMt28bXt374He6IB c9_cell_21;

#endif                                 /* c9_typedef_c9_cell_21 */

#ifndef c9_typedef_c9_cell_22
#define c9_typedef_c9_cell_22

typedef struct c9_tag_4uvGTEjvHQUqIbuB33mmHB c9_cell_22;

#endif                                 /* c9_typedef_c9_cell_22 */

#ifndef c9_typedef_c9_cell_23
#define c9_typedef_c9_cell_23

typedef struct c9_tag_cUWaYEfJVKrwLRux1qG4UF c9_cell_23;

#endif                                 /* c9_typedef_c9_cell_23 */

#ifndef c9_typedef_c9_cell_24
#define c9_typedef_c9_cell_24

typedef struct c9_tag_oanHHIkf1jJJFv0zKMaqxG c9_cell_24;

#endif                                 /* c9_typedef_c9_cell_24 */

#ifndef c9_typedef_c9_cell_25
#define c9_typedef_c9_cell_25

typedef struct c9_tag_tOVohXlnRgOVmYnwYHCFcH c9_cell_25;

#endif                                 /* c9_typedef_c9_cell_25 */

#ifndef c9_typedef_c9_cell_26
#define c9_typedef_c9_cell_26

typedef struct c9_tag_QxFbldG57tOstWLr33LOmB c9_cell_26;

#endif                                 /* c9_typedef_c9_cell_26 */

#ifndef c9_typedef_c9_cell_27
#define c9_typedef_c9_cell_27

typedef struct c9_tag_DwCj7Xnd6JZ0A1dXnN5rc c9_cell_27;

#endif                                 /* c9_typedef_c9_cell_27 */

#ifndef c9_typedef_c9_cell_28
#define c9_typedef_c9_cell_28

typedef struct c9_tag_gXbtcthfT36yc3y9NSOpHB c9_cell_28;

#endif                                 /* c9_typedef_c9_cell_28 */

#ifndef c9_typedef_c9_cell_29
#define c9_typedef_c9_cell_29

typedef struct c9_tag_sQqzhT6lgzOQlKB8EVZ4HF c9_cell_29;

#endif                                 /* c9_typedef_c9_cell_29 */

#ifndef c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD
#define c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c9_tag_tP4ysjhyvuYk36JuHDg8bD c9_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF
#define c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF

typedef struct c9_tag_ynaaIE6q9xznGBkza31TCF c9_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH
#define c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH

typedef struct c9_tag_Wpvgs6lt20ISI5VkQtF4vH c9_s_Wpvgs6lt20ISI5VkQtF4vH;

#endif                                 /* c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH */

#ifndef c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF
#define c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF

typedef struct c9_tag_hq4Z13O5hXdQ9UsncvBGlF c9_s_hq4Z13O5hXdQ9UsncvBGlF;

#endif                                 /* c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD
#define c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD

typedef struct c9_tag_GZjSpaey3IDRqvh7nZoQMD c9_s_GZjSpaey3IDRqvh7nZoQMD;

#endif                                 /* c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD */

#ifndef c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG
#define c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG

typedef struct c9_tag_zhWislg2JXfOJCG0FlayVG c9_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG */

#ifndef c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF
#define c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c9_tag_BrRdqYMft44ulwR1A7rKqF c9_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF
#define c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c9_tag_lnEOVMt12CNg5nSw1iwvNF c9_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC
#define c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c9_tag_Uq8YUzQmSy3K1TONPeIAhC c9_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD
#define c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD

typedef struct c9_tag_HOps0FrfA6RiWumqewPwZD c9_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD
#define c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD

typedef struct c9_tag_1nlLkVeIuST25DF6il3ApD c9_s_1nlLkVeIuST25DF6il3ApD;

#endif                                 /* c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD */

#ifndef c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF
#define c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF

typedef struct c9_tag_uzuPWHtc1cM7ZRTfbsKeiF c9_s_uzuPWHtc1cM7ZRTfbsKeiF;

#endif                                 /* c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF
#define c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c9_tag_i8jNnI3x8wo4JAox5HV9WF c9_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD
#define c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c9_tag_dV11HShs2d9BqwRJb6HgvD c9_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE
#define c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE

typedef struct c9_tag_JkNjgv3CFjBZhduPupEzEE c9_s_JkNjgv3CFjBZhduPupEzEE;

#endif                                 /* c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE */

#ifndef c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH
#define c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c9_tag_HSHOljOSgF7qDZeWd2IfH c9_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG
#define c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG

typedef struct c9_tag_23YJI910RYCWhAsXw5RjrG c9_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG */

#ifndef c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH
#define c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c9_tag_i3ZGqykvgqQLsMCH6x4OBH c9_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB
#define c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c9_tag_u4ui3JwwaZ1jYzDQeNl7gB c9_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF
#define c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF

typedef struct c9_tag_lv60kHidgCVN68cHDjBCkF c9_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF */

#ifndef c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB
#define c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB

typedef struct c9_tag_MQfHiYk2RSY7P6gdFv6fDB c9_s_MQfHiYk2RSY7P6gdFv6fDB;

#endif                                 /* c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG
#define c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG

typedef struct c9_tag_zyomqXisN60TlgNyBJHFGG c9_s_zyomqXisN60TlgNyBJHFGG;

#endif                                 /* c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG */

#ifndef c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE
#define c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE

typedef struct c9_tag_7xbvANdg7KAufDVBBSkgZE c9_s_7xbvANdg7KAufDVBBSkgZE;

#endif                                 /* c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE */

#ifndef c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC
#define c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC

typedef struct c9_tag_FT1dThmKyyOBY5mTNhhCiC c9_s_FT1dThmKyyOBY5mTNhhCiC;

#endif                                 /* c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC */

#ifndef c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG
#define c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG

typedef struct c9_tag_LiC67LW1mMO192u9sMnmMG c9_s_LiC67LW1mMO192u9sMnmMG;

#endif                                 /* c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG */

#ifndef c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF
#define c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF

typedef struct c9_tag_MNdGPE827fhwyzcwIbJ2SF c9_s_MNdGPE827fhwyzcwIbJ2SF;

#endif                                 /* c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF */

#ifndef c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB
#define c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB

typedef struct c9_tag_GvWTNEJOSSRh883m2SnETB c9_s_GvWTNEJOSSRh883m2SnETB;

#endif                                 /* c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB */

#ifndef c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F
#define c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F

typedef struct c9_tag_Z2qSppxNoXb8Jppd82oq6F c9_s_Z2qSppxNoXb8Jppd82oq6F;

#endif                                 /* c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F */

#ifndef c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH
#define c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH

typedef struct c9_tag_bfdw51ZQJqFWZgII8x0zkH c9_s_bfdw51ZQJqFWZgII8x0zkH;

#endif                                 /* c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH */

#ifndef c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH
#define c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH

typedef struct c9_tag_Zk8dErMjLMrsJtNaWjimqH c9_s_Zk8dErMjLMrsJtNaWjimqH;

#endif                                 /* c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH */

/* Type Definitions */
#ifndef c9_struct_c9_tag_sGaAmWJmK5HvPUvd2k3PkCG
#define c9_struct_c9_tag_sGaAmWJmK5HvPUvd2k3PkCG

struct c9_tag_sGaAmWJmK5HvPUvd2k3PkCG
{
  uint32_T nanflag;
  uint32_T ComparisonMethod;
};

#endif                                 /* c9_struct_c9_tag_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG
#define c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG

typedef struct c9_tag_sGaAmWJmK5HvPUvd2k3PkCG c9_sGaAmWJmK5HvPUvd2k3PkCG;

#endif                                 /* c9_typedef_c9_sGaAmWJmK5HvPUvd2k3PkCG */

#ifndef c9_struct_c9_tag_sc6f4Behc0Ffg9eeZ0XliHC
#define c9_struct_c9_tag_sc6f4Behc0Ffg9eeZ0XliHC

struct c9_tag_sc6f4Behc0Ffg9eeZ0XliHC
{
  uint32_T dim;
  uint32_T nanflag;
  uint32_T linear;
  uint32_T ComparisonMethod;
};

#endif                                 /* c9_struct_c9_tag_sc6f4Behc0Ffg9eeZ0XliHC */

#ifndef c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC
#define c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC

typedef struct c9_tag_sc6f4Behc0Ffg9eeZ0XliHC c9_sc6f4Behc0Ffg9eeZ0XliHC;

#endif                                 /* c9_typedef_c9_sc6f4Behc0Ffg9eeZ0XliHC */

#ifndef c9_struct_c9_tag_szuUIsjSIN6GWJW5YzVNVmG
#define c9_struct_c9_tag_szuUIsjSIN6GWJW5YzVNVmG

struct c9_tag_szuUIsjSIN6GWJW5YzVNVmG
{
  uint32_T Theta;
  uint32_T RhoResolution;
};

#endif                                 /* c9_struct_c9_tag_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG
#define c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG

typedef struct c9_tag_szuUIsjSIN6GWJW5YzVNVmG c9_szuUIsjSIN6GWJW5YzVNVmG;

#endif                                 /* c9_typedef_c9_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef c9_struct_c9_tag_s9s8BC13iTohZXRbLMSIDHE
#define c9_struct_c9_tag_s9s8BC13iTohZXRbLMSIDHE

struct c9_tag_s9s8BC13iTohZXRbLMSIDHE
{
  boolean_T CaseSensitivity;
  boolean_T StructExpand;
  boolean_T PartialMatching;
};

#endif                                 /* c9_struct_c9_tag_s9s8BC13iTohZXRbLMSIDHE */

#ifndef c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE
#define c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE

typedef struct c9_tag_s9s8BC13iTohZXRbLMSIDHE c9_s9s8BC13iTohZXRbLMSIDHE;

#endif                                 /* c9_typedef_c9_s9s8BC13iTohZXRbLMSIDHE */

#ifndef c9_struct_c9_tag_skZBV47kFp42DPFCMXy0uBE
#define c9_struct_c9_tag_skZBV47kFp42DPFCMXy0uBE

struct c9_tag_skZBV47kFp42DPFCMXy0uBE
{
  uint32_T Threshold;
  uint32_T NHoodSize;
  uint32_T Theta;
};

#endif                                 /* c9_struct_c9_tag_skZBV47kFp42DPFCMXy0uBE */

#ifndef c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE
#define c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE

typedef struct c9_tag_skZBV47kFp42DPFCMXy0uBE c9_skZBV47kFp42DPFCMXy0uBE;

#endif                                 /* c9_typedef_c9_skZBV47kFp42DPFCMXy0uBE */

#ifndef c9_struct_c9_tag_0K68mFBjQDo1WRxKPpRFgD
#define c9_struct_c9_tag_0K68mFBjQDo1WRxKPpRFgD

struct c9_tag_0K68mFBjQDo1WRxKPpRFgD
{
  int32_T f1;
  int32_T f2;
};

#endif                                 /* c9_struct_c9_tag_0K68mFBjQDo1WRxKPpRFgD */

#ifndef c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD
#define c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c9_tag_0K68mFBjQDo1WRxKPpRFgD c9_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* c9_typedef_c9_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef c9_struct_c9_tag_P9BqU0OiPAu5sFhUNvbXPC
#define c9_struct_c9_tag_P9BqU0OiPAu5sFhUNvbXPC

struct c9_tag_P9BqU0OiPAu5sFhUNvbXPC
{
  c9_s_0K68mFBjQDo1WRxKPpRFgD _data;
};

#endif                                 /* c9_struct_c9_tag_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC
#define c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c9_tag_P9BqU0OiPAu5sFhUNvbXPC c9_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* c9_typedef_c9_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef c9_struct_c9_tag_s7x1Wx46WFovLWMRmX2SU0C
#define c9_struct_c9_tag_s7x1Wx46WFovLWMRmX2SU0C

struct c9_tag_s7x1Wx46WFovLWMRmX2SU0C
{
  char_T struct_tm[7];
  char_T struct_timespec[13];
};

#endif                                 /* c9_struct_c9_tag_s7x1Wx46WFovLWMRmX2SU0C */

#ifndef c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C
#define c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C

typedef struct c9_tag_s7x1Wx46WFovLWMRmX2SU0C c9_s7x1Wx46WFovLWMRmX2SU0C;

#endif                                 /* c9_typedef_c9_s7x1Wx46WFovLWMRmX2SU0C */

#ifndef c9_struct_c9_tag_smzGQHcQ1fZcSCW5rtLpn4F
#define c9_struct_c9_tag_smzGQHcQ1fZcSCW5rtLpn4F

struct c9_tag_smzGQHcQ1fZcSCW5rtLpn4F
{
  boolean_T CaseSensitivity;
  char_T PartialMatching[6];
  boolean_T StructExpand;
  boolean_T IgnoreNulls;
  boolean_T SupportOverrides;
};

#endif                                 /* c9_struct_c9_tag_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F
#define c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F

typedef struct c9_tag_smzGQHcQ1fZcSCW5rtLpn4F c9_smzGQHcQ1fZcSCW5rtLpn4F;

#endif                                 /* c9_typedef_c9_smzGQHcQ1fZcSCW5rtLpn4F */

#ifndef c9_struct_c9_tag_a7TcNrdk5JZcy5uxGijaRG
#define c9_struct_c9_tag_a7TcNrdk5JZcy5uxGijaRG

struct c9_tag_a7TcNrdk5JZcy5uxGijaRG
{
  char_T f1[7];
  char_T f2[7];
};

#endif                                 /* c9_struct_c9_tag_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG
#define c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c9_tag_a7TcNrdk5JZcy5uxGijaRG c9_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* c9_typedef_c9_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef c9_struct_c9_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define c9_struct_c9_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c9_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* c9_struct_c9_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef c9_typedef_c9_cell_1
#define c9_typedef_c9_cell_1

typedef struct c9_tag_hIvE0H0Ni3BhTo6qVK2nUE c9_cell_1;

#endif                                 /* c9_typedef_c9_cell_1 */

#ifndef c9_struct_c9_tag_25GdKeOSj3xov0ID48aFgC
#define c9_struct_c9_tag_25GdKeOSj3xov0ID48aFgC

struct c9_tag_25GdKeOSj3xov0ID48aFgC
{
  char_T f1[5];
  char_T f2[11];
  char_T f3[5];
  char_T f4[7];
  char_T f5[7];
  char_T f6[3];
  char_T f7[9];
};

#endif                                 /* c9_struct_c9_tag_25GdKeOSj3xov0ID48aFgC */

#ifndef c9_typedef_c9_cell_2
#define c9_typedef_c9_cell_2

typedef struct c9_tag_25GdKeOSj3xov0ID48aFgC c9_cell_2;

#endif                                 /* c9_typedef_c9_cell_2 */

#ifndef c9_struct_c9_tag_7Te4OFDdKI7zKK1PSL4sfF
#define c9_struct_c9_tag_7Te4OFDdKI7zKK1PSL4sfF

struct c9_tag_7Te4OFDdKI7zKK1PSL4sfF
{
  char_T f1[5];
  char_T f2[7];
  char_T f3[7];
};

#endif                                 /* c9_struct_c9_tag_7Te4OFDdKI7zKK1PSL4sfF */

#ifndef c9_typedef_c9_cell_3
#define c9_typedef_c9_cell_3

typedef struct c9_tag_7Te4OFDdKI7zKK1PSL4sfF c9_cell_3;

#endif                                 /* c9_typedef_c9_cell_3 */

#ifndef c9_struct_c9_tag_arNsAu0k4EKn3oJmOQ4PR
#define c9_struct_c9_tag_arNsAu0k4EKn3oJmOQ4PR

struct c9_tag_arNsAu0k4EKn3oJmOQ4PR
{
  char_T f1[5];
};

#endif                                 /* c9_struct_c9_tag_arNsAu0k4EKn3oJmOQ4PR */

#ifndef c9_typedef_c9_cell_wrap_4
#define c9_typedef_c9_cell_wrap_4

typedef struct c9_tag_arNsAu0k4EKn3oJmOQ4PR c9_cell_wrap_4;

#endif                                 /* c9_typedef_c9_cell_wrap_4 */

#ifndef c9_struct_c9_tag_4f3zucywOvoC0QgnMj36nF
#define c9_struct_c9_tag_4f3zucywOvoC0QgnMj36nF

struct c9_tag_4f3zucywOvoC0QgnMj36nF
{
  char_T f1[4];
  char_T f2[5];
  char_T f3[5];
  char_T f4[6];
  char_T f5[5];
  char_T f6[6];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* c9_struct_c9_tag_4f3zucywOvoC0QgnMj36nF */

#ifndef c9_typedef_c9_cell_5
#define c9_typedef_c9_cell_5

typedef struct c9_tag_4f3zucywOvoC0QgnMj36nF c9_cell_5;

#endif                                 /* c9_typedef_c9_cell_5 */

#ifndef c9_struct_c9_tag_y2anywF90yUI9j7qH5yd3E
#define c9_struct_c9_tag_y2anywF90yUI9j7qH5yd3E

struct c9_tag_y2anywF90yUI9j7qH5yd3E
{
  char_T f1[9];
};

#endif                                 /* c9_struct_c9_tag_y2anywF90yUI9j7qH5yd3E */

#ifndef c9_typedef_c9_cell_wrap_6
#define c9_typedef_c9_cell_wrap_6

typedef struct c9_tag_y2anywF90yUI9j7qH5yd3E c9_cell_wrap_6;

#endif                                 /* c9_typedef_c9_cell_wrap_6 */

#ifndef c9_struct_c9_tag_ge1UD3YqHcNerzgtJ4AjXF
#define c9_struct_c9_tag_ge1UD3YqHcNerzgtJ4AjXF

struct c9_tag_ge1UD3YqHcNerzgtJ4AjXF
{
  char_T f1[6];
};

#endif                                 /* c9_struct_c9_tag_ge1UD3YqHcNerzgtJ4AjXF */

#ifndef c9_typedef_c9_cell_wrap_7
#define c9_typedef_c9_cell_wrap_7

typedef struct c9_tag_ge1UD3YqHcNerzgtJ4AjXF c9_cell_wrap_7;

#endif                                 /* c9_typedef_c9_cell_wrap_7 */

#ifndef c9_struct_c9_tag_EX2wxrf7UhZ6FVbfRZyo7B
#define c9_struct_c9_tag_EX2wxrf7UhZ6FVbfRZyo7B

struct c9_tag_EX2wxrf7UhZ6FVbfRZyo7B
{
  char_T f1[9];
  char_T f2[9];
  char_T f3[8];
  char_T f4[4];
  char_T f5[4];
  char_T f6[4];
  char_T f7[4];
};

#endif                                 /* c9_struct_c9_tag_EX2wxrf7UhZ6FVbfRZyo7B */

#ifndef c9_typedef_c9_cell_8
#define c9_typedef_c9_cell_8

typedef struct c9_tag_EX2wxrf7UhZ6FVbfRZyo7B c9_cell_8;

#endif                                 /* c9_typedef_c9_cell_8 */

#ifndef c9_struct_c9_tag_L5JvjW1A13FyCQi5N783sB
#define c9_struct_c9_tag_L5JvjW1A13FyCQi5N783sB

struct c9_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* c9_struct_c9_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef c9_typedef_c9_cell_wrap_0
#define c9_typedef_c9_cell_wrap_0

typedef struct c9_tag_L5JvjW1A13FyCQi5N783sB c9_cell_wrap_0;

#endif                                 /* c9_typedef_c9_cell_wrap_0 */

#ifndef c9_struct_c9_tag_6jR4RtbHdjyG00WYqgD5nF
#define c9_struct_c9_tag_6jR4RtbHdjyG00WYqgD5nF

struct c9_tag_6jR4RtbHdjyG00WYqgD5nF
{
  char_T f1[16];
};

#endif                                 /* c9_struct_c9_tag_6jR4RtbHdjyG00WYqgD5nF */

#ifndef c9_typedef_c9_cell_wrap_9
#define c9_typedef_c9_cell_wrap_9

typedef struct c9_tag_6jR4RtbHdjyG00WYqgD5nF c9_cell_wrap_9;

#endif                                 /* c9_typedef_c9_cell_wrap_9 */

#ifndef c9_struct_c9_tag_njgfiHhWBCqqqpWsKZxr7F
#define c9_struct_c9_tag_njgfiHhWBCqqqpWsKZxr7F

struct c9_tag_njgfiHhWBCqqqpWsKZxr7F
{
  char_T f1[15];
  char_T f2[15];
  char_T f3[12];
  char_T f4[11];
  char_T f5[16];
};

#endif                                 /* c9_struct_c9_tag_njgfiHhWBCqqqpWsKZxr7F */

#ifndef c9_typedef_c9_cell_10
#define c9_typedef_c9_cell_10

typedef struct c9_tag_njgfiHhWBCqqqpWsKZxr7F c9_cell_10;

#endif                                 /* c9_typedef_c9_cell_10 */

#ifndef c9_struct_c9_tag_wvqtwQNAx0JJ5IpvMHRcsG
#define c9_struct_c9_tag_wvqtwQNAx0JJ5IpvMHRcsG

struct c9_tag_wvqtwQNAx0JJ5IpvMHRcsG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[11];
  char_T f5[7];
};

#endif                                 /* c9_struct_c9_tag_wvqtwQNAx0JJ5IpvMHRcsG */

#ifndef c9_typedef_c9_cell_11
#define c9_typedef_c9_cell_11

typedef struct c9_tag_wvqtwQNAx0JJ5IpvMHRcsG c9_cell_11;

#endif                                 /* c9_typedef_c9_cell_11 */

#ifndef c9_struct_c9_tag_awFMsYYWj01uO3vmLPQJOE
#define c9_struct_c9_tag_awFMsYYWj01uO3vmLPQJOE

struct c9_tag_awFMsYYWj01uO3vmLPQJOE
{
  char_T f1[8];
  char_T f2[9];
  char_T f3[9];
  char_T f4[3];
  char_T f5[4];
  char_T f6[4];
};

#endif                                 /* c9_struct_c9_tag_awFMsYYWj01uO3vmLPQJOE */

#ifndef c9_typedef_c9_cell_12
#define c9_typedef_c9_cell_12

typedef struct c9_tag_awFMsYYWj01uO3vmLPQJOE c9_cell_12;

#endif                                 /* c9_typedef_c9_cell_12 */

#ifndef c9_struct_c9_tag_xOZlLoGvSrTJr14RWwCqHG
#define c9_struct_c9_tag_xOZlLoGvSrTJr14RWwCqHG

struct c9_tag_xOZlLoGvSrTJr14RWwCqHG
{
  char_T f1[3];
  char_T f2[7];
  char_T f3[6];
};

#endif                                 /* c9_struct_c9_tag_xOZlLoGvSrTJr14RWwCqHG */

#ifndef c9_typedef_c9_cell_13
#define c9_typedef_c9_cell_13

typedef struct c9_tag_xOZlLoGvSrTJr14RWwCqHG c9_cell_13;

#endif                                 /* c9_typedef_c9_cell_13 */

#ifndef c9_struct_c9_tag_WYClaNMLzsYbJFiV2mng6F
#define c9_struct_c9_tag_WYClaNMLzsYbJFiV2mng6F

struct c9_tag_WYClaNMLzsYbJFiV2mng6F
{
  char_T f1[6];
  char_T f2[5];
  char_T f3[4];
  char_T f4[7];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[5];
};

#endif                                 /* c9_struct_c9_tag_WYClaNMLzsYbJFiV2mng6F */

#ifndef c9_typedef_c9_cell_14
#define c9_typedef_c9_cell_14

typedef struct c9_tag_WYClaNMLzsYbJFiV2mng6F c9_cell_14;

#endif                                 /* c9_typedef_c9_cell_14 */

#ifndef c9_struct_c9_tag_BoX4lGjW7CLGNTo2OWmlp
#define c9_struct_c9_tag_BoX4lGjW7CLGNTo2OWmlp

struct c9_tag_BoX4lGjW7CLGNTo2OWmlp
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[7];
};

#endif                                 /* c9_struct_c9_tag_BoX4lGjW7CLGNTo2OWmlp */

#ifndef c9_typedef_c9_cell_15
#define c9_typedef_c9_cell_15

typedef struct c9_tag_BoX4lGjW7CLGNTo2OWmlp c9_cell_15;

#endif                                 /* c9_typedef_c9_cell_15 */

#ifndef c9_struct_c9_tag_6CsBRVljdCQyAxGT7eZM3E
#define c9_struct_c9_tag_6CsBRVljdCQyAxGT7eZM3E

struct c9_tag_6CsBRVljdCQyAxGT7eZM3E
{
  char_T f1[7];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[7];
  char_T f6[8];
};

#endif                                 /* c9_struct_c9_tag_6CsBRVljdCQyAxGT7eZM3E */

#ifndef c9_typedef_c9_cell_16
#define c9_typedef_c9_cell_16

typedef struct c9_tag_6CsBRVljdCQyAxGT7eZM3E c9_cell_16;

#endif                                 /* c9_typedef_c9_cell_16 */

#ifndef c9_struct_c9_tag_URxaCoPZWr69Oy7fwnFxl
#define c9_struct_c9_tag_URxaCoPZWr69Oy7fwnFxl

struct c9_tag_URxaCoPZWr69Oy7fwnFxl
{
  char_T f1[5];
  char_T f2[4];
  char_T f3[6];
  char_T f4[5];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* c9_struct_c9_tag_URxaCoPZWr69Oy7fwnFxl */

#ifndef c9_typedef_c9_cell_18
#define c9_typedef_c9_cell_18

typedef struct c9_tag_URxaCoPZWr69Oy7fwnFxl c9_cell_18;

#endif                                 /* c9_typedef_c9_cell_18 */

#ifndef c9_struct_c9_tag_yMfj6323Zqv19VFnWGoHjH
#define c9_struct_c9_tag_yMfj6323Zqv19VFnWGoHjH

struct c9_tag_yMfj6323Zqv19VFnWGoHjH
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[6];
};

#endif                                 /* c9_struct_c9_tag_yMfj6323Zqv19VFnWGoHjH */

#ifndef c9_typedef_c9_cell_19
#define c9_typedef_c9_cell_19

typedef struct c9_tag_yMfj6323Zqv19VFnWGoHjH c9_cell_19;

#endif                                 /* c9_typedef_c9_cell_19 */

#ifndef c9_struct_c9_tag_kS8ceVSqQXZwOLTLRGuZQC
#define c9_struct_c9_tag_kS8ceVSqQXZwOLTLRGuZQC

struct c9_tag_kS8ceVSqQXZwOLTLRGuZQC
{
  char_T f1[4];
  char_T f2[2];
  char_T f3[9];
  char_T f4[8];
};

#endif                                 /* c9_struct_c9_tag_kS8ceVSqQXZwOLTLRGuZQC */

#ifndef c9_typedef_c9_cell_20
#define c9_typedef_c9_cell_20

typedef struct c9_tag_kS8ceVSqQXZwOLTLRGuZQC c9_cell_20;

#endif                                 /* c9_typedef_c9_cell_20 */

#ifndef c9_struct_c9_tag_Se3bDHKMt28bXt374He6IB
#define c9_struct_c9_tag_Se3bDHKMt28bXt374He6IB

struct c9_tag_Se3bDHKMt28bXt374He6IB
{
  char_T f1[5];
  char_T f2[13];
};

#endif                                 /* c9_struct_c9_tag_Se3bDHKMt28bXt374He6IB */

#ifndef c9_typedef_c9_cell_21
#define c9_typedef_c9_cell_21

typedef struct c9_tag_Se3bDHKMt28bXt374He6IB c9_cell_21;

#endif                                 /* c9_typedef_c9_cell_21 */

#ifndef c9_struct_c9_tag_4uvGTEjvHQUqIbuB33mmHB
#define c9_struct_c9_tag_4uvGTEjvHQUqIbuB33mmHB

struct c9_tag_4uvGTEjvHQUqIbuB33mmHB
{
  char_T f1[15];
  char_T f2[12];
  char_T f3[15];
};

#endif                                 /* c9_struct_c9_tag_4uvGTEjvHQUqIbuB33mmHB */

#ifndef c9_typedef_c9_cell_22
#define c9_typedef_c9_cell_22

typedef struct c9_tag_4uvGTEjvHQUqIbuB33mmHB c9_cell_22;

#endif                                 /* c9_typedef_c9_cell_22 */

#ifndef c9_struct_c9_tag_cUWaYEfJVKrwLRux1qG4UF
#define c9_struct_c9_tag_cUWaYEfJVKrwLRux1qG4UF

struct c9_tag_cUWaYEfJVKrwLRux1qG4UF
{
  char_T f1[8];
  char_T f2[4];
  char_T f3[6];
  char_T f4[6];
};

#endif                                 /* c9_struct_c9_tag_cUWaYEfJVKrwLRux1qG4UF */

#ifndef c9_typedef_c9_cell_23
#define c9_typedef_c9_cell_23

typedef struct c9_tag_cUWaYEfJVKrwLRux1qG4UF c9_cell_23;

#endif                                 /* c9_typedef_c9_cell_23 */

#ifndef c9_struct_c9_tag_oanHHIkf1jJJFv0zKMaqxG
#define c9_struct_c9_tag_oanHHIkf1jJJFv0zKMaqxG

struct c9_tag_oanHHIkf1jJJFv0zKMaqxG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[8];
};

#endif                                 /* c9_struct_c9_tag_oanHHIkf1jJJFv0zKMaqxG */

#ifndef c9_typedef_c9_cell_24
#define c9_typedef_c9_cell_24

typedef struct c9_tag_oanHHIkf1jJJFv0zKMaqxG c9_cell_24;

#endif                                 /* c9_typedef_c9_cell_24 */

#ifndef c9_struct_c9_tag_tOVohXlnRgOVmYnwYHCFcH
#define c9_struct_c9_tag_tOVohXlnRgOVmYnwYHCFcH

struct c9_tag_tOVohXlnRgOVmYnwYHCFcH
{
  char_T f1[4];
  char_T f2[2];
  char_T f3[9];
  char_T f4[8];
  char_T f5[6];
  char_T f6[7];
};

#endif                                 /* c9_struct_c9_tag_tOVohXlnRgOVmYnwYHCFcH */

#ifndef c9_typedef_c9_cell_25
#define c9_typedef_c9_cell_25

typedef struct c9_tag_tOVohXlnRgOVmYnwYHCFcH c9_cell_25;

#endif                                 /* c9_typedef_c9_cell_25 */

#ifndef c9_struct_c9_tag_QxFbldG57tOstWLr33LOmB
#define c9_struct_c9_tag_QxFbldG57tOstWLr33LOmB

struct c9_tag_QxFbldG57tOstWLr33LOmB
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[7];
  char_T f4[8];
  char_T f5[8];
};

#endif                                 /* c9_struct_c9_tag_QxFbldG57tOstWLr33LOmB */

#ifndef c9_typedef_c9_cell_26
#define c9_typedef_c9_cell_26

typedef struct c9_tag_QxFbldG57tOstWLr33LOmB c9_cell_26;

#endif                                 /* c9_typedef_c9_cell_26 */

#ifndef c9_struct_c9_tag_DwCj7Xnd6JZ0A1dXnN5rc
#define c9_struct_c9_tag_DwCj7Xnd6JZ0A1dXnN5rc

struct c9_tag_DwCj7Xnd6JZ0A1dXnN5rc
{
  char_T f1[9];
  char_T f2[9];
  char_T f3[5];
};

#endif                                 /* c9_struct_c9_tag_DwCj7Xnd6JZ0A1dXnN5rc */

#ifndef c9_typedef_c9_cell_27
#define c9_typedef_c9_cell_27

typedef struct c9_tag_DwCj7Xnd6JZ0A1dXnN5rc c9_cell_27;

#endif                                 /* c9_typedef_c9_cell_27 */

#ifndef c9_struct_c9_tag_gXbtcthfT36yc3y9NSOpHB
#define c9_struct_c9_tag_gXbtcthfT36yc3y9NSOpHB

struct c9_tag_gXbtcthfT36yc3y9NSOpHB
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[11];
};

#endif                                 /* c9_struct_c9_tag_gXbtcthfT36yc3y9NSOpHB */

#ifndef c9_typedef_c9_cell_28
#define c9_typedef_c9_cell_28

typedef struct c9_tag_gXbtcthfT36yc3y9NSOpHB c9_cell_28;

#endif                                 /* c9_typedef_c9_cell_28 */

#ifndef c9_struct_c9_tag_sQqzhT6lgzOQlKB8EVZ4HF
#define c9_struct_c9_tag_sQqzhT6lgzOQlKB8EVZ4HF

struct c9_tag_sQqzhT6lgzOQlKB8EVZ4HF
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[7];
  char_T f5[8];
  char_T f6[3];
};

#endif                                 /* c9_struct_c9_tag_sQqzhT6lgzOQlKB8EVZ4HF */

#ifndef c9_typedef_c9_cell_29
#define c9_typedef_c9_cell_29

typedef struct c9_tag_sQqzhT6lgzOQlKB8EVZ4HF c9_cell_29;

#endif                                 /* c9_typedef_c9_cell_29 */

#ifndef c9_struct_c9_tag_tP4ysjhyvuYk36JuHDg8bD
#define c9_struct_c9_tag_tP4ysjhyvuYk36JuHDg8bD

struct c9_tag_tP4ysjhyvuYk36JuHDg8bD
{
  c9_s_a7TcNrdk5JZcy5uxGijaRG _data;
};

#endif                                 /* c9_struct_c9_tag_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD
#define c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c9_tag_tP4ysjhyvuYk36JuHDg8bD c9_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* c9_typedef_c9_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef c9_struct_c9_tag_ynaaIE6q9xznGBkza31TCF
#define c9_struct_c9_tag_ynaaIE6q9xznGBkza31TCF

struct c9_tag_ynaaIE6q9xznGBkza31TCF
{
  c9_cell_1 _data;
};

#endif                                 /* c9_struct_c9_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF
#define c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF

typedef struct c9_tag_ynaaIE6q9xznGBkza31TCF c9_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c9_typedef_c9_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c9_struct_c9_tag_Wpvgs6lt20ISI5VkQtF4vH
#define c9_struct_c9_tag_Wpvgs6lt20ISI5VkQtF4vH

struct c9_tag_Wpvgs6lt20ISI5VkQtF4vH
{
  c9_cell_2 _data;
};

#endif                                 /* c9_struct_c9_tag_Wpvgs6lt20ISI5VkQtF4vH */

#ifndef c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH
#define c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH

typedef struct c9_tag_Wpvgs6lt20ISI5VkQtF4vH c9_s_Wpvgs6lt20ISI5VkQtF4vH;

#endif                                 /* c9_typedef_c9_s_Wpvgs6lt20ISI5VkQtF4vH */

#ifndef c9_struct_c9_tag_hq4Z13O5hXdQ9UsncvBGlF
#define c9_struct_c9_tag_hq4Z13O5hXdQ9UsncvBGlF

struct c9_tag_hq4Z13O5hXdQ9UsncvBGlF
{
  c9_cell_3 _data;
};

#endif                                 /* c9_struct_c9_tag_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF
#define c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF

typedef struct c9_tag_hq4Z13O5hXdQ9UsncvBGlF c9_s_hq4Z13O5hXdQ9UsncvBGlF;

#endif                                 /* c9_typedef_c9_s_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef c9_struct_c9_tag_GZjSpaey3IDRqvh7nZoQMD
#define c9_struct_c9_tag_GZjSpaey3IDRqvh7nZoQMD

struct c9_tag_GZjSpaey3IDRqvh7nZoQMD
{
  c9_cell_wrap_4 _data;
};

#endif                                 /* c9_struct_c9_tag_GZjSpaey3IDRqvh7nZoQMD */

#ifndef c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD
#define c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD

typedef struct c9_tag_GZjSpaey3IDRqvh7nZoQMD c9_s_GZjSpaey3IDRqvh7nZoQMD;

#endif                                 /* c9_typedef_c9_s_GZjSpaey3IDRqvh7nZoQMD */

#ifndef c9_struct_c9_tag_zhWislg2JXfOJCG0FlayVG
#define c9_struct_c9_tag_zhWislg2JXfOJCG0FlayVG

struct c9_tag_zhWislg2JXfOJCG0FlayVG
{
  c9_cell_5 _data;
};

#endif                                 /* c9_struct_c9_tag_zhWislg2JXfOJCG0FlayVG */

#ifndef c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG
#define c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG

typedef struct c9_tag_zhWislg2JXfOJCG0FlayVG c9_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* c9_typedef_c9_s_zhWislg2JXfOJCG0FlayVG */

#ifndef c9_struct_c9_tag_BrRdqYMft44ulwR1A7rKqF
#define c9_struct_c9_tag_BrRdqYMft44ulwR1A7rKqF

struct c9_tag_BrRdqYMft44ulwR1A7rKqF
{
  c9_cell_wrap_6 _data;
};

#endif                                 /* c9_struct_c9_tag_BrRdqYMft44ulwR1A7rKqF */

#ifndef c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF
#define c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c9_tag_BrRdqYMft44ulwR1A7rKqF c9_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* c9_typedef_c9_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef c9_struct_c9_tag_lnEOVMt12CNg5nSw1iwvNF
#define c9_struct_c9_tag_lnEOVMt12CNg5nSw1iwvNF

struct c9_tag_lnEOVMt12CNg5nSw1iwvNF
{
  c9_cell_wrap_7 _data;
};

#endif                                 /* c9_struct_c9_tag_lnEOVMt12CNg5nSw1iwvNF */

#ifndef c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF
#define c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c9_tag_lnEOVMt12CNg5nSw1iwvNF c9_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* c9_typedef_c9_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef c9_struct_c9_tag_Uq8YUzQmSy3K1TONPeIAhC
#define c9_struct_c9_tag_Uq8YUzQmSy3K1TONPeIAhC

struct c9_tag_Uq8YUzQmSy3K1TONPeIAhC
{
  c9_cell_8 _data;
};

#endif                                 /* c9_struct_c9_tag_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC
#define c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c9_tag_Uq8YUzQmSy3K1TONPeIAhC c9_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* c9_typedef_c9_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef c9_struct_c9_tag_HOps0FrfA6RiWumqewPwZD
#define c9_struct_c9_tag_HOps0FrfA6RiWumqewPwZD

struct c9_tag_HOps0FrfA6RiWumqewPwZD
{
  c9_cell_wrap_0 _data;
};

#endif                                 /* c9_struct_c9_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD
#define c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD

typedef struct c9_tag_HOps0FrfA6RiWumqewPwZD c9_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c9_typedef_c9_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c9_struct_c9_tag_1nlLkVeIuST25DF6il3ApD
#define c9_struct_c9_tag_1nlLkVeIuST25DF6il3ApD

struct c9_tag_1nlLkVeIuST25DF6il3ApD
{
  c9_cell_wrap_9 _data;
};

#endif                                 /* c9_struct_c9_tag_1nlLkVeIuST25DF6il3ApD */

#ifndef c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD
#define c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD

typedef struct c9_tag_1nlLkVeIuST25DF6il3ApD c9_s_1nlLkVeIuST25DF6il3ApD;

#endif                                 /* c9_typedef_c9_s_1nlLkVeIuST25DF6il3ApD */

#ifndef c9_struct_c9_tag_uzuPWHtc1cM7ZRTfbsKeiF
#define c9_struct_c9_tag_uzuPWHtc1cM7ZRTfbsKeiF

struct c9_tag_uzuPWHtc1cM7ZRTfbsKeiF
{
  c9_cell_10 _data;
};

#endif                                 /* c9_struct_c9_tag_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF
#define c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF

typedef struct c9_tag_uzuPWHtc1cM7ZRTfbsKeiF c9_s_uzuPWHtc1cM7ZRTfbsKeiF;

#endif                                 /* c9_typedef_c9_s_uzuPWHtc1cM7ZRTfbsKeiF */

#ifndef c9_struct_c9_tag_i8jNnI3x8wo4JAox5HV9WF
#define c9_struct_c9_tag_i8jNnI3x8wo4JAox5HV9WF

struct c9_tag_i8jNnI3x8wo4JAox5HV9WF
{
  c9_cell_11 _data;
};

#endif                                 /* c9_struct_c9_tag_i8jNnI3x8wo4JAox5HV9WF */

#ifndef c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF
#define c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c9_tag_i8jNnI3x8wo4JAox5HV9WF c9_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* c9_typedef_c9_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef c9_struct_c9_tag_dV11HShs2d9BqwRJb6HgvD
#define c9_struct_c9_tag_dV11HShs2d9BqwRJb6HgvD

struct c9_tag_dV11HShs2d9BqwRJb6HgvD
{
  c9_cell_12 _data;
};

#endif                                 /* c9_struct_c9_tag_dV11HShs2d9BqwRJb6HgvD */

#ifndef c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD
#define c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c9_tag_dV11HShs2d9BqwRJb6HgvD c9_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* c9_typedef_c9_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef c9_struct_c9_tag_JkNjgv3CFjBZhduPupEzEE
#define c9_struct_c9_tag_JkNjgv3CFjBZhduPupEzEE

struct c9_tag_JkNjgv3CFjBZhduPupEzEE
{
  c9_cell_13 _data;
};

#endif                                 /* c9_struct_c9_tag_JkNjgv3CFjBZhduPupEzEE */

#ifndef c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE
#define c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE

typedef struct c9_tag_JkNjgv3CFjBZhduPupEzEE c9_s_JkNjgv3CFjBZhduPupEzEE;

#endif                                 /* c9_typedef_c9_s_JkNjgv3CFjBZhduPupEzEE */

#ifndef c9_struct_c9_tag_HSHOljOSgF7qDZeWd2IfH
#define c9_struct_c9_tag_HSHOljOSgF7qDZeWd2IfH

struct c9_tag_HSHOljOSgF7qDZeWd2IfH
{
  c9_cell_14 _data;
};

#endif                                 /* c9_struct_c9_tag_HSHOljOSgF7qDZeWd2IfH */

#ifndef c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH
#define c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c9_tag_HSHOljOSgF7qDZeWd2IfH c9_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* c9_typedef_c9_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef c9_struct_c9_tag_23YJI910RYCWhAsXw5RjrG
#define c9_struct_c9_tag_23YJI910RYCWhAsXw5RjrG

struct c9_tag_23YJI910RYCWhAsXw5RjrG
{
  c9_cell_15 _data;
};

#endif                                 /* c9_struct_c9_tag_23YJI910RYCWhAsXw5RjrG */

#ifndef c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG
#define c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG

typedef struct c9_tag_23YJI910RYCWhAsXw5RjrG c9_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* c9_typedef_c9_s_23YJI910RYCWhAsXw5RjrG */

#ifndef c9_struct_c9_tag_i3ZGqykvgqQLsMCH6x4OBH
#define c9_struct_c9_tag_i3ZGqykvgqQLsMCH6x4OBH

struct c9_tag_i3ZGqykvgqQLsMCH6x4OBH
{
  c9_cell_16 _data;
};

#endif                                 /* c9_struct_c9_tag_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH
#define c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c9_tag_i3ZGqykvgqQLsMCH6x4OBH c9_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* c9_typedef_c9_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c9_struct_c9_tag_u4ui3JwwaZ1jYzDQeNl7gB
#define c9_struct_c9_tag_u4ui3JwwaZ1jYzDQeNl7gB

struct c9_tag_u4ui3JwwaZ1jYzDQeNl7gB
{
  c9_cell_18 _data;
};

#endif                                 /* c9_struct_c9_tag_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB
#define c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c9_tag_u4ui3JwwaZ1jYzDQeNl7gB c9_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* c9_typedef_c9_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef c9_struct_c9_tag_lv60kHidgCVN68cHDjBCkF
#define c9_struct_c9_tag_lv60kHidgCVN68cHDjBCkF

struct c9_tag_lv60kHidgCVN68cHDjBCkF
{
  c9_cell_19 _data;
};

#endif                                 /* c9_struct_c9_tag_lv60kHidgCVN68cHDjBCkF */

#ifndef c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF
#define c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF

typedef struct c9_tag_lv60kHidgCVN68cHDjBCkF c9_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* c9_typedef_c9_s_lv60kHidgCVN68cHDjBCkF */

#ifndef c9_struct_c9_tag_MQfHiYk2RSY7P6gdFv6fDB
#define c9_struct_c9_tag_MQfHiYk2RSY7P6gdFv6fDB

struct c9_tag_MQfHiYk2RSY7P6gdFv6fDB
{
  c9_cell_20 _data;
};

#endif                                 /* c9_struct_c9_tag_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB
#define c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB

typedef struct c9_tag_MQfHiYk2RSY7P6gdFv6fDB c9_s_MQfHiYk2RSY7P6gdFv6fDB;

#endif                                 /* c9_typedef_c9_s_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef c9_struct_c9_tag_zyomqXisN60TlgNyBJHFGG
#define c9_struct_c9_tag_zyomqXisN60TlgNyBJHFGG

struct c9_tag_zyomqXisN60TlgNyBJHFGG
{
  c9_cell_21 _data;
};

#endif                                 /* c9_struct_c9_tag_zyomqXisN60TlgNyBJHFGG */

#ifndef c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG
#define c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG

typedef struct c9_tag_zyomqXisN60TlgNyBJHFGG c9_s_zyomqXisN60TlgNyBJHFGG;

#endif                                 /* c9_typedef_c9_s_zyomqXisN60TlgNyBJHFGG */

#ifndef c9_struct_c9_tag_7xbvANdg7KAufDVBBSkgZE
#define c9_struct_c9_tag_7xbvANdg7KAufDVBBSkgZE

struct c9_tag_7xbvANdg7KAufDVBBSkgZE
{
  c9_cell_22 _data;
};

#endif                                 /* c9_struct_c9_tag_7xbvANdg7KAufDVBBSkgZE */

#ifndef c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE
#define c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE

typedef struct c9_tag_7xbvANdg7KAufDVBBSkgZE c9_s_7xbvANdg7KAufDVBBSkgZE;

#endif                                 /* c9_typedef_c9_s_7xbvANdg7KAufDVBBSkgZE */

#ifndef c9_struct_c9_tag_FT1dThmKyyOBY5mTNhhCiC
#define c9_struct_c9_tag_FT1dThmKyyOBY5mTNhhCiC

struct c9_tag_FT1dThmKyyOBY5mTNhhCiC
{
  c9_cell_23 _data;
};

#endif                                 /* c9_struct_c9_tag_FT1dThmKyyOBY5mTNhhCiC */

#ifndef c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC
#define c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC

typedef struct c9_tag_FT1dThmKyyOBY5mTNhhCiC c9_s_FT1dThmKyyOBY5mTNhhCiC;

#endif                                 /* c9_typedef_c9_s_FT1dThmKyyOBY5mTNhhCiC */

#ifndef c9_struct_c9_tag_LiC67LW1mMO192u9sMnmMG
#define c9_struct_c9_tag_LiC67LW1mMO192u9sMnmMG

struct c9_tag_LiC67LW1mMO192u9sMnmMG
{
  c9_cell_24 _data;
};

#endif                                 /* c9_struct_c9_tag_LiC67LW1mMO192u9sMnmMG */

#ifndef c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG
#define c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG

typedef struct c9_tag_LiC67LW1mMO192u9sMnmMG c9_s_LiC67LW1mMO192u9sMnmMG;

#endif                                 /* c9_typedef_c9_s_LiC67LW1mMO192u9sMnmMG */

#ifndef c9_struct_c9_tag_MNdGPE827fhwyzcwIbJ2SF
#define c9_struct_c9_tag_MNdGPE827fhwyzcwIbJ2SF

struct c9_tag_MNdGPE827fhwyzcwIbJ2SF
{
  c9_cell_25 _data;
};

#endif                                 /* c9_struct_c9_tag_MNdGPE827fhwyzcwIbJ2SF */

#ifndef c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF
#define c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF

typedef struct c9_tag_MNdGPE827fhwyzcwIbJ2SF c9_s_MNdGPE827fhwyzcwIbJ2SF;

#endif                                 /* c9_typedef_c9_s_MNdGPE827fhwyzcwIbJ2SF */

#ifndef c9_struct_c9_tag_GvWTNEJOSSRh883m2SnETB
#define c9_struct_c9_tag_GvWTNEJOSSRh883m2SnETB

struct c9_tag_GvWTNEJOSSRh883m2SnETB
{
  c9_cell_26 _data;
};

#endif                                 /* c9_struct_c9_tag_GvWTNEJOSSRh883m2SnETB */

#ifndef c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB
#define c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB

typedef struct c9_tag_GvWTNEJOSSRh883m2SnETB c9_s_GvWTNEJOSSRh883m2SnETB;

#endif                                 /* c9_typedef_c9_s_GvWTNEJOSSRh883m2SnETB */

#ifndef c9_struct_c9_tag_Z2qSppxNoXb8Jppd82oq6F
#define c9_struct_c9_tag_Z2qSppxNoXb8Jppd82oq6F

struct c9_tag_Z2qSppxNoXb8Jppd82oq6F
{
  c9_cell_27 _data;
};

#endif                                 /* c9_struct_c9_tag_Z2qSppxNoXb8Jppd82oq6F */

#ifndef c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F
#define c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F

typedef struct c9_tag_Z2qSppxNoXb8Jppd82oq6F c9_s_Z2qSppxNoXb8Jppd82oq6F;

#endif                                 /* c9_typedef_c9_s_Z2qSppxNoXb8Jppd82oq6F */

#ifndef c9_struct_c9_tag_bfdw51ZQJqFWZgII8x0zkH
#define c9_struct_c9_tag_bfdw51ZQJqFWZgII8x0zkH

struct c9_tag_bfdw51ZQJqFWZgII8x0zkH
{
  c9_cell_28 _data;
};

#endif                                 /* c9_struct_c9_tag_bfdw51ZQJqFWZgII8x0zkH */

#ifndef c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH
#define c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH

typedef struct c9_tag_bfdw51ZQJqFWZgII8x0zkH c9_s_bfdw51ZQJqFWZgII8x0zkH;

#endif                                 /* c9_typedef_c9_s_bfdw51ZQJqFWZgII8x0zkH */

#ifndef c9_struct_c9_tag_Zk8dErMjLMrsJtNaWjimqH
#define c9_struct_c9_tag_Zk8dErMjLMrsJtNaWjimqH

struct c9_tag_Zk8dErMjLMrsJtNaWjimqH
{
  c9_cell_29 _data;
};

#endif                                 /* c9_struct_c9_tag_Zk8dErMjLMrsJtNaWjimqH */

#ifndef c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH
#define c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH

typedef struct c9_tag_Zk8dErMjLMrsJtNaWjimqH c9_s_Zk8dErMjLMrsJtNaWjimqH;

#endif                                 /* c9_typedef_c9_s_Zk8dErMjLMrsJtNaWjimqH */

#ifndef typedef_SFc9_flightControlSystemInstanceStruct
#define typedef_SFc9_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c9_sfEvent;
  boolean_T c9_doneDoubleBufferReInit;
  uint8_T c9_JITStateAnimation[1];
  uint8_T c9_JITTransitionAnimation[1];
  real_T c9_H[25740];
  real_T c9_hnew[25740];
  real_T c9_varargin_1[25740];
  CovrtStateflowInstance *c9_covrtInstance;
  void *c9_fEmlrtCtx;
  real_T (*c9_BWImage)[2400];
  real_T *c9_DegAngle;
} SFc9_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc9_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c9_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c9_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c9_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
