/* Include files */

#include "flightControlSystem_sfun.h"
#include "c1_flightControlSystem.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c1_emlrtMCI = { 13, /* lineNo */
  13,                                  /* colNo */
  "toLogicalCheck",                    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\toLogicalCheck.m"/* pName */
};

static emlrtMCInfo c1_b_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatenonnan",                    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatenonnan.m"/* pName */
};

static emlrtRSInfo c1_emlrtRSI = { 18, /* lineNo */
  "Image Processing System/MATLAB Function1",/* fcnName */
  "#flightControlSystem:2682"          /* pathName */
};

static emlrtRSInfo c1_b_emlrtRSI = { 19,/* lineNo */
  "Image Processing System/MATLAB Function1",/* fcnName */
  "#flightControlSystem:2682"          /* pathName */
};

static emlrtRSInfo c1_c_emlrtRSI = { 38,/* lineNo */
  "morphop_fast",                      /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\private\\morphop_fast.m"/* pathName */
};

static emlrtRSInfo c1_d_emlrtRSI = { 96,/* lineNo */
  "imdilate",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\imdilate.m"/* pathName */
};

static emlrtRSInfo c1_e_emlrtRSI = { 98,/* lineNo */
  "imdilate",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\imdilate.m"/* pathName */
};

static emlrtRSInfo c1_f_emlrtRSI = { 17,/* lineNo */
  "morphop",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\morphop.m"/* pathName */
};

static emlrtRSInfo c1_g_emlrtRSI = { 22,/* lineNo */
  "morphop",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphop.m"/* pathName */
};

static emlrtRSInfo c1_h_emlrtRSI = { 15,/* lineNo */
  "morphopConstantFoldingImpl",        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphopConstantFoldingImpl.m"/* pathName */
};

static emlrtRSInfo c1_i_emlrtRSI = { 487,/* lineNo */
  "morphopConstantFoldingImpl",        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphopConstantFoldingImpl.m"/* pathName */
};

static emlrtRSInfo c1_j_emlrtRSI = { 13,/* lineNo */
  "morphopInputParser",                /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphopInputParser.m"/* pathName */
};

static emlrtRSInfo c1_k_emlrtRSI = { 61,/* lineNo */
  "morphopInputParser",                /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphopInputParser.m"/* pathName */
};

static emlrtRSInfo c1_l_emlrtRSI = { 93,/* lineNo */
  "validateattributes",                /* fcnName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"/* pathName */
};

static emlrtRSInfo c1_m_emlrtRSI = { 691,/* lineNo */
  "morphopConstantFoldingImpl",        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\+coder\\morphopConstantFoldingImpl.m"/* pathName */
};

static emlrtRSInfo c1_n_emlrtRSI = { 85,/* lineNo */
  "imerode",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\imerode.m"/* pathName */
};

static emlrtRSInfo c1_o_emlrtRSI = { 87,/* lineNo */
  "imerode",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\imerode.m"/* pathName */
};

static char_T c1_cv[19] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'n', 'o', 'l',
  'o', 'g', 'i', 'c', 'a', 'l', 'n', 'a', 'n' };

static char_T c1_cv1[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
  'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't', 'r',
  'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'N', 'o',
  'n', 'N', 'a', 'N' };

static char_T c1_cv2[19] = { 'i', 'n', 'p', 'u', 't', ' ', 'n', 'u', 'm', 'b',
  'e', 'r', ' ', '1', ',', ' ', 'I', 'M', ',' };

/* Function Declarations */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st);
static void c1_imerode(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_A[19200], real_T c1_c_B[19200]);
static void c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_nullptr, const char_T *c1_identifier, real_T
  c1_y[19200]);
static void c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId,
  real_T c1_y[19200]);
static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  emlrtLicenseCheckR2022a(&c1_st, "EMLRT:runTime:MexFunctionNeedsLicense",
    "image_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c1_doneDoubleBufferReInit = false;
  chartInstance->c1_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
}

static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static const uint32_T c1_decisionTxtEndIdx = 0U;
  static const uint32_T c1_decisionTxtStartIdx = 0U;
  sfSetAnimationVectors(chartInstance->S, &chartInstance->c1_JITStateAnimation[0],
                        &chartInstance->c1_JITTransitionAnimation[0]);
  covrtCreateStateflowInstanceData(chartInstance->c1_covrtInstance, 1U, 0U, 1U,
    46U);
  covrtChartInitFcn(chartInstance->c1_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c1_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c1_decisionTxtStartIdx, &c1_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c1_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c1_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c1_covrtInstance, 4U, 0U, 0U,
                     "c1_flightControlSystem", 0, -1, 628);
}

static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  covrtDeleteStateflowInstanceData(chartInstance->c1_covrtInstance);
}

static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static char_T c1_b_cv[30] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'i', 'm', 'd',
    'i', 'l', 'a', 't', 'e', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'N',
    'o', 'n', 'N', 'a', 'N' };

  emlrtStack c1_b_st;
  emlrtStack c1_c_st;
  emlrtStack c1_d_st;
  emlrtStack c1_e_st;
  emlrtStack c1_f_st;
  emlrtStack c1_g_st;
  emlrtStack c1_h_st;
  emlrtStack c1_i_st;
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_b_dv[19200];
  real_T c1_asizeT[2];
  real_T c1_nsizeT[2];
  real_T c1_b_x;
  real_T c1_c_k;
  real_T c1_c_x;
  real_T c1_x;
  int32_T c1_b_k;
  int32_T c1_i;
  int32_T c1_i1;
  int32_T c1_i10;
  int32_T c1_i11;
  int32_T c1_i12;
  int32_T c1_i13;
  int32_T c1_i2;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_i8;
  int32_T c1_i9;
  int32_T c1_k;
  boolean_T c1_b_redMask[19200];
  boolean_T c1_bv[19200];
  boolean_T c1_nhood[9];
  boolean_T c1_b;
  boolean_T c1_b_b;
  boolean_T c1_b_p;
  boolean_T c1_c_b;
  boolean_T c1_exitg1;
  boolean_T c1_p;
  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_c_st.prev = &c1_b_st;
  c1_c_st.tls = c1_b_st.tls;
  c1_d_st.prev = &c1_c_st;
  c1_d_st.tls = c1_c_st.tls;
  c1_e_st.prev = &c1_d_st;
  c1_e_st.tls = c1_d_st.tls;
  c1_f_st.prev = &c1_e_st;
  c1_f_st.tls = c1_e_st.tls;
  c1_g_st.prev = &c1_f_st;
  c1_g_st.tls = c1_f_st.tls;
  c1_h_st.prev = &c1_g_st;
  c1_h_st.tls = c1_g_st.tls;
  c1_i_st.prev = &c1_h_st;
  c1_i_st.tls = c1_h_st.tls;
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 2U, (real_T)
                      (*chartInstance->c1_b_B)[c1_i]);
  }

  for (c1_i1 = 0; c1_i1 < 19200; c1_i1++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 1U, (real_T)
                      (*chartInstance->c1_G)[c1_i1]);
  }

  for (c1_i2 = 0; c1_i2 < 19200; c1_i2++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 0U, (real_T)
                      (*chartInstance->c1_R)[c1_i2]);
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c1_JITTransitionAnimation[0] = 0U;
  chartInstance->c1_sfEvent = CALL_EVENT;
  covrtEmlFcnEval(chartInstance->c1_covrtInstance, 4U, 0, 0);
  for (c1_i3 = 0; c1_i3 < 19200; c1_i3++) {
    c1_b_redMask[c1_i3] = ((*chartInstance->c1_R)[c1_i3] > 100);
  }

  for (c1_i4 = 0; c1_i4 < 19200; c1_i4++) {
    c1_bv[c1_i4] = ((*chartInstance->c1_G)[c1_i4] < 80);
  }

  for (c1_i5 = 0; c1_i5 < 19200; c1_i5++) {
    c1_b_redMask[c1_i5] = (c1_b_redMask[c1_i5] && c1_bv[c1_i5]);
  }

  for (c1_i6 = 0; c1_i6 < 19200; c1_i6++) {
    c1_bv[c1_i6] = ((*chartInstance->c1_b_B)[c1_i6] < 80);
  }

  for (c1_i7 = 0; c1_i7 < 19200; c1_i7++) {
    c1_b_redMask[c1_i7] = (c1_b_redMask[c1_i7] && c1_bv[c1_i7]);
  }

  for (c1_i8 = 0; c1_i8 < 19200; c1_i8++) {
    chartInstance->c1_redMask[c1_i8] = (real_T)c1_b_redMask[c1_i8];
  }

  c1_b_st.site = &c1_emlrtRSI;
  c1_c_st.site = &c1_d_emlrtRSI;
  c1_d_st.site = &c1_c_emlrtRSI;
  for (c1_k = 0; c1_k < 9; c1_k++) {
    c1_x = 1.0;
    c1_b = muDoubleScalarIsNaN(c1_x);
    if (c1_b) {
      c1_y = NULL;
      sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1, 0U, 2, 1, 19),
                    false);
      c1_b_y = NULL;
      sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv, 10, 0U, 1, 0U, 2, 1, 19),
                    false);
      sf_mex_call(&c1_d_st, &c1_emlrtMCI, "error", 0U, 2U, 14, c1_y, 14,
                  sf_mex_call(&c1_d_st, NULL, "getString", 1U, 1U, 14,
        sf_mex_call(&c1_d_st, NULL, "message", 1U, 1U, 14, c1_b_y)));
    }
  }

  c1_c_st.site = &c1_e_emlrtRSI;
  c1_d_st.site = &c1_f_emlrtRSI;
  c1_e_st.site = &c1_g_emlrtRSI;
  c1_f_st.site = &c1_h_emlrtRSI;
  c1_g_st.site = &c1_j_emlrtRSI;
  c1_h_st.site = &c1_k_emlrtRSI;
  c1_i_st.site = &c1_l_emlrtRSI;
  c1_p = true;
  c1_b_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_b_k < 19200)) {
    c1_c_k = 1.0 + (real_T)c1_b_k;
    c1_b_x = chartInstance->c1_redMask[(int32_T)c1_c_k - 1];
    c1_c_x = c1_b_x;
    c1_c_b = muDoubleScalarIsNaN(c1_c_x);
    c1_b_p = !c1_c_b;
    if (c1_b_p) {
      c1_b_k++;
    } else {
      c1_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_p) {
    c1_b_b = true;
  } else {
    c1_b_b = false;
  }

  if (!c1_b_b) {
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1, 0U, 2, 1, 30),
                  false);
    c1_d_y = NULL;
    sf_mex_assign(&c1_d_y, sf_mex_create("y", c1_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c1_e_y = NULL;
    sf_mex_assign(&c1_e_y, sf_mex_create("y", c1_cv2, 10, 0U, 1, 0U, 2, 1, 19),
                  false);
    sf_mex_call(&c1_i_st, &c1_b_emlrtMCI, "error", 0U, 2U, 14, c1_c_y, 14,
                sf_mex_call(&c1_i_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_i_st, NULL, "message", 1U, 2U, 14, c1_d_y, 14, c1_e_y)));
  }

  c1_f_st.site = &c1_i_emlrtRSI;
  c1_g_st.site = &c1_m_emlrtRSI;
  for (c1_i9 = 0; c1_i9 < 9; c1_i9++) {
    c1_nhood[c1_i9] = true;
  }

  for (c1_i10 = 0; c1_i10 < 2; c1_i10++) {
    c1_asizeT[c1_i10] = 120.0 + 40.0 * (real_T)c1_i10;
  }

  for (c1_i11 = 0; c1_i11 < 2; c1_i11++) {
    c1_nsizeT[c1_i11] = 3.0;
  }

  dilate_flat_real64_tbb(&chartInstance->c1_redMask[0], &c1_asizeT[0], 2.0,
    &c1_nhood[0], &c1_nsizeT[0], 2.0, &chartInstance->c1_B[0]);
  c1_b_st.site = &c1_b_emlrtRSI;
  c1_imerode(chartInstance, &c1_b_st, chartInstance->c1_B, c1_b_dv);
  for (c1_i12 = 0; c1_i12 < 19200; c1_i12++) {
    (*chartInstance->c1_binaryImage)[c1_i12] = c1_b_dv[c1_i12];
  }

  for (c1_i13 = 0; c1_i13 < 19200; c1_i13++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 3U,
                      (*chartInstance->c1_binaryImage)[c1_i13]);
  }
}

static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_st = NULL;
  const mxArray *c1_y = NULL;
  c1_st = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_createcellmatrix(1, 1), false);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", *chartInstance->c1_binaryImage, 0,
    0U, 1, 0U, 2, 120, 160), false);
  sf_mex_setcell(c1_y, 0, c1_b_y);
  sf_mex_assign(&c1_st, c1_y, false);
  return c1_st;
}

static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st)
{
  const mxArray *c1_u;
  int32_T c1_i;
  chartInstance->c1_doneDoubleBufferReInit = true;
  c1_u = sf_mex_dup(c1_st);
  c1_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 0)),
                      "binaryImage", chartInstance->c1_dv);
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    (*chartInstance->c1_binaryImage)[c1_i] = chartInstance->c1_dv[c1_i];
  }

  sf_mex_destroy(&c1_u);
  sf_mex_destroy(&c1_st);
}

static void c1_imerode(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_A[19200], real_T c1_c_B[19200])
{
  static char_T c1_b_cv[29] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'i', 'm', 'e',
    'r', 'o', 'd', 'e', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'N', 'o',
    'n', 'N', 'a', 'N' };

  emlrtStack c1_b_st;
  emlrtStack c1_c_st;
  emlrtStack c1_d_st;
  emlrtStack c1_e_st;
  emlrtStack c1_f_st;
  emlrtStack c1_g_st;
  emlrtStack c1_st;
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_asizeT[2];
  real_T c1_nsizeT[2];
  real_T c1_b_x;
  real_T c1_c_k;
  real_T c1_c_x;
  real_T c1_x;
  int32_T c1_b_k;
  int32_T c1_i;
  int32_T c1_i1;
  int32_T c1_i2;
  int32_T c1_k;
  boolean_T c1_nhood[9];
  boolean_T c1_b;
  boolean_T c1_b_b;
  boolean_T c1_b_p;
  boolean_T c1_c_b;
  boolean_T c1_exitg1;
  boolean_T c1_p;
  (void)chartInstance;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_c_st.prev = &c1_b_st;
  c1_c_st.tls = c1_b_st.tls;
  c1_d_st.prev = &c1_c_st;
  c1_d_st.tls = c1_c_st.tls;
  c1_e_st.prev = &c1_d_st;
  c1_e_st.tls = c1_d_st.tls;
  c1_f_st.prev = &c1_e_st;
  c1_f_st.tls = c1_e_st.tls;
  c1_g_st.prev = &c1_f_st;
  c1_g_st.tls = c1_f_st.tls;
  c1_st.site = &c1_n_emlrtRSI;
  c1_b_st.site = &c1_c_emlrtRSI;
  for (c1_k = 0; c1_k < 9; c1_k++) {
    c1_x = 1.0;
    c1_b = muDoubleScalarIsNaN(c1_x);
    if (c1_b) {
      c1_y = NULL;
      sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1, 0U, 2, 1, 19),
                    false);
      c1_b_y = NULL;
      sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv, 10, 0U, 1, 0U, 2, 1, 19),
                    false);
      sf_mex_call(&c1_b_st, &c1_emlrtMCI, "error", 0U, 2U, 14, c1_y, 14,
                  sf_mex_call(&c1_b_st, NULL, "getString", 1U, 1U, 14,
        sf_mex_call(&c1_b_st, NULL, "message", 1U, 1U, 14, c1_b_y)));
    }
  }

  c1_st.site = &c1_o_emlrtRSI;
  c1_b_st.site = &c1_f_emlrtRSI;
  c1_c_st.site = &c1_g_emlrtRSI;
  c1_d_st.site = &c1_h_emlrtRSI;
  c1_e_st.site = &c1_j_emlrtRSI;
  c1_f_st.site = &c1_k_emlrtRSI;
  c1_g_st.site = &c1_l_emlrtRSI;
  c1_p = true;
  c1_b_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_b_k < 19200)) {
    c1_c_k = 1.0 + (real_T)c1_b_k;
    c1_b_x = c1_A[(int32_T)c1_c_k - 1];
    c1_c_x = c1_b_x;
    c1_c_b = muDoubleScalarIsNaN(c1_c_x);
    c1_b_p = !c1_c_b;
    if (c1_b_p) {
      c1_b_k++;
    } else {
      c1_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_p) {
    c1_b_b = true;
  } else {
    c1_b_b = false;
  }

  if (!c1_b_b) {
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1, 0U, 2, 1, 29),
                  false);
    c1_d_y = NULL;
    sf_mex_assign(&c1_d_y, sf_mex_create("y", c1_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c1_e_y = NULL;
    sf_mex_assign(&c1_e_y, sf_mex_create("y", c1_cv2, 10, 0U, 1, 0U, 2, 1, 19),
                  false);
    sf_mex_call(&c1_g_st, &c1_b_emlrtMCI, "error", 0U, 2U, 14, c1_c_y, 14,
                sf_mex_call(&c1_g_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_g_st, NULL, "message", 1U, 2U, 14, c1_d_y, 14, c1_e_y)));
  }

  c1_d_st.site = &c1_i_emlrtRSI;
  c1_e_st.site = &c1_m_emlrtRSI;
  for (c1_i = 0; c1_i < 9; c1_i++) {
    c1_nhood[c1_i] = true;
  }

  for (c1_i1 = 0; c1_i1 < 2; c1_i1++) {
    c1_asizeT[c1_i1] = 120.0 + 40.0 * (real_T)c1_i1;
  }

  for (c1_i2 = 0; c1_i2 < 2; c1_i2++) {
    c1_nsizeT[c1_i2] = 3.0;
  }

  erode_flat_real64_tbb(&c1_A[0], &c1_asizeT[0], 2.0, &c1_nhood[0], &c1_nsizeT[0],
                        2.0, &c1_c_B[0]);
}

const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info(void)
{
  const mxArray *c1_nameCaptureInfo = NULL;
  c1_nameCaptureInfo = NULL;
  sf_mex_assign(&c1_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1, 0U, 2, 0, 1), false);
  return c1_nameCaptureInfo;
}

static void c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_nullptr, const char_T *c1_identifier, real_T
  c1_y[19200])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char_T *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_nullptr), &c1_thisId, c1_y);
  sf_mex_destroy(&c1_nullptr);
}

static void c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId,
  real_T c1_y[19200])
{
  real_T c1_b_dv[19200];
  int32_T c1_i;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_b_dv, 1, 0, 0U, 1, 0U, 2, 120,
                160);
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    c1_y[c1_i] = c1_b_dv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  chartInstance->c1_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c1_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c1_R = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c1_binaryImage = (real_T (*)[19200])
    ssGetOutputPortSignal_wrapper(chartInstance->S, 1);
  chartInstance->c1_G = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c1_b_B = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2743249712U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(998475317U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3969543205U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1176795377U);
}

mxArray *sf_c1_flightControlSystem_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,1);
  mxSetCell(mxcell3p, 0, mxCreateString(
             "images.internal.coder.buildable.Morphop_flat_tbb_Buildable"));
  return(mxcell3p);
}

mxArray *sf_c1_flightControlSystem_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("dilate_flat_real64_tbb");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c1_flightControlSystem_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c1_flightControlSystem(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiDWYGRgYAPSHEDMxAABrFA+IxKGiLPAxRWAuKSyIBUkXlyU7JkCpPMSc8H8xNI"
    "Kz7y0fLD5FgwI89kImM8JFYeAD/aU6RdxAOl3QNLPgkU/N5J+ASg/KTMvsajSMzcxHewdsD9AAA"
    "BXthDX"
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c1_flightControlSystem_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sSiFV2H3usyO00qK3IAZt8D";
}

static void sf_opaque_initialize_c1_flightControlSystem(void *chartInstanceVar)
{
  initialize_params_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
  initialize_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c1_flightControlSystem(void *chartInstanceVar)
{
  enable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c1_flightControlSystem(void *chartInstanceVar)
{
  disable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c1_flightControlSystem(void *chartInstanceVar)
{
  sf_gateway_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c1_flightControlSystem(SimStruct*
  S)
{
  return get_sim_state_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c1_flightControlSystem(SimStruct* S, const
  mxArray *st)
{
  set_sim_state_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_cleanup_runtime_resources_c1_flightControlSystem(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_flightControlSystem_optimization_info();
    }

    mdl_cleanup_runtime_resources_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c1_flightControlSystem(void *chartInstanceVar)
{
  mdl_start_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
  if (chartInstanceVar) {
    sf_reset_warnings_ChartRunTimeInfo(((SFc1_flightControlSystemInstanceStruct*)
      chartInstanceVar)->S);
  }
}

static void sf_opaque_mdl_terminate_c1_flightControlSystem(void
  *chartInstanceVar)
{
  mdl_terminate_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c1_flightControlSystem(SimStruct *S)
{
  mdlProcessParamsCommon(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*)sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c1_flightControlSystem_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [21] = {
    "eNrdWMtuI0UULSchYpiHBgkxSCDBkg1SZiykWSCYjB+MRUws2gnSbKDcfdtdSnVVpx52zII938A",
    "v8DPsRnwCC8QSdtxqtx3LNnZXG5RAS53ObfvUvXX63Eeb1DpdgscDPL99RMghXl/Hc49Mj9cKu7",
    "ZwTu8fkE8Ku/cGIWFClemIWBL/I5QRDEEENo7ZlSdW2LRHFU11Bb+CpvAVaMmtYVL4Bc9EDApEi",
    "AtkUhkvv5qlljNx0bYidJ711wkLkyCRlkfPcUEanQo++Tu/mTU99NhkCkLTBohMoqQdJm1Oh5tZ",
    "UGbcSCC80Db15kqDCWzmtqq7lhuWcWhdQdgR2lBkQW/Zb2CogYa58lYI08EMLdOMMyrKc51QHUC",
    "G6jBwlkX499QaZK+kX/Q3YIIaqRjlrZQ3nMJLYnsc4+yirLk3zyY1TRjY4ZCJoWNX2RQE7h91Uo",
    "KruCFHoOgQToVnDrrdta7yBzzXZfkc7DhZVspBm06fiq6Ezf22RsiQrui3HYoG5Vz7YfsyO4ER8",
    "Nx/kxpaATv17wHWmkV9eU6VywLPTLKCXVoosA0pIlb+CY+WUHnB/RKLZwk4S52kIEKa56HPF9qm",
    "SauNTBuYRs2Tk5L+VrEdYUDFNITStU9RpgEDznXl6Tdimg64QyNLJt9l6RVAVIYSHVvRHEt1gRz",
    "7Ftlrrlwm+KEhGkITDOQFo4XqPqfclow51VjhnDzONFYsP7+IdflTCRzSMIHI9RPGoQvaLaBL12",
    "fsI8e42xEzkyboULGsbCZZDRE2EsdSf5LBmbgQcizaSqZBMRFs0BUAVg2qBLaF59iW1KSNwZeLW",
    "sFl3ymryniWUsPpwGnjcxDYWdxeXSekIWZVS+DohgHtgg3Yd9jahWba4Dg1aeU5EOXz6Ds1v3n0",
    "zcKuz3Opo/sKnxTFNixwUjoe5MMe9FkK+Y2A4kwxNYvD+T0i137v7G32u4f/1SriyI64Fwu4gzX",
    "8vL2Ae1jY4eNvYs6GiSvCRkkeTJD3dDWOeyX4Xhf/Mo6s4K55nl0/XMDX1vglC9dtfO2v8LVPar",
    "Vajnu2gLu/5OdgCXdYcPbzD7/+cvLbn90fW3ffPfjp+/u76OOVp54fFPZ7s/ls3sFGK0W+jB4eL",
    "enB2Thet8+fvKhbPTk9Orr8ot45fmmeNqfPxTPe2f0P8DRY4PJ6qcJOVLxrOZva6TuAW//pQryH",
    "W9a/s6AnQn7/bDf8W8+W9bCOr7tLfDl7kNfeTootY0XHt71u3FSdusk4y9Sx/Yq4Gvn36uY/idt",
    "1f771+b/+/aMNdYEsff/hLd7Hpvrk06dv275eEb++9H5hfzp/h24kjEdrpvjiYxy043Wf/k/0/Y",
    "cnf7O5oeX4K34EfFk/FpRPcGyfvhYVt3vK/f40/0gB1evfjW6iD82u2/r+vaX8dvaYiUiO9UePn",
    "3xc36Wv/QVU1ARN",
    ""
  };

  static char newstr [1441] = "";
  newstr[0] = '\0';
  for (i = 0; i < 21; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c1_flightControlSystem(SimStruct *S)
{
  const char* newstr = sf_c1_flightControlSystem_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(3672803793U));
  ssSetChecksum1(S,(1308225100U));
  ssSetChecksum2(S,(453723547U));
  ssSetChecksum3(S,(226405380U));
}

static void mdlRTW_c1_flightControlSystem(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c1_flightControlSystem(SimStruct *S)
{
  SFc1_flightControlSystemInstanceStruct *chartInstance;
  chartInstance = (SFc1_flightControlSystemInstanceStruct *)utMalloc(sizeof
    (SFc1_flightControlSystemInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc1_flightControlSystemInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c1_flightControlSystem;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c1_flightControlSystem;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c1_flightControlSystem;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c1_flightControlSystem;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c1_flightControlSystem;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c1_flightControlSystem;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c1_flightControlSystem;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c1_flightControlSystem;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c1_flightControlSystem;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c1_flightControlSystem;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c1_flightControlSystem(chartInstance);
}

void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c1_flightControlSystem(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c1_flightControlSystem_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
