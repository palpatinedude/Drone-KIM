/* Include files */

#include "flightControlSystem_sfun.h"
#include "c9_flightControlSystem.h"
#include <string.h>
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c9_emlrtMCI = { 13, /* lineNo */
  9,                                   /* colNo */
  "sqrt",                              /* fName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\elfun\\sqrt.m"/* pName */
};

static emlrtMCInfo c9_b_emlrtMCI = { 13,/* lineNo */
  13,                                  /* colNo */
  "toLogicalCheck",                    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\toLogicalCheck.m"/* pName */
};

static emlrtMCInfo c9_c_emlrtMCI = { 87,/* lineNo */
  33,                                  /* colNo */
  "eml_int_forloop_overflow_check",    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pName */
};

static emlrtMCInfo c9_d_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatefinite",                    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatefinite.m"/* pName */
};

static emlrtMCInfo c9_e_emlrtMCI = { 13,/* lineNo */
  37,                                  /* colNo */
  "validateinteger",                   /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validateinteger.m"/* pName */
};

static emlrtMCInfo c9_f_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatenonnan",                    /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatenonnan.m"/* pName */
};

static emlrtMCInfo c9_g_emlrtMCI = { 454,/* lineNo */
  5,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtMCInfo c9_h_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatepositive",                  /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatepositive.m"/* pName */
};

static emlrtMCInfo c9_i_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validateodd",                       /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validateodd.m"/* pName */
};

static emlrtMCInfo c9_j_emlrtMCI = { 474,/* lineNo */
  1,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtMCInfo c9_k_emlrtMCI = { 21,/* lineNo */
  15,                                  /* colNo */
  "ind2sub",                           /* fName */
  "D:\\MATLAB\\toolbox\\eml\\eml\\+coder\\+internal\\ind2sub.m"/* pName */
};

static emlrtRSInfo c9_emlrtRSI = { 3,  /* lineNo */
  "Image Processing System/MATLAB Function8",/* fcnName */
  "#flightControlSystem:2696"          /* pathName */
};

static emlrtRSInfo c9_b_emlrtRSI = { 6,/* lineNo */
  "Image Processing System/MATLAB Function8",/* fcnName */
  "#flightControlSystem:2696"          /* pathName */
};

static emlrtRSInfo c9_c_emlrtRSI = { 9,/* lineNo */
  "Image Processing System/MATLAB Function8",/* fcnName */
  "#flightControlSystem:2696"          /* pathName */
};

static emlrtRSInfo c9_d_emlrtRSI = { 117,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_e_emlrtRSI = { 133,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_f_emlrtRSI = { 139,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_g_emlrtRSI = { 743,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_h_emlrtRSI = { 744,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_i_emlrtRSI = { 749,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_j_emlrtRSI = { 750,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_k_emlrtRSI = { 115,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_l_emlrtRSI = { 127,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_m_emlrtRSI = { 814,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_n_emlrtRSI = { 888,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_o_emlrtRSI = { 962,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_p_emlrtRSI = { 990,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_q_emlrtRSI = { 1002,/* lineNo */
  "imfilter",                          /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c9_r_emlrtRSI = { 759,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_s_emlrtRSI = { 131,/* lineNo */
  "imhist",                            /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c9_t_emlrtRSI = { 166,/* lineNo */
  "imhist",                            /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c9_u_emlrtRSI = { 452,/* lineNo */
  "imhist",                            /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c9_v_emlrtRSI = { 14,/* lineNo */
  "warning",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\shared\\coder\\coder\\lib\\+coder\\+internal\\warning.m"/* pathName */
};

static emlrtRSInfo c9_w_emlrtRSI = { 799,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_x_emlrtRSI = { 805,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_y_emlrtRSI = { 909,/* lineNo */
  "edge",                              /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c9_ab_emlrtRSI = { 40,/* lineNo */
  "imreconstruct",                     /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imreconstruct.m"/* pathName */
};

static emlrtRSInfo c9_bb_emlrtRSI = { 78,/* lineNo */
  "imreconstruct",                     /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\imreconstruct.m"/* pathName */
};

static emlrtRSInfo c9_cb_emlrtRSI = { 27,/* lineNo */
  "getBinaryConnectivityMatrix",       /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\+images\\+internal\\getBinaryConnectivityMatrix.m"/* pathName */
};

static emlrtRSInfo c9_db_emlrtRSI = { 60,/* lineNo */
  "hough",                             /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\hough.m"/* pathName */
};

static emlrtRSInfo c9_eb_emlrtRSI = { 290,/* lineNo */
  "hough",                             /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\hough.m"/* pathName */
};

static emlrtRSInfo c9_fb_emlrtRSI = { 111,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_gb_emlrtRSI = { 61,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_hb_emlrtRSI = { 274,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_ib_emlrtRSI = { 317,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_jb_emlrtRSI = { 321,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_kb_emlrtRSI = { 324,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_lb_emlrtRSI = { 93,/* lineNo */
  "validateattributes",                /* fcnName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"/* pathName */
};

static emlrtRSInfo c9_mb_emlrtRSI = { 427,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_nb_emlrtRSI = { 439,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_ob_emlrtRSI = { 474,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_pb_emlrtRSI = { 463,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c9_qb_emlrtRSI = { 19,/* lineNo */
  "ind2sub",                           /* fcnName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\elmat\\ind2sub.m"/* pathName */
};

static emlrtRTEInfo c9_emlrtRTEI = { 774,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c9_b_emlrtRTEI = { 775,/* lineNo */
  37,                                  /* colNo */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c9_c_emlrtRTEI = { 76,/* lineNo */
  9,                                   /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "D:\\MATLAB\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo c9_d_emlrtRTEI = { 775,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c9_e_emlrtRTEI = { 771,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c9_f_emlrtRTEI = { 772,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c9_g_emlrtRTEI = { 191,/* lineNo */
  5,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtRTEInfo c9_h_emlrtRTEI = { 187,/* lineNo */
  5,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtBCInfo c9_emlrtBCI = { 1,  /* iFirst */
  40,                                  /* iLast */
  348,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "hough",                             /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\hough.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c9_b_emlrtBCI = { 1,/* iFirst */
  143,                                 /* iLast */
  301,                                 /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "hough",                             /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\hough.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c9_c_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  804,                                 /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_d_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  799,                                 /* lineNo */
  70,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_e_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  143,                                 /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_f_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  142,                                 /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_g_emlrtBCI = { 1,/* iFirst */
  180,                                 /* iLast */
  12,                                  /* lineNo */
  22,                                  /* colNo */
  "theta",                             /* aName */
  "Image Processing System/MATLAB Function8",/* fName */
  "#flightControlSystem:2696",         /* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c9_emlrtDCI = { 12, /* lineNo */
  22,                                  /* colNo */
  "Image Processing System/MATLAB Function8",/* fName */
  "#flightControlSystem:2696",         /* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c9_h_emlrtBCI = { 1,/* iFirst */
  40,                                  /* iLast */
  156,                                 /* lineNo */
  36,                                  /* colNo */
  "",                                  /* aName */
  "padarray",                          /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\padarray.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_i_emlrtBCI = { 1,/* iFirst */
  60,                                  /* iLast */
  156,                                 /* lineNo */
  47,                                  /* colNo */
  "",                                  /* aName */
  "padarray",                          /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\padarray.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_j_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  12,                                  /* lineNo */
  28,                                  /* colNo */
  "peaks",                             /* aName */
  "Image Processing System/MATLAB Function8",/* fName */
  "#flightControlSystem:2696",         /* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c9_k_emlrtBCI = { 1,/* iFirst */
  1,                                   /* iLast */
  122,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c9_l_emlrtBCI = { 1,/* iFirst */
  143,                                 /* iLast */
  119,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "houghpeaks",                        /* fName */
  "D:\\MATLAB\\toolbox\\images\\images\\eml\\houghpeaks.m",/* pName */
  0                                    /* checkKind */
};

static char_T c9_cv[32] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o', 'u',
  'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
  'F', 'i', 'n', 'i', 't', 'e' };

static char_T c9_cv1[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
  'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't', 'r',
  'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'F', 'i',
  'n', 'i', 't', 'e' };

/* Function Declarations */
static void initialize_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void initialize_params_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void mdl_start_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void mdl_terminate_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void enable_c9_flightControlSystem(SFc9_flightControlSystemInstanceStruct
  *chartInstance);
static void disable_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void sf_gateway_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void ext_mode_exec_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void c9_update_jit_animation_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void c9_do_animation_call_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance);
static void set_sim_state_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance, const mxArray *c9_st);
static void c9_warning(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp);
static void c9_houghpeaks(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp, real_T c9_b_varargin_1[25740], real_T c9_peaks_data[],
  int32_T c9_peaks_size[2]);
static void c9_validateattributes(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c9_sp, real_T c9_a[25740]);
static void c9_b_validateattributes(SFc9_flightControlSystemInstanceStruct
  *chartInstance);
static real_T c9_sumColumnB(SFc9_flightControlSystemInstanceStruct
  *chartInstance, real_T c9_x[178]);
static real_T c9_emlrt_marshallIn(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c9_nullptr, const char_T *c9_identifier);
static real_T c9_b_emlrt_marshallIn(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c9_u, const emlrtMsgIdentifier *c9_parentId);
static const mxArray *c9_feval(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c9_sp, const mxArray *c9_input0, const
  mxArray *c9_input1);
static void c9_b_feval(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp, const mxArray *c9_input0, const mxArray *c9_input1);
static int32_T c9__s32_s64_(SFc9_flightControlSystemInstanceStruct
  *chartInstance, int64_T c9_b, int32_T c9_EMLOvCount_src_loc, uint32_T
  c9_ssid_src_loc, int32_T c9_offset_src_loc, int32_T c9_length_src_loc);
static void init_dsm_address_info(SFc9_flightControlSystemInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc9_flightControlSystemInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  emlrtStack c9_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c9_st.tls = chartInstance->c9_fEmlrtCtx;
  emlrtLicenseCheckR2022a(&c9_st, "EMLRT:runTime:MexFunctionNeedsLicense",
    "image_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c9_doneDoubleBufferReInit = false;
  chartInstance->c9_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void initialize_params_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
}

static void mdl_terminate_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  static const uint32_T c9_decisionTxtEndIdx = 0U;
  static const uint32_T c9_decisionTxtStartIdx = 0U;
  sfSetAnimationVectors(chartInstance->S, &chartInstance->c9_JITStateAnimation[0],
                        &chartInstance->c9_JITTransitionAnimation[0]);
  covrtCreateStateflowInstanceData(chartInstance->c9_covrtInstance, 1U, 0U, 1U,
    44U);
  covrtChartInitFcn(chartInstance->c9_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c9_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c9_decisionTxtStartIdx, &c9_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c9_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c9_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  1U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c9_covrtInstance, 4U, 0U, 0U,
                     "c9_flightControlSystem", 0, -1, 408);
  covrtEmlSaturationInitFcn(chartInstance->c9_covrtInstance, 4U, 0U, 0U, 90, -1,
    112);
}

static void mdl_cleanup_runtime_resources_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  covrtDeleteStateflowInstanceData(chartInstance->c9_covrtInstance);
}

static void enable_c9_flightControlSystem(SFc9_flightControlSystemInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  static real_T c9_b_kernel[13] = { 0.0020299751839417137, 0.0102182810143517,
    0.058116735860084034, 0.19634433732941292, 0.37823877042972087,
    0.35505190018248872, 0.0, -0.35505190018248872, -0.37823877042972087,
    -0.19634433732941292, -0.058116735860084034, -0.0102182810143517,
    -0.0020299751839417137 };

  static real_T c9_c_kernel[13] = { 3.4813359214923059E-5,
    0.00054457256285105158, 0.0051667606200595222, 0.029732654490475543,
    0.10377716120747747, 0.21969625200024598, 0.28209557151935094,
    0.21969625200024598, 0.10377716120747747, 0.029732654490475543,
    0.0051667606200595222, 0.00054457256285105158, 3.4813359214923059E-5 };

  static real_T c9_d_kernel[13] = { 0.0020299751839417137, 0.0102182810143517,
    0.058116735860084034, 0.19634433732941292, 0.37823877042972087,
    0.35505190018248872, 0.0, -0.35505190018248872, -0.37823877042972087,
    -0.19634433732941292, -0.058116735860084034, -0.0102182810143517,
    -0.0020299751839417137 };

  static real_T c9_kernel[13] = { 3.4813359214923059E-5, 0.00054457256285105158,
    0.0051667606200595222, 0.029732654490475543, 0.10377716120747747,
    0.21969625200024598, 0.28209557151935094, 0.21969625200024598,
    0.10377716120747747, 0.029732654490475543, 0.0051667606200595222,
    0.00054457256285105158, 3.4813359214923059E-5 };

  static real_T c9_nonZeroKernel[12] = { 0.0020299751839417137,
    0.0102182810143517, 0.058116735860084034, 0.19634433732941292,
    0.37823877042972087, 0.35505190018248872, -0.35505190018248872,
    -0.37823877042972087, -0.19634433732941292, -0.058116735860084034,
    -0.0102182810143517, -0.0020299751839417137 };

  static int32_T c9_b_idxA[144] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
    14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 3,
    4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
    25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43,
    44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 60, 60,
    60, 60, 60, 60 };

  static int32_T c9_idxA[120] = { 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9,
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
    29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 40, 40, 40, 40, 40, 40, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    56, 57, 58, 59, 60 };

  static boolean_T c9_b_conn[13] = { true, true, true, true, true, true, false,
    true, true, true, true, true, true };

  static boolean_T c9_c_conn[13] = { true, true, true, true, true, true, false,
    true, true, true, true, true, true };

  emlrtStack c9_b_st;
  emlrtStack c9_c_st;
  emlrtStack c9_d_st;
  emlrtStack c9_e_st;
  emlrtStack c9_f_st;
  emlrtStack c9_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  real_T c9_aTmp[3120];
  real_T c9_b_aTmp[2880];
  real_T c9_bTmp[2400];
  real_T c9_b_bTmp[2400];
  real_T c9_magGrad[2400];
  real_T c9_cost[180];
  real_T c9_sint[180];
  real_T c9_counts[64];
  real_T c9_tempBin[40];
  real_T c9_connDimsT[2];
  real_T c9_outSizeT[2];
  real_T c9_padSizeT[2];
  real_T c9_peaks_data[2];
  real_T c9_startT[2];
  real_T c9_b_data[1];
  real_T c9_highThresh_data[1];
  real_T c9_lowThresh_data[1];
  real_T c9_a;
  real_T c9_b;
  real_T c9_b_DegAngle;
  real_T c9_b_a;
  real_T c9_b_b;
  real_T c9_b_idx;
  real_T c9_b_j;
  real_T c9_b_k;
  real_T c9_b_lowThresh;
  real_T c9_b_r;
  real_T c9_b_varargin_1;
  real_T c9_b_x;
  real_T c9_b_x1;
  real_T c9_b_x2;
  real_T c9_b_y;
  real_T c9_c_a;
  real_T c9_c_b;
  real_T c9_c_x;
  real_T c9_c_y;
  real_T c9_d;
  real_T c9_d_a;
  real_T c9_d_b;
  real_T c9_d_i;
  real_T c9_d_idx;
  real_T c9_d_j;
  real_T c9_d_x;
  real_T c9_d_y;
  real_T c9_e_a;
  real_T c9_e_x;
  real_T c9_e_y;
  real_T c9_f_a;
  real_T c9_f_j;
  real_T c9_f_x;
  real_T c9_f_y;
  real_T c9_g_a;
  real_T c9_g_b;
  real_T c9_g_i;
  real_T c9_g_x;
  real_T c9_g_y;
  real_T c9_h_j;
  real_T c9_h_x;
  real_T c9_h_y;
  real_T c9_highThresh;
  real_T c9_highThreshTemp;
  real_T c9_i_x;
  real_T c9_i_y;
  real_T c9_j_i;
  real_T c9_j_j;
  real_T c9_j_x;
  real_T c9_k_x;
  real_T c9_l_j;
  real_T c9_l_x;
  real_T c9_lowThresh;
  real_T c9_m_i;
  real_T c9_m_x;
  real_T c9_magmax;
  real_T c9_myRho;
  real_T c9_n_x;
  real_T c9_o_i;
  real_T c9_o_x;
  real_T c9_out;
  real_T c9_p_x;
  real_T c9_r;
  real_T c9_s_i;
  real_T c9_sum;
  real_T c9_tempNum;
  real_T c9_varargin_2;
  real_T c9_x;
  real_T c9_x1;
  real_T c9_x2;
  real_T c9_y;
  int32_T c9_nonZeroPixelMatrix[2400];
  int32_T c9_rhoIdxVector[143];
  int32_T c9_numNonZeros[60];
  int32_T c9_peaks_size[2];
  int32_T c9_highThresh_size[1];
  int32_T c9_lowThresh_size[1];
  int32_T c9_b_c;
  int32_T c9_b_i;
  int32_T c9_b_thetaIdx;
  int32_T c9_c;
  int32_T c9_c_c;
  int32_T c9_c_i;
  int32_T c9_c_j;
  int32_T c9_e_i;
  int32_T c9_e_j;
  int32_T c9_f_i;
  int32_T c9_g_j;
  int32_T c9_h_a;
  int32_T c9_h_i;
  int32_T c9_i;
  int32_T c9_i1;
  int32_T c9_i10;
  int32_T c9_i11;
  int32_T c9_i12;
  int32_T c9_i13;
  int32_T c9_i14;
  int32_T c9_i15;
  int32_T c9_i16;
  int32_T c9_i17;
  int32_T c9_i18;
  int32_T c9_i19;
  int32_T c9_i2;
  int32_T c9_i20;
  int32_T c9_i21;
  int32_T c9_i22;
  int32_T c9_i23;
  int32_T c9_i24;
  int32_T c9_i25;
  int32_T c9_i26;
  int32_T c9_i27;
  int32_T c9_i28;
  int32_T c9_i29;
  int32_T c9_i3;
  int32_T c9_i30;
  int32_T c9_i31;
  int32_T c9_i32;
  int32_T c9_i33;
  int32_T c9_i34;
  int32_T c9_i35;
  int32_T c9_i36;
  int32_T c9_i37;
  int32_T c9_i38;
  int32_T c9_i39;
  int32_T c9_i4;
  int32_T c9_i40;
  int32_T c9_i41;
  int32_T c9_i42;
  int32_T c9_i43;
  int32_T c9_i44;
  int32_T c9_i45;
  int32_T c9_i46;
  int32_T c9_i47;
  int32_T c9_i48;
  int32_T c9_i49;
  int32_T c9_i5;
  int32_T c9_i50;
  int32_T c9_i51;
  int32_T c9_i52;
  int32_T c9_i6;
  int32_T c9_i7;
  int32_T c9_i8;
  int32_T c9_i9;
  int32_T c9_i_i;
  int32_T c9_i_j;
  int32_T c9_idx;
  int32_T c9_j;
  int32_T c9_j_y;
  int32_T c9_k;
  int32_T c9_k_i;
  int32_T c9_k_j;
  int32_T c9_l_i;
  int32_T c9_loop_ub;
  int32_T c9_n;
  int32_T c9_n_i;
  int32_T c9_p_i;
  int32_T c9_q_i;
  int32_T c9_r_i;
  int32_T c9_rhoIdx;
  int32_T c9_t_i;
  int32_T c9_thetaIdx;
  int8_T c9_c_idx;
  boolean_T c9_E[2400];
  boolean_T c9_marker[2400];
  boolean_T c9_conn[13];
  boolean_T c9_b_modeFlag;
  boolean_T c9_b_tooBig;
  boolean_T c9_c_modeFlag;
  boolean_T c9_c_tooBig;
  boolean_T c9_covSaturation = false;
  boolean_T c9_d_modeFlag;
  boolean_T c9_d_tooBig;
  boolean_T c9_e_b;
  boolean_T c9_e_modeFlag;
  boolean_T c9_exitg1;
  boolean_T c9_f_b;
  boolean_T c9_f_modeFlag;
  boolean_T c9_g_modeFlag;
  boolean_T c9_h_modeFlag;
  boolean_T c9_i_modeFlag;
  boolean_T c9_j_modeFlag;
  boolean_T c9_k_modeFlag;
  boolean_T c9_l_modeFlag;
  boolean_T c9_modeFlag;
  boolean_T c9_nanFlag;
  boolean_T c9_tooBig;
  c9_st.tls = chartInstance->c9_fEmlrtCtx;
  c9_b_st.prev = &c9_st;
  c9_b_st.tls = c9_st.tls;
  c9_c_st.prev = &c9_b_st;
  c9_c_st.tls = c9_b_st.tls;
  c9_d_st.prev = &c9_c_st;
  c9_d_st.tls = c9_c_st.tls;
  c9_e_st.prev = &c9_d_st;
  c9_e_st.tls = c9_d_st.tls;
  c9_f_st.prev = &c9_e_st;
  c9_f_st.tls = c9_e_st.tls;
  for (c9_i = 0; c9_i < 2400; c9_i++) {
    covrtSigUpdateFcn(chartInstance->c9_covrtInstance, 0U,
                      (*chartInstance->c9_BWImage)[c9_i]);
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c9_JITTransitionAnimation[0] = 0U;
  chartInstance->c9_sfEvent = CALL_EVENT;
  covrtEmlFcnEval(chartInstance->c9_covrtInstance, 4U, 0, 0);
  c9_b_st.site = &c9_emlrtRSI;
  c9_c_st.site = &c9_d_emlrtRSI;
  c9_d_st.site = &c9_g_emlrtRSI;
  c9_e_st.site = &c9_k_emlrtRSI;
  c9_f_st.site = &c9_m_emlrtRSI;
  for (c9_j = 0; c9_j < 60; c9_j++) {
    c9_b_j = (real_T)c9_j + 1.0;
    for (c9_b_i = 0; c9_b_i < 52; c9_b_i++) {
      c9_d_i = (real_T)c9_b_i + 1.0;
      if ((c9_idxA[(int32_T)c9_d_i - 1] < 1) || (c9_idxA[(int32_T)c9_d_i - 1] >
           40)) {
        emlrtDynamicBoundsCheckR2012b(c9_idxA[(int32_T)c9_d_i - 1], 1, 40,
          &c9_h_emlrtBCI, &c9_f_st);
      }

      c9_i1 = c9_idxA[(int32_T)c9_b_j + 59];
      if ((c9_i1 < 1) || (c9_i1 > 60)) {
        emlrtDynamicBoundsCheckR2012b(c9_i1, 1, 60, &c9_i_emlrtBCI, &c9_f_st);
      }

      c9_aTmp[((int32_T)c9_d_i + 52 * ((int32_T)c9_b_j - 1)) - 1] =
        (*chartInstance->c9_BWImage)[(c9_idxA[(int32_T)c9_d_i - 1] + 40 * (c9_i1
        - 1)) - 1];
    }
  }

  c9_e_st.site = &c9_l_emlrtRSI;
  c9_f_st.site = &c9_n_emlrtRSI;
  c9_tooBig = true;
  for (c9_c_i = 0; c9_c_i < 2; c9_c_i++) {
    c9_tooBig = false;
  }

  if (!c9_tooBig) {
    c9_modeFlag = true;
  } else {
    c9_modeFlag = false;
  }

  if (c9_modeFlag) {
    c9_b_modeFlag = true;
  } else {
    c9_b_modeFlag = false;
  }

  c9_c_modeFlag = c9_b_modeFlag;
  if (c9_c_modeFlag) {
    for (c9_i3 = 0; c9_i3 < 2; c9_i3++) {
      c9_padSizeT[c9_i3] = 52.0 + 8.0 * (real_T)c9_i3;
    }

    for (c9_i5 = 0; c9_i5 < 2; c9_i5++) {
      c9_outSizeT[c9_i5] = 40.0 + 20.0 * (real_T)c9_i5;
    }

    for (c9_i7 = 0; c9_i7 < 2; c9_i7++) {
      c9_connDimsT[c9_i7] = 13.0 + -12.0 * (real_T)c9_i7;
    }

    ippfilter_real64(&c9_aTmp[0], &c9_bTmp[0], &c9_outSizeT[0], 2.0,
                     &c9_padSizeT[0], &c9_kernel[0], &c9_connDimsT[0], true);
  } else {
    for (c9_i2 = 0; c9_i2 < 13; c9_i2++) {
      c9_conn[c9_i2] = true;
    }

    for (c9_i4 = 0; c9_i4 < 2; c9_i4++) {
      c9_padSizeT[c9_i4] = 52.0 + 8.0 * (real_T)c9_i4;
    }

    for (c9_i6 = 0; c9_i6 < 2; c9_i6++) {
      c9_outSizeT[c9_i6] = 40.0 + 20.0 * (real_T)c9_i6;
    }

    for (c9_i8 = 0; c9_i8 < 2; c9_i8++) {
      c9_connDimsT[c9_i8] = 13.0 + -12.0 * (real_T)c9_i8;
    }

    for (c9_i9 = 0; c9_i9 < 2; c9_i9++) {
      c9_startT[c9_i9] = 6.0 + -6.0 * (real_T)c9_i9;
    }

    imfilter_real64(&c9_aTmp[0], &c9_bTmp[0], 2.0, &c9_outSizeT[0], 2.0,
                    &c9_padSizeT[0], &c9_kernel[0], 13.0, &c9_conn[0], 2.0,
                    &c9_connDimsT[0], &c9_startT[0], 2.0, true, true);
  }

  c9_d_st.site = &c9_h_emlrtRSI;
  c9_e_st.site = &c9_k_emlrtRSI;
  c9_f_st.site = &c9_m_emlrtRSI;
  for (c9_c_j = 0; c9_c_j < 72; c9_c_j++) {
    c9_d_j = (real_T)c9_c_j + 1.0;
    for (c9_e_i = 0; c9_e_i < 40; c9_e_i++) {
      c9_g_i = (real_T)c9_e_i + 1.0;
      if ((c9_b_idxA[(int32_T)c9_g_i - 1] < 1) || (c9_b_idxA[(int32_T)c9_g_i - 1]
           > 40)) {
        emlrtDynamicBoundsCheckR2012b(c9_b_idxA[(int32_T)c9_g_i - 1], 1, 40,
          &c9_h_emlrtBCI, &c9_f_st);
      }

      c9_i10 = c9_b_idxA[(int32_T)c9_d_j + 71];
      if ((c9_i10 < 1) || (c9_i10 > 60)) {
        emlrtDynamicBoundsCheckR2012b(c9_i10, 1, 60, &c9_i_emlrtBCI, &c9_f_st);
      }

      c9_b_aTmp[((int32_T)c9_g_i + 40 * ((int32_T)c9_d_j - 1)) - 1] = c9_bTmp
        [(c9_b_idxA[(int32_T)c9_g_i - 1] + 40 * (c9_i10 - 1)) - 1];
    }
  }

  c9_e_st.site = &c9_l_emlrtRSI;
  c9_f_st.site = &c9_n_emlrtRSI;
  c9_b_tooBig = true;
  for (c9_f_i = 0; c9_f_i < 2; c9_f_i++) {
    c9_b_tooBig = false;
  }

  if (!c9_b_tooBig) {
    c9_d_modeFlag = true;
  } else {
    c9_d_modeFlag = false;
  }

  if (c9_d_modeFlag) {
    c9_e_modeFlag = true;
  } else {
    c9_e_modeFlag = false;
  }

  c9_f_modeFlag = c9_e_modeFlag;
  if (c9_f_modeFlag) {
    for (c9_i12 = 0; c9_i12 < 2; c9_i12++) {
      c9_padSizeT[c9_i12] = 40.0 + 32.0 * (real_T)c9_i12;
    }

    for (c9_i14 = 0; c9_i14 < 2; c9_i14++) {
      c9_outSizeT[c9_i14] = 40.0 + 20.0 * (real_T)c9_i14;
    }

    for (c9_i16 = 0; c9_i16 < 2; c9_i16++) {
      c9_connDimsT[c9_i16] = 1.0 + 12.0 * (real_T)c9_i16;
    }

    ippfilter_real64(&c9_b_aTmp[0], &c9_bTmp[0], &c9_outSizeT[0], 2.0,
                     &c9_padSizeT[0], &c9_b_kernel[0], &c9_connDimsT[0], true);
  } else {
    for (c9_i11 = 0; c9_i11 < 2; c9_i11++) {
      c9_padSizeT[c9_i11] = 40.0 + 32.0 * (real_T)c9_i11;
    }

    for (c9_i13 = 0; c9_i13 < 2; c9_i13++) {
      c9_outSizeT[c9_i13] = 40.0 + 20.0 * (real_T)c9_i13;
    }

    for (c9_i15 = 0; c9_i15 < 2; c9_i15++) {
      c9_connDimsT[c9_i15] = 1.0 + 12.0 * (real_T)c9_i15;
    }

    for (c9_i17 = 0; c9_i17 < 2; c9_i17++) {
      c9_startT[c9_i17] = 6.0 * (real_T)c9_i17;
    }

    imfilter_real64(&c9_b_aTmp[0], &c9_bTmp[0], 2.0, &c9_outSizeT[0], 2.0,
                    &c9_padSizeT[0], &c9_nonZeroKernel[0], 12.0, &c9_b_conn[0],
                    2.0, &c9_connDimsT[0], &c9_startT[0], 2.0, true, true);
  }

  c9_d_st.site = &c9_i_emlrtRSI;
  c9_e_st.site = &c9_k_emlrtRSI;
  c9_f_st.site = &c9_m_emlrtRSI;
  for (c9_e_j = 0; c9_e_j < 72; c9_e_j++) {
    c9_f_j = (real_T)c9_e_j + 1.0;
    for (c9_h_i = 0; c9_h_i < 40; c9_h_i++) {
      c9_j_i = (real_T)c9_h_i + 1.0;
      if ((c9_b_idxA[(int32_T)c9_j_i - 1] < 1) || (c9_b_idxA[(int32_T)c9_j_i - 1]
           > 40)) {
        emlrtDynamicBoundsCheckR2012b(c9_b_idxA[(int32_T)c9_j_i - 1], 1, 40,
          &c9_h_emlrtBCI, &c9_f_st);
      }

      c9_i18 = c9_b_idxA[(int32_T)c9_f_j + 71];
      if ((c9_i18 < 1) || (c9_i18 > 60)) {
        emlrtDynamicBoundsCheckR2012b(c9_i18, 1, 60, &c9_i_emlrtBCI, &c9_f_st);
      }

      c9_b_aTmp[((int32_T)c9_j_i + 40 * ((int32_T)c9_f_j - 1)) - 1] =
        (*chartInstance->c9_BWImage)[(c9_b_idxA[(int32_T)c9_j_i - 1] + 40 *
        (c9_i18 - 1)) - 1];
    }
  }

  c9_e_st.site = &c9_l_emlrtRSI;
  c9_f_st.site = &c9_n_emlrtRSI;
  c9_c_tooBig = true;
  for (c9_i_i = 0; c9_i_i < 2; c9_i_i++) {
    c9_c_tooBig = false;
  }

  if (!c9_c_tooBig) {
    c9_g_modeFlag = true;
  } else {
    c9_g_modeFlag = false;
  }

  if (c9_g_modeFlag) {
    c9_h_modeFlag = true;
  } else {
    c9_h_modeFlag = false;
  }

  c9_i_modeFlag = c9_h_modeFlag;
  if (c9_i_modeFlag) {
    for (c9_i20 = 0; c9_i20 < 2; c9_i20++) {
      c9_padSizeT[c9_i20] = 40.0 + 32.0 * (real_T)c9_i20;
    }

    for (c9_i22 = 0; c9_i22 < 2; c9_i22++) {
      c9_outSizeT[c9_i22] = 40.0 + 20.0 * (real_T)c9_i22;
    }

    for (c9_i24 = 0; c9_i24 < 2; c9_i24++) {
      c9_connDimsT[c9_i24] = 1.0 + 12.0 * (real_T)c9_i24;
    }

    ippfilter_real64(&c9_b_aTmp[0], &c9_b_bTmp[0], &c9_outSizeT[0], 2.0,
                     &c9_padSizeT[0], &c9_c_kernel[0], &c9_connDimsT[0], true);
  } else {
    for (c9_i19 = 0; c9_i19 < 13; c9_i19++) {
      c9_conn[c9_i19] = true;
    }

    for (c9_i21 = 0; c9_i21 < 2; c9_i21++) {
      c9_padSizeT[c9_i21] = 40.0 + 32.0 * (real_T)c9_i21;
    }

    for (c9_i23 = 0; c9_i23 < 2; c9_i23++) {
      c9_outSizeT[c9_i23] = 40.0 + 20.0 * (real_T)c9_i23;
    }

    for (c9_i25 = 0; c9_i25 < 2; c9_i25++) {
      c9_connDimsT[c9_i25] = 1.0 + 12.0 * (real_T)c9_i25;
    }

    for (c9_i26 = 0; c9_i26 < 2; c9_i26++) {
      c9_startT[c9_i26] = 6.0 * (real_T)c9_i26;
    }

    imfilter_real64(&c9_b_aTmp[0], &c9_b_bTmp[0], 2.0, &c9_outSizeT[0], 2.0,
                    &c9_padSizeT[0], &c9_kernel[0], 13.0, &c9_conn[0], 2.0,
                    &c9_connDimsT[0], &c9_startT[0], 2.0, true, true);
  }

  c9_d_st.site = &c9_j_emlrtRSI;
  c9_e_st.site = &c9_k_emlrtRSI;
  c9_f_st.site = &c9_m_emlrtRSI;
  for (c9_g_j = 0; c9_g_j < 60; c9_g_j++) {
    c9_h_j = (real_T)c9_g_j + 1.0;
    for (c9_k_i = 0; c9_k_i < 52; c9_k_i++) {
      c9_m_i = (real_T)c9_k_i + 1.0;
      if ((c9_idxA[(int32_T)c9_m_i - 1] < 1) || (c9_idxA[(int32_T)c9_m_i - 1] >
           40)) {
        emlrtDynamicBoundsCheckR2012b(c9_idxA[(int32_T)c9_m_i - 1], 1, 40,
          &c9_h_emlrtBCI, &c9_f_st);
      }

      c9_i27 = c9_idxA[(int32_T)c9_h_j + 59];
      if ((c9_i27 < 1) || (c9_i27 > 60)) {
        emlrtDynamicBoundsCheckR2012b(c9_i27, 1, 60, &c9_i_emlrtBCI, &c9_f_st);
      }

      c9_aTmp[((int32_T)c9_m_i + 52 * ((int32_T)c9_h_j - 1)) - 1] = c9_b_bTmp
        [(c9_idxA[(int32_T)c9_m_i - 1] + 40 * (c9_i27 - 1)) - 1];
    }
  }

  c9_e_st.site = &c9_l_emlrtRSI;
  c9_f_st.site = &c9_n_emlrtRSI;
  c9_d_tooBig = true;
  for (c9_l_i = 0; c9_l_i < 2; c9_l_i++) {
    c9_d_tooBig = false;
  }

  if (!c9_d_tooBig) {
    c9_j_modeFlag = true;
  } else {
    c9_j_modeFlag = false;
  }

  if (c9_j_modeFlag) {
    c9_k_modeFlag = true;
  } else {
    c9_k_modeFlag = false;
  }

  c9_l_modeFlag = c9_k_modeFlag;
  if (c9_l_modeFlag) {
    for (c9_i29 = 0; c9_i29 < 2; c9_i29++) {
      c9_padSizeT[c9_i29] = 52.0 + 8.0 * (real_T)c9_i29;
    }

    for (c9_i31 = 0; c9_i31 < 2; c9_i31++) {
      c9_outSizeT[c9_i31] = 40.0 + 20.0 * (real_T)c9_i31;
    }

    for (c9_i33 = 0; c9_i33 < 2; c9_i33++) {
      c9_connDimsT[c9_i33] = 13.0 + -12.0 * (real_T)c9_i33;
    }

    ippfilter_real64(&c9_aTmp[0], &c9_b_bTmp[0], &c9_outSizeT[0], 2.0,
                     &c9_padSizeT[0], &c9_d_kernel[0], &c9_connDimsT[0], true);
  } else {
    for (c9_i28 = 0; c9_i28 < 2; c9_i28++) {
      c9_padSizeT[c9_i28] = 52.0 + 8.0 * (real_T)c9_i28;
    }

    for (c9_i30 = 0; c9_i30 < 2; c9_i30++) {
      c9_outSizeT[c9_i30] = 40.0 + 20.0 * (real_T)c9_i30;
    }

    for (c9_i32 = 0; c9_i32 < 2; c9_i32++) {
      c9_connDimsT[c9_i32] = 13.0 + -12.0 * (real_T)c9_i32;
    }

    for (c9_i34 = 0; c9_i34 < 2; c9_i34++) {
      c9_startT[c9_i34] = 6.0 + -6.0 * (real_T)c9_i34;
    }

    imfilter_real64(&c9_aTmp[0], &c9_b_bTmp[0], 2.0, &c9_outSizeT[0], 2.0,
                    &c9_padSizeT[0], &c9_nonZeroKernel[0], 12.0, &c9_c_conn[0],
                    2.0, &c9_connDimsT[0], &c9_startT[0], 2.0, true, true);
  }

  c9_x = c9_bTmp[0];
  c9_y = c9_b_bTmp[0];
  c9_a = c9_x;
  c9_b = c9_y;
  c9_b_x = c9_a;
  c9_b_y = c9_b;
  c9_x1 = c9_b_x;
  c9_x2 = c9_b_y;
  c9_b_a = c9_x1;
  c9_b_b = c9_x2;
  c9_r = muDoubleScalarHypot(c9_b_a, c9_b_b);
  c9_magGrad[0] = c9_r;
  c9_magmax = c9_magGrad[0];
  for (c9_idx = 0; c9_idx < 2399; c9_idx++) {
    c9_b_idx = (real_T)c9_idx + 2.0;
    c9_c_x = c9_bTmp[(int32_T)c9_b_idx - 1];
    c9_c_y = c9_b_bTmp[(int32_T)c9_b_idx - 1];
    c9_c_a = c9_c_x;
    c9_c_b = c9_c_y;
    c9_d_x = c9_c_a;
    c9_d_y = c9_c_b;
    c9_b_x1 = c9_d_x;
    c9_b_x2 = c9_d_y;
    c9_d_a = c9_b_x1;
    c9_d_b = c9_b_x2;
    c9_b_r = muDoubleScalarHypot(c9_d_a, c9_d_b);
    c9_magGrad[(int32_T)c9_b_idx - 1] = c9_b_r;
    c9_b_varargin_1 = c9_magGrad[(int32_T)c9_b_idx - 1];
    c9_varargin_2 = c9_magmax;
    c9_f_x = c9_b_varargin_1;
    c9_e_y = c9_varargin_2;
    c9_g_x = c9_f_x;
    c9_f_y = c9_e_y;
    c9_i_x = c9_g_x;
    c9_g_y = c9_f_y;
    c9_e_a = c9_i_x;
    c9_g_b = c9_g_y;
    c9_j_x = c9_e_a;
    c9_h_y = c9_g_b;
    c9_k_x = c9_j_x;
    c9_i_y = c9_h_y;
    c9_magmax = muDoubleScalarMax(c9_k_x, c9_i_y);
  }

  if (c9_magmax > 0.0) {
    for (c9_i35 = 0; c9_i35 < 2400; c9_i35++) {
      c9_magGrad[c9_i35] /= c9_magmax;
    }
  }

  c9_c_st.site = &c9_e_emlrtRSI;
  c9_d_st.site = &c9_r_emlrtRSI;
  c9_e_st.site = &c9_s_emlrtRSI;
  c9_f_st.site = &c9_t_emlrtRSI;
  c9_out = 1.0;
  getnumcores(&c9_out);
  memset(&c9_counts[0], 0, sizeof(real_T) << 6);
  c9_nanFlag = false;
  for (c9_n_i = 0; c9_n_i < 2400; c9_n_i++) {
    c9_o_i = (real_T)c9_n_i + 1.0;
    c9_e_x = c9_magGrad[(int32_T)c9_o_i - 1];
    c9_e_b = muDoubleScalarIsNaN(c9_e_x);
    if (c9_e_b) {
      c9_nanFlag = true;
      c9_d_idx = 0.0;
    } else {
      c9_d_idx = c9_magGrad[(int32_T)c9_o_i - 1] * 63.0 + 0.5;
    }

    if (c9_d_idx > 63.0) {
      c9_counts[63]++;
    } else {
      c9_h_x = c9_magGrad[(int32_T)c9_o_i - 1];
      c9_f_b = muDoubleScalarIsInf(c9_h_x);
      if (c9_f_b) {
        c9_counts[63]++;
      } else {
        c9_f_a = c9_d_idx;
        c9_c = (int32_T)c9_f_a;
        c9_g_a = c9_d_idx;
        c9_b_c = (int32_T)c9_g_a;
        c9_counts[c9_c] = c9_counts[c9_b_c] + 1.0;
      }
    }
  }

  if (c9_nanFlag) {
    c9_f_st.site = &c9_u_emlrtRSI;
    c9_warning(chartInstance, &c9_f_st);
  }

  c9_sum = 0.0;
  c9_c_idx = 1;
  while ((!(c9_sum > 1680.0)) && (c9_c_idx <= 64)) {
    c9_sum += c9_counts[c9_c_idx - 1];
    c9_i37 = c9_c_idx + 1;
    if (c9_i37 > 127) {
      c9_covSaturation = true;
      c9_i37 = 127;
    } else if (c9_i37 < -128) {
      c9_covSaturation = true;
      c9_i37 = -128;
    }

    covrtSaturationUpdateFcn(chartInstance->c9_covrtInstance, 4, 0, 0, 0,
      c9_covSaturation);
    c9_c_idx = (int8_T)c9_i37;
  }

  c9_i36 = c9_c_idx - 1;
  if (c9_i36 > 127) {
    c9_i36 = 127;
  } else if (c9_i36 < -128) {
    c9_i36 = -128;
  }

  c9_highThreshTemp = (real_T)(int8_T)c9_i36 / 64.0;
  if ((c9_c_idx > 64) && (!(c9_sum > 1680.0))) {
    c9_highThresh_size[0] = 0;
    c9_lowThresh_size[0] = 0;
  } else {
    c9_highThresh_size[0] = 1;
    c9_highThresh_data[0] = c9_highThreshTemp;
    c9_loop_ub = c9_highThresh_size[0] - 1;
    for (c9_i38 = 0; c9_i38 <= c9_loop_ub; c9_i38++) {
      c9_b_data[c9_i38] = c9_highThresh_data[c9_i38];
    }

    c9_b_data[0] *= 0.4;
    c9_lowThresh_size[0] = 1;
    c9_lowThresh_data[0] = c9_b_data[0];
  }

  c9_c_st.site = &c9_f_emlrtRSI;
  c9_i39 = 1;
  if ((c9_i39 < 1) || (c9_i39 > c9_lowThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c9_i39, 1, c9_lowThresh_size[0],
      &c9_d_emlrtBCI, &c9_c_st);
  }

  c9_d_st.site = &c9_w_emlrtRSI;
  c9_lowThresh = c9_lowThresh_data[0];
  c9_e_st.site = &c9_y_emlrtRSI;
  c9_b_lowThresh = c9_lowThresh;
  memset(&c9_E[0], 0, 2400U * sizeof(boolean_T));
  for (c9_i40 = 0; c9_i40 < 2; c9_i40++) {
    c9_connDimsT[c9_i40] = 40.0 + 20.0 * (real_T)c9_i40;
  }

  cannythresholding_real64_tbb(&c9_bTmp[0], &c9_b_bTmp[0], &c9_magGrad[0],
    &c9_connDimsT[0], c9_b_lowThresh, &c9_E[0]);
  c9_i41 = 1;
  if ((c9_i41 < 1) || (c9_i41 > c9_highThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c9_i41, 1, c9_highThresh_size[0],
      &c9_c_emlrtBCI, &c9_c_st);
  }

  c9_highThresh = c9_highThresh_data[0];
  for (c9_i42 = 0; c9_i42 < 2400; c9_i42++) {
    c9_marker[c9_i42] = (c9_magGrad[c9_i42] > c9_highThresh);
  }

  c9_d_st.site = &c9_x_emlrtRSI;
  c9_e_st.site = &c9_ab_emlrtRSI;
  c9_e_st.site = &c9_bb_emlrtRSI;
  for (c9_i43 = 0; c9_i43 < 2; c9_i43++) {
    c9_connDimsT[c9_i43] = 40.0 + 20.0 * (real_T)c9_i43;
  }

  ippreconstruct_uint8((uint8_T *)&c9_marker[0], (uint8_T *)&c9_E[0],
                       &c9_connDimsT[0], 2.0);
  c9_i44 = 1;
  if ((c9_i44 < 1) || (c9_i44 > c9_lowThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c9_i44, 1, c9_lowThresh_size[0],
      &c9_f_emlrtBCI, &c9_b_st);
  }

  c9_i45 = 1;
  if ((c9_i45 < 1) || (c9_i45 > c9_highThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c9_i45, 1, c9_highThresh_size[0],
      &c9_e_emlrtBCI, &c9_b_st);
  }

  c9_b_st.site = &c9_b_emlrtRSI;
  c9_c_st.site = &c9_db_emlrtRSI;
  for (c9_p_i = 0; c9_p_i < 180; c9_p_i++) {
    c9_q_i = c9_p_i;
    c9_l_x = (-90.0 + (real_T)c9_q_i) * 3.1415926535897931 / 180.0;
    c9_m_x = c9_l_x;
    c9_m_x = muDoubleScalarCos(c9_m_x);
    c9_cost[c9_q_i] = c9_m_x;
    c9_n_x = (-90.0 + (real_T)c9_q_i) * 3.1415926535897931 / 180.0;
    c9_o_x = c9_n_x;
    c9_o_x = muDoubleScalarSin(c9_o_x);
    c9_sint[c9_q_i] = c9_o_x;
  }

  c9_d_st.site = &c9_eb_emlrtRSI;
  for (c9_i_j = 0; c9_i_j < 60; c9_i_j++) {
    c9_j_j = (real_T)c9_i_j + 1.0;
    c9_tempNum = 0.0;
    for (c9_r_i = 0; c9_r_i < 40; c9_r_i++) {
      c9_s_i = (real_T)c9_r_i + 1.0;
      if (c9_marker[((int32_T)c9_s_i + 40 * ((int32_T)c9_j_j - 1)) - 1]) {
        c9_tempNum++;
        c9_i50 = (int32_T)c9_tempNum;
        if ((c9_i50 < 1) || (c9_i50 > 40)) {
          emlrtDynamicBoundsCheckR2012b(c9_i50, 1, 40, &c9_emlrtBCI, &c9_d_st);
        }

        c9_tempBin[c9_i50 - 1] = c9_s_i;
      }
    }

    c9_numNonZeros[(int32_T)c9_j_j - 1] = (int32_T)c9_tempNum;
    c9_k = 0;
    c9_exitg1 = false;
    while ((!c9_exitg1) && (c9_k < 40)) {
      c9_b_k = (real_T)c9_k + 1.0;
      if (c9_b_k > c9_tempNum) {
        c9_exitg1 = true;
      } else {
        c9_nonZeroPixelMatrix[((int32_T)c9_b_k + 40 * ((int32_T)c9_j_j - 1)) - 1]
          = (int32_T)c9_tempBin[(int32_T)c9_b_k - 1];
        c9_k++;
      }
    }
  }

  for (c9_thetaIdx = 0; c9_thetaIdx < 180; c9_thetaIdx++) {
    c9_b_thetaIdx = c9_thetaIdx;
    memset(&c9_rhoIdxVector[0], 0, 143U * sizeof(int32_T));
    for (c9_k_j = 0; c9_k_j < 60; c9_k_j++) {
      c9_l_j = (real_T)c9_k_j + 1.0;
      c9_i49 = c9_numNonZeros[(int32_T)c9_l_j - 1];
      c9_i51 = (uint8_T)c9_i49;
      for (c9_t_i = 0; c9_t_i < c9_i51; c9_t_i++) {
        c9_q_i = c9_t_i;
        c9_n = c9_nonZeroPixelMatrix[c9_q_i + 40 * ((int32_T)c9_l_j - 1)];
        c9_myRho = (c9_l_j - 1.0) * c9_cost[c9_b_thetaIdx] + ((real_T)c9_n - 1.0)
          * c9_sint[c9_b_thetaIdx];
        c9_p_x = c9_myRho - -71.0;
        c9_j_y = (int32_T)(c9_p_x + 0.5) + 1;
        c9_rhoIdx = c9_j_y;
        c9_h_a = c9_rhoIdxVector[c9_rhoIdx - 1] + 1;
        c9_c_c = c9_h_a;
        if ((c9_rhoIdx < 1) || (c9_rhoIdx > 143)) {
          emlrtDynamicBoundsCheckR2012b(c9_rhoIdx, 1, 143, &c9_b_emlrtBCI,
            &c9_c_st);
        }

        c9_rhoIdxVector[c9_rhoIdx - 1] = c9_c_c;
      }
    }

    for (c9_i48 = 0; c9_i48 < 143; c9_i48++) {
      chartInstance->c9_H[c9_i48 + 143 * c9_b_thetaIdx] = (real_T)
        c9_rhoIdxVector[c9_i48];
    }
  }

  c9_b_st.site = &c9_c_emlrtRSI;
  c9_houghpeaks(chartInstance, &c9_b_st, chartInstance->c9_H, c9_peaks_data,
                c9_peaks_size);
  c9_i46 = c9__s32_s64_(chartInstance, (int64_T)c9_peaks_size[0] * (int64_T)
                        c9_peaks_size[1], 0, 1U, 346, 8);
  c9_i47 = 2;
  if ((c9_i47 < 1) || (c9_i47 > c9_i46)) {
    emlrtDynamicBoundsCheckR2012b(c9_i47, 1, c9_i46, &c9_j_emlrtBCI, &c9_st);
  }

  c9_d = c9_peaks_data[c9_i47 - 1];
  if (c9_d != (real_T)(int32_T)muDoubleScalarFloor(c9_d)) {
    emlrtIntegerCheckR2012b(c9_d, &c9_emlrtDCI, &c9_st);
  }

  c9_i52 = (int32_T)c9_d;
  if ((c9_i52 < 1) || (c9_i52 > 180)) {
    emlrtDynamicBoundsCheckR2012b(c9_i52, 1, 180, &c9_g_emlrtBCI, &c9_st);
  }

  c9_b_DegAngle = -90.0 + (real_T)(c9_i52 - 1);
  *chartInstance->c9_DegAngle = c9_b_DegAngle;
  covrtSigUpdateFcn(chartInstance->c9_covrtInstance, 1U,
                    *chartInstance->c9_DegAngle);
}

static void ext_mode_exec_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c9_update_jit_animation_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c9_do_animation_call_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance)
{
  const mxArray *c9_b_y = NULL;
  const mxArray *c9_st = NULL;
  const mxArray *c9_y = NULL;
  c9_st = NULL;
  c9_y = NULL;
  sf_mex_assign(&c9_y, sf_mex_createcellmatrix(1, 1), false);
  c9_b_y = NULL;
  sf_mex_assign(&c9_b_y, sf_mex_create("y", chartInstance->c9_DegAngle, 0, 0U, 0,
    0U, 0), false);
  sf_mex_setcell(c9_y, 0, c9_b_y);
  sf_mex_assign(&c9_st, c9_y, false);
  return c9_st;
}

static void set_sim_state_c9_flightControlSystem
  (SFc9_flightControlSystemInstanceStruct *chartInstance, const mxArray *c9_st)
{
  const mxArray *c9_u;
  chartInstance->c9_doneDoubleBufferReInit = true;
  c9_u = sf_mex_dup(c9_st);
  *chartInstance->c9_DegAngle = c9_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c9_u, 0)), "DegAngle");
  sf_mex_destroy(&c9_u);
  sf_mex_destroy(&c9_st);
}

static void c9_warning(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp)
{
  static char_T c9_msgID[27] = { 'i', 'm', 'a', 'g', 'e', 's', ':', 'i', 'm',
    'h', 'i', 's', 't', 'c', ':', 'i', 'n', 'p', 'u', 't', 'H', 'a', 's', 'N',
    'a', 'N', 's' };

  static char_T c9_b_cv[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  static char_T c9_b_cv1[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  emlrtStack c9_st;
  const mxArray *c9_b_y = NULL;
  const mxArray *c9_c_y = NULL;
  const mxArray *c9_y = NULL;
  c9_st.prev = c9_sp;
  c9_st.tls = c9_sp->tls;
  c9_y = NULL;
  sf_mex_assign(&c9_y, sf_mex_create("y", c9_b_cv, 10, 0U, 1, 0U, 2, 1, 7),
                false);
  c9_b_y = NULL;
  sf_mex_assign(&c9_b_y, sf_mex_create("y", c9_b_cv1, 10, 0U, 1, 0U, 2, 1, 7),
                false);
  c9_c_y = NULL;
  sf_mex_assign(&c9_c_y, sf_mex_create("y", c9_msgID, 10, 0U, 1, 0U, 2, 1, 27),
                false);
  c9_st.site = &c9_v_emlrtRSI;
  c9_b_feval(chartInstance, &c9_st, c9_y, c9_feval(chartInstance, &c9_st, c9_b_y,
              c9_c_y));
}

static void c9_houghpeaks(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp, real_T c9_b_varargin_1[25740], real_T c9_peaks_data[],
  int32_T c9_peaks_size[2])
{
  static char_T c9_b_cv1[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't',
    't', 'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'N', 'o', 'n', 'N', 'a', 'N' };

  static char_T c9_cv4[43] = { 'i', 'm', 'a', 'g', 'e', 's', ':', 'h', 'o', 'u',
    'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'i', 'n', 'v', 'a', 'l', 'i', 'd',
    'T', 'h', 'e', 't', 'a', 'V', 'e', 'c', 't', 'o', 'r', 'S', 'p', 'a', 'c',
    'i', 'n', 'g' };

  static char_T c9_b_cv[32] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o', 'u',
    'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'N', 'o', 'n', 'N', 'a', 'N' };

  static char_T c9_cv2[9] = { 'T', 'h', 'r', 'e', 's', 'h', 'o', 'l', 'd' };

  static char_T c9_cv3[5] = { 'T', 'h', 'e', 't', 'a' };

  emlrtStack c9_b_st;
  emlrtStack c9_c_st;
  emlrtStack c9_d_st;
  emlrtStack c9_st;
  const mxArray *c9_b_y = NULL;
  const mxArray *c9_c_y = NULL;
  const mxArray *c9_d_y = NULL;
  const mxArray *c9_e_y = NULL;
  const mxArray *c9_f_y = NULL;
  const mxArray *c9_i_y = NULL;
  const mxArray *c9_j_y = NULL;
  const mxArray *c9_y = NULL;
  real_T c9_y1[179];
  real_T c9_b_y1[178];
  real_T c9_peakCoordinates[2];
  real_T c9_a;
  real_T c9_b_a;
  real_T c9_b_default;
  real_T c9_b_ex;
  real_T c9_b_k;
  real_T c9_b_ndx;
  real_T c9_b_threshold;
  real_T c9_b_thresholdDefault;
  real_T c9_b_tmp1;
  real_T c9_b_tmp2;
  real_T c9_b_work;
  real_T c9_b_x;
  real_T c9_c_a;
  real_T c9_c_ex;
  real_T c9_c_threshold;
  real_T c9_c_x;
  real_T c9_d_k;
  real_T c9_d_x;
  real_T c9_default;
  real_T c9_e_idx;
  real_T c9_e_x;
  real_T c9_ex;
  real_T c9_f_x;
  real_T c9_g_x;
  real_T c9_g_y;
  real_T c9_h_x;
  real_T c9_h_y;
  real_T c9_iPeak;
  real_T c9_i_x;
  real_T c9_jPeak;
  real_T c9_j_x;
  real_T c9_k_x;
  real_T c9_k_y;
  real_T c9_l_x;
  real_T c9_l_y;
  real_T c9_m_x;
  real_T c9_maxTheta;
  real_T c9_maxVal;
  real_T c9_minTheta;
  real_T c9_n_x;
  real_T c9_ndx;
  real_T c9_o_x;
  real_T c9_p_x;
  real_T c9_q_x;
  real_T c9_r_x;
  real_T c9_thetaResolution;
  real_T c9_threshold;
  real_T c9_thresholdDefault;
  real_T c9_tmp1;
  real_T c9_tmp2;
  real_T c9_val;
  real_T c9_work;
  real_T c9_x;
  int32_T c9_b_iPeak;
  int32_T c9_b_idx;
  int32_T c9_b_ixLead;
  int32_T c9_b_iyLead;
  int32_T c9_b_jPeak;
  int32_T c9_b_m;
  int32_T c9_c_idx;
  int32_T c9_c_k;
  int32_T c9_d_a;
  int32_T c9_d_idx;
  int32_T c9_e_k;
  int32_T c9_f_idx;
  int32_T c9_f_k;
  int32_T c9_first;
  int32_T c9_g_k;
  int32_T c9_h_k;
  int32_T c9_i;
  int32_T c9_i1;
  int32_T c9_i2;
  int32_T c9_i3;
  int32_T c9_idx;
  int32_T c9_iindx;
  int32_T c9_ixLead;
  int32_T c9_iyLead;
  int32_T c9_k;
  int32_T c9_m;
  int32_T c9_peakIdx;
  int32_T c9_rho;
  int32_T c9_rhoMax;
  int32_T c9_rhoMin;
  int32_T c9_rhoToRemove;
  int32_T c9_theta;
  int32_T c9_thetaMax;
  int32_T c9_thetaMin;
  int32_T c9_thetaToRemove;
  int32_T c9_v1;
  int32_T c9_varargout_3;
  int32_T c9_varargout_4;
  int32_T c9_vk;
  boolean_T c9_b;
  boolean_T c9_b1;
  boolean_T c9_b2;
  boolean_T c9_b3;
  boolean_T c9_b_b;
  boolean_T c9_b_p;
  boolean_T c9_c_b;
  boolean_T c9_c_p;
  boolean_T c9_d_b;
  boolean_T c9_d_p;
  boolean_T c9_e_b;
  boolean_T c9_e_p;
  boolean_T c9_exitg1;
  boolean_T c9_f_b;
  boolean_T c9_g_b;
  boolean_T c9_isDone;
  boolean_T c9_isThetaAntisymmetric;
  boolean_T c9_p;
  c9_st.prev = c9_sp;
  c9_st.tls = c9_sp->tls;
  c9_b_st.prev = &c9_st;
  c9_b_st.tls = c9_st.tls;
  c9_c_st.prev = &c9_b_st;
  c9_c_st.tls = c9_b_st.tls;
  c9_d_st.prev = &c9_c_st;
  c9_d_st.tls = c9_c_st.tls;
  c9_st.site = &c9_gb_emlrtRSI;
  c9_b_st.site = &c9_hb_emlrtRSI;
  c9_validateattributes(chartInstance, &c9_b_st, c9_b_varargin_1);
  c9_maxVal = 0.0;
  for (c9_k = 0; c9_k < 25740; c9_k++) {
    c9_b_k = (real_T)c9_k + 1.0;
    c9_val = c9_b_varargin_1[(int32_T)c9_b_k - 1];
    if (c9_val > c9_maxVal) {
      c9_maxVal = c9_val;
    }
  }

  c9_thresholdDefault = 0.5 * c9_maxVal;
  c9_b_thresholdDefault = c9_thresholdDefault;
  c9_default = c9_b_thresholdDefault;
  c9_b_default = c9_default;
  c9_threshold = c9_b_default;
  c9_b_threshold = c9_threshold;
  c9_b_st.site = &c9_ib_emlrtRSI;
  c9_c_threshold = c9_threshold;
  c9_c_st.site = &c9_mb_emlrtRSI;
  c9_a = c9_c_threshold;
  c9_d_st.site = &c9_lb_emlrtRSI;
  c9_b_a = c9_a;
  c9_c_a = c9_b_a;
  c9_p = true;
  c9_x = c9_c_a;
  c9_b_x = c9_x;
  c9_b = muDoubleScalarIsNaN(c9_b_x);
  c9_b_p = !c9_b;
  if (!c9_b_p) {
    c9_p = false;
  }

  if (c9_p) {
    c9_b_b = true;
  } else {
    c9_b_b = false;
  }

  if (!c9_b_b) {
    c9_y = NULL;
    sf_mex_assign(&c9_y, sf_mex_create("y", c9_b_cv, 10, 0U, 1, 0U, 2, 1, 32),
                  false);
    c9_b_y = NULL;
    sf_mex_assign(&c9_b_y, sf_mex_create("y", c9_b_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c9_c_y = NULL;
    sf_mex_assign(&c9_c_y, sf_mex_create("y", c9_cv2, 10, 0U, 1, 0U, 2, 1, 9),
                  false);
    sf_mex_call(&c9_d_st, &c9_f_emlrtMCI, "error", 0U, 2U, 14, c9_y, 14,
                sf_mex_call(&c9_d_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c9_d_st, NULL, "message", 1U, 2U, 14, c9_b_y, 14, c9_c_y)));
  }

  c9_b_st.site = &c9_jb_emlrtRSI;
  c9_c_st.site = &c9_nb_emlrtRSI;
  c9_b_validateattributes(chartInstance);
  c9_b_st.site = &c9_kb_emlrtRSI;
  c9_c_st.site = &c9_pb_emlrtRSI;
  c9_d_st.site = &c9_lb_emlrtRSI;
  c9_c_p = true;
  c9_c_k = 0;
  c9_exitg1 = false;
  while ((!c9_exitg1) && (c9_c_k < 180)) {
    c9_d_k = (real_T)c9_c_k + 1.0;
    c9_c_x = -90.0 + (real_T)((int32_T)c9_d_k - 1);
    c9_d_x = c9_c_x;
    c9_c_b = muDoubleScalarIsInf(c9_d_x);
    c9_b2 = !c9_c_b;
    c9_e_x = c9_c_x;
    c9_d_b = muDoubleScalarIsNaN(c9_e_x);
    c9_b3 = !c9_d_b;
    c9_e_b = (c9_b2 && c9_b3);
    if (c9_e_b) {
      c9_c_k++;
    } else {
      c9_c_p = false;
      c9_exitg1 = true;
    }
  }

  if (c9_c_p) {
    c9_b1 = true;
  } else {
    c9_b1 = false;
  }

  if (!c9_b1) {
    c9_d_y = NULL;
    sf_mex_assign(&c9_d_y, sf_mex_create("y", c9_cv, 10, 0U, 1, 0U, 2, 1, 32),
                  false);
    c9_e_y = NULL;
    sf_mex_assign(&c9_e_y, sf_mex_create("y", c9_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c9_f_y = NULL;
    sf_mex_assign(&c9_f_y, sf_mex_create("y", c9_cv3, 10, 0U, 1, 0U, 2, 1, 5),
                  false);
    sf_mex_call(&c9_d_st, &c9_d_emlrtMCI, "error", 0U, 2U, 14, c9_d_y, 14,
                sf_mex_call(&c9_d_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c9_d_st, NULL, "message", 1U, 2U, 14, c9_e_y, 14, c9_f_y)));
  }

  c9_ixLead = 1;
  c9_iyLead = 0;
  c9_work = -90.0;
  for (c9_m = 0; c9_m < 179; c9_m++) {
    c9_tmp1 = -90.0 + (real_T)c9_ixLead;
    c9_tmp2 = c9_work;
    c9_work = c9_tmp1;
    c9_tmp1 -= c9_tmp2;
    c9_ixLead++;
    c9_y1[c9_iyLead] = c9_tmp1;
    c9_iyLead++;
  }

  c9_c_st.site = &c9_ob_emlrtRSI;
  c9_b_ixLead = 1;
  c9_b_iyLead = 0;
  c9_b_work = c9_y1[0];
  for (c9_b_m = 0; c9_b_m < 178; c9_b_m++) {
    c9_b_tmp1 = c9_y1[c9_b_ixLead];
    c9_b_tmp2 = c9_b_work;
    c9_b_work = c9_b_tmp1;
    c9_b_tmp1 -= c9_b_tmp2;
    c9_b_ixLead++;
    c9_b_y1[c9_b_iyLead] = c9_b_tmp1;
    c9_b_iyLead++;
  }

  c9_g_y = c9_sumColumnB(chartInstance, c9_b_y1);
  c9_f_x = c9_g_y;
  c9_g_x = c9_f_x;
  c9_h_x = c9_g_x;
  c9_h_y = muDoubleScalarAbs(c9_h_x);
  if (c9_h_y > 1.4901161193847656E-8) {
    c9_i_y = NULL;
    sf_mex_assign(&c9_i_y, sf_mex_create("y", c9_cv4, 10, 0U, 1, 0U, 2, 1, 43),
                  false);
    c9_j_y = NULL;
    sf_mex_assign(&c9_j_y, sf_mex_create("y", c9_cv4, 10, 0U, 1, 0U, 2, 1, 43),
                  false);
    sf_mex_call(&c9_b_st, &c9_j_emlrtMCI, "error", 0U, 2U, 14, c9_i_y, 14,
                sf_mex_call(&c9_b_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c9_b_st, NULL, "message", 1U, 1U, 14, c9_j_y)));
  }

  c9_isDone = false;
  for (c9_i = 0; c9_i < 25740; c9_i++) {
    chartInstance->c9_hnew[c9_i] = c9_b_varargin_1[c9_i];
  }

  c9_peakIdx = 0;
  c9_ex = -90.0;
  for (c9_e_k = 0; c9_e_k < 179; c9_e_k++) {
    if (c9_ex > -90.0 + (real_T)(c9_e_k + 1)) {
      c9_ex = -90.0 + (real_T)(c9_e_k + 1);
    }
  }

  c9_minTheta = c9_ex;
  c9_b_ex = -90.0;
  for (c9_f_k = 0; c9_f_k < 179; c9_f_k++) {
    if (c9_b_ex < -90.0 + (real_T)(c9_f_k + 1)) {
      c9_b_ex = -90.0 + (real_T)(c9_f_k + 1);
    }
  }

  c9_maxTheta = c9_b_ex;
  c9_i_x = c9_maxTheta - c9_minTheta;
  c9_j_x = c9_i_x;
  c9_k_x = c9_j_x;
  c9_k_y = muDoubleScalarAbs(c9_k_x);
  c9_thetaResolution = c9_k_y / 179.0;
  c9_l_x = c9_minTheta + c9_thetaResolution * 5.0;
  c9_m_x = c9_l_x;
  c9_n_x = c9_m_x;
  c9_l_y = muDoubleScalarAbs(c9_n_x);
  c9_isThetaAntisymmetric = (c9_l_y <= c9_maxTheta);
  while (!c9_isDone) {
    for (c9_i1 = 0; c9_i1 < 25740; c9_i1++) {
      chartInstance->c9_varargin_1[c9_i1] = chartInstance->c9_hnew[c9_i1];
    }

    c9_o_x = chartInstance->c9_varargin_1[0];
    c9_p_x = c9_o_x;
    c9_f_b = muDoubleScalarIsNaN(c9_p_x);
    c9_d_p = !c9_f_b;
    if (c9_d_p) {
      c9_idx = 1;
    } else {
      c9_idx = 0;
      c9_g_k = 2;
      c9_exitg1 = false;
      while ((!c9_exitg1) && (c9_g_k < 25741)) {
        c9_q_x = chartInstance->c9_varargin_1[c9_g_k - 1];
        c9_r_x = c9_q_x;
        c9_g_b = muDoubleScalarIsNaN(c9_r_x);
        c9_e_p = !c9_g_b;
        if (c9_e_p) {
          c9_idx = c9_g_k;
          c9_exitg1 = true;
        } else {
          c9_g_k++;
        }
      }
    }

    if (c9_idx == 0) {
      c9_idx = 1;
    } else {
      c9_first = c9_idx;
      c9_c_ex = chartInstance->c9_varargin_1[c9_first - 1];
      c9_b_idx = c9_first;
      c9_i3 = c9_first;
      for (c9_h_k = c9_i3 + 1; c9_h_k < 25741; c9_h_k++) {
        if (c9_c_ex < chartInstance->c9_varargin_1[c9_h_k - 1]) {
          c9_c_ex = chartInstance->c9_varargin_1[c9_h_k - 1];
          c9_b_idx = c9_h_k;
        }
      }

      c9_idx = c9_b_idx;
    }

    c9_c_idx = c9_idx;
    c9_d_idx = c9_c_idx;
    c9_iindx = c9_d_idx;
    c9_e_idx = (real_T)c9_iindx;
    c9_st.site = &c9_fb_emlrtRSI;
    c9_ndx = c9_e_idx;
    c9_b_st.site = &c9_qb_emlrtRSI;
    c9_b_ndx = c9_ndx;
    c9_f_idx = (int32_T)c9_b_ndx - 1;
    c9_v1 = c9_f_idx;
    c9_d_a = c9_v1;
    c9_vk = (int32_T)((uint32_T)(uint16_T)c9_d_a / 143U);
    c9_varargout_4 = c9_vk;
    c9_v1 = (c9_v1 - c9_vk * 143) + 1;
    c9_varargout_3 = c9_v1;
    c9_iPeak = (real_T)c9_varargout_3;
    c9_jPeak = (real_T)(c9_varargout_4 + 1);
    c9_b_iPeak = (int32_T)c9_iPeak;
    c9_b_jPeak = (int32_T)c9_jPeak;
    if ((c9_b_iPeak < 1) || (c9_b_iPeak > 143)) {
      emlrtDynamicBoundsCheckR2012b(c9_b_iPeak, 1, 143, &c9_l_emlrtBCI,
        (emlrtConstCTX)c9_sp);
    }

    if (chartInstance->c9_hnew[(c9_b_iPeak + 143 * (c9_b_jPeak - 1)) - 1] >=
        c9_b_threshold) {
      c9_peakIdx++;
      if ((c9_peakIdx < 1) || (c9_peakIdx > 1)) {
        emlrtDynamicBoundsCheckR2012b(c9_peakIdx, 1, 1, &c9_k_emlrtBCI,
          (emlrtConstCTX)c9_sp);
      }

      c9_peakCoordinates[0] = (real_T)c9_b_iPeak;
      c9_peakCoordinates[1] = (real_T)c9_b_jPeak;
      c9_rhoMin = c9_b_iPeak - 2;
      c9_rhoMax = c9_b_iPeak + 2;
      c9_thetaMin = c9_b_jPeak;
      c9_thetaMax = c9_b_jPeak;
      if (c9_rhoMin < 1) {
        c9_rhoMin = 1;
      }

      if (c9_rhoMax > 143) {
        c9_rhoMax = 143;
      }

      for (c9_theta = c9_thetaMin - 2; c9_theta <= c9_thetaMax + 2; c9_theta++)
      {
        for (c9_rho = c9_rhoMin; c9_rho <= c9_rhoMax; c9_rho++) {
          c9_rhoToRemove = c9_rho;
          c9_thetaToRemove = c9_theta;
          if (c9_isThetaAntisymmetric) {
            if (c9_theta > 180) {
              c9_rhoToRemove = 144 - c9_rho;
              c9_thetaToRemove = c9_theta - 180;
            } else if (c9_theta < 1) {
              c9_rhoToRemove = 144 - c9_rho;
              c9_thetaToRemove = c9_theta + 180;
            }
          }

          if ((c9_thetaToRemove > 180) || (c9_thetaToRemove < 1)) {
          } else {
            chartInstance->c9_hnew[(c9_rhoToRemove + 143 * (c9_thetaToRemove - 1))
              - 1] = 0.0;
          }
        }
      }

      c9_isDone = true;
    } else {
      c9_isDone = true;
    }
  }

  if (c9_peakIdx == 0) {
    memset(&c9_peaks_size[0], 0, sizeof(int32_T) << 1);
  } else {
    c9_peaks_size[0] = 1;
    c9_peaks_size[1] = 2;
    for (c9_i2 = 0; c9_i2 < 2; c9_i2++) {
      c9_peaks_data[c9_peaks_size[0] * c9_i2] = c9_peakCoordinates[c9_i2];
    }
  }
}

static void c9_validateattributes(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c9_sp, real_T c9_a[25740])
{
  static char_T c9_cv2[47] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't',
    'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
    'I', 'n', 't', 'e', 'g', 'e', 'r' };

  static char_T c9_b_cv1[33] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o',
    'u', 'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't',
    'e', 'd', 'I', 'n', 't', 'e', 'g', 'e', 'r' };

  static char_T c9_b_cv[18] = { 'i', 'n', 'p', 'u', 't', ' ', 'n', 'u', 'm', 'b',
    'e', 'r', ' ', '1', ',', ' ', 'H', ',' };

  static char_T c9_cv3[18] = { 'i', 'n', 'p', 'u', 't', ' ', 'n', 'u', 'm', 'b',
    'e', 'r', ' ', '1', ',', ' ', 'H', ',' };

  emlrtStack c9_st;
  const mxArray *c9_b_y = NULL;
  const mxArray *c9_c_y = NULL;
  const mxArray *c9_d_y = NULL;
  const mxArray *c9_e_y = NULL;
  const mxArray *c9_f_y = NULL;
  const mxArray *c9_y = NULL;
  real_T c9_b_k;
  real_T c9_b_x;
  real_T c9_c_x;
  real_T c9_d_k;
  real_T c9_d_x;
  real_T c9_e_x;
  real_T c9_f_x;
  real_T c9_g_x;
  real_T c9_g_y;
  real_T c9_h_x;
  real_T c9_i_x;
  real_T c9_x;
  int32_T c9_c_k;
  int32_T c9_k;
  boolean_T c9_b;
  boolean_T c9_b1;
  boolean_T c9_b2;
  boolean_T c9_b3;
  boolean_T c9_b4;
  boolean_T c9_b5;
  boolean_T c9_b_b;
  boolean_T c9_b_p;
  boolean_T c9_c_b;
  boolean_T c9_c_p;
  boolean_T c9_d_b;
  boolean_T c9_d_p;
  boolean_T c9_e_b;
  boolean_T c9_exitg1;
  boolean_T c9_f_b;
  boolean_T c9_g_b;
  boolean_T c9_p;
  (void)chartInstance;
  c9_st.prev = c9_sp;
  c9_st.tls = c9_sp->tls;
  c9_st.site = &c9_lb_emlrtRSI;
  c9_p = true;
  c9_k = 0;
  c9_exitg1 = false;
  while ((!c9_exitg1) && (c9_k < 25740)) {
    c9_b_k = (real_T)c9_k + 1.0;
    c9_x = c9_a[(int32_T)c9_b_k - 1];
    c9_b_x = c9_x;
    c9_b_b = muDoubleScalarIsInf(c9_b_x);
    c9_b1 = !c9_b_b;
    c9_c_x = c9_x;
    c9_c_b = muDoubleScalarIsNaN(c9_c_x);
    c9_b2 = !c9_c_b;
    c9_d_b = (c9_b1 && c9_b2);
    if (c9_d_b) {
      c9_k++;
    } else {
      c9_p = false;
      c9_exitg1 = true;
    }
  }

  if (c9_p) {
    c9_b = true;
  } else {
    c9_b = false;
  }

  if (!c9_b) {
    c9_y = NULL;
    sf_mex_assign(&c9_y, sf_mex_create("y", c9_cv, 10, 0U, 1, 0U, 2, 1, 32),
                  false);
    c9_b_y = NULL;
    sf_mex_assign(&c9_b_y, sf_mex_create("y", c9_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c9_c_y = NULL;
    sf_mex_assign(&c9_c_y, sf_mex_create("y", c9_b_cv, 10, 0U, 1, 0U, 2, 1, 18),
                  false);
    sf_mex_call(&c9_st, &c9_d_emlrtMCI, "error", 0U, 2U, 14, c9_y, 14,
                sf_mex_call(&c9_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c9_st, NULL, "message", 1U, 2U, 14, c9_b_y, 14, c9_c_y)));
  }

  c9_st.site = &c9_lb_emlrtRSI;
  c9_b_p = true;
  c9_c_k = 0;
  c9_exitg1 = false;
  while ((!c9_exitg1) && (c9_c_k < 25740)) {
    c9_d_k = (real_T)c9_c_k + 1.0;
    c9_d_x = c9_a[(int32_T)c9_d_k - 1];
    c9_e_x = c9_d_x;
    c9_f_x = c9_e_x;
    c9_e_b = muDoubleScalarIsInf(c9_f_x);
    c9_b4 = !c9_e_b;
    c9_g_x = c9_e_x;
    c9_f_b = muDoubleScalarIsNaN(c9_g_x);
    c9_b5 = !c9_f_b;
    c9_g_b = (c9_b4 && c9_b5);
    if (c9_g_b) {
      c9_h_x = c9_d_x;
      c9_i_x = c9_h_x;
      c9_g_y = c9_i_x;
      if (c9_g_y == c9_d_x) {
        c9_c_p = true;
      } else {
        c9_c_p = false;
      }
    } else {
      c9_c_p = false;
    }

    c9_d_p = c9_c_p;
    if (c9_d_p) {
      c9_c_k++;
    } else {
      c9_b_p = false;
      c9_exitg1 = true;
    }
  }

  if (c9_b_p) {
    c9_b3 = true;
  } else {
    c9_b3 = false;
  }

  if (!c9_b3) {
    c9_d_y = NULL;
    sf_mex_assign(&c9_d_y, sf_mex_create("y", c9_b_cv1, 10, 0U, 1, 0U, 2, 1, 33),
                  false);
    c9_e_y = NULL;
    sf_mex_assign(&c9_e_y, sf_mex_create("y", c9_cv2, 10, 0U, 1, 0U, 2, 1, 47),
                  false);
    c9_f_y = NULL;
    sf_mex_assign(&c9_f_y, sf_mex_create("y", c9_cv3, 10, 0U, 1, 0U, 2, 1, 18),
                  false);
    sf_mex_call(&c9_st, &c9_e_emlrtMCI, "error", 0U, 2U, 14, c9_d_y, 14,
                sf_mex_call(&c9_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c9_st, NULL, "message", 1U, 2U, 14, c9_e_y, 14, c9_f_y)));
  }
}

static void c9_b_validateattributes(SFc9_flightControlSystemInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static real_T c9_sumColumnB(SFc9_flightControlSystemInstanceStruct
  *chartInstance, real_T c9_x[178])
{
  real_T c9_y;
  int32_T c9_b_k;
  int32_T c9_k;
  (void)chartInstance;
  c9_y = c9_x[0];
  for (c9_k = 0; c9_k < 177; c9_k++) {
    c9_b_k = c9_k;
    c9_y += c9_x[c9_b_k + 1];
  }

  return c9_y;
}

const mxArray *sf_c9_flightControlSystem_get_eml_resolved_functions_info(void)
{
  const mxArray *c9_nameCaptureInfo = NULL;
  c9_nameCaptureInfo = NULL;
  sf_mex_assign(&c9_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1, 0U, 2, 0, 1), false);
  return c9_nameCaptureInfo;
}

static real_T c9_emlrt_marshallIn(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c9_nullptr, const char_T *c9_identifier)
{
  emlrtMsgIdentifier c9_thisId;
  real_T c9_y;
  c9_thisId.fIdentifier = (const char_T *)c9_identifier;
  c9_thisId.fParent = NULL;
  c9_thisId.bParentIsCell = false;
  c9_y = c9_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c9_nullptr), &c9_thisId);
  sf_mex_destroy(&c9_nullptr);
  return c9_y;
}

static real_T c9_b_emlrt_marshallIn(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c9_u, const emlrtMsgIdentifier *c9_parentId)
{
  real_T c9_d;
  real_T c9_y;
  (void)chartInstance;
  sf_mex_import(c9_parentId, sf_mex_dup(c9_u), &c9_d, 1, 0, 0U, 0, 0U, 0);
  c9_y = c9_d;
  sf_mex_destroy(&c9_u);
  return c9_y;
}

static const mxArray *c9_feval(SFc9_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c9_sp, const mxArray *c9_input0, const
  mxArray *c9_input1)
{
  const mxArray *c9_m = NULL;
  (void)chartInstance;
  c9_m = NULL;
  sf_mex_assign(&c9_m, sf_mex_call(c9_sp, NULL, "feval", 1U, 2U, 14, sf_mex_dup
    (c9_input0), 14, sf_mex_dup(c9_input1)), false);
  sf_mex_destroy(&c9_input0);
  sf_mex_destroy(&c9_input1);
  return c9_m;
}

static void c9_b_feval(SFc9_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c9_sp, const mxArray *c9_input0, const mxArray *c9_input1)
{
  (void)chartInstance;
  sf_mex_call(c9_sp, NULL, "feval", 0U, 2U, 14, sf_mex_dup(c9_input0), 14,
              sf_mex_dup(c9_input1));
  sf_mex_destroy(&c9_input0);
  sf_mex_destroy(&c9_input1);
}

static int32_T c9__s32_s64_(SFc9_flightControlSystemInstanceStruct
  *chartInstance, int64_T c9_b, int32_T c9_EMLOvCount_src_loc, uint32_T
  c9_ssid_src_loc, int32_T c9_offset_src_loc, int32_T c9_length_src_loc)
{
  int32_T c9_a;
  (void)c9_EMLOvCount_src_loc;
  c9_a = (int32_T)c9_b;
  if ((int64_T)c9_a != c9_b) {
    sf_data_overflow_error(chartInstance->S, c9_ssid_src_loc, c9_offset_src_loc,
      c9_length_src_loc);
  }

  return c9_a;
}

static void init_dsm_address_info(SFc9_flightControlSystemInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc9_flightControlSystemInstanceStruct
  *chartInstance)
{
  chartInstance->c9_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c9_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c9_BWImage = (real_T (*)[2400])ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c9_DegAngle = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c9_flightControlSystem_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3214001963U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(196011864U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1289636571U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(178868427U);
}

mxArray *sf_c9_flightControlSystem_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,5);
  mxSetCell(mxcell3p, 0, mxCreateString(
             "images.internal.coder.buildable.IppfilterBuildable"));
  mxSetCell(mxcell3p, 1, mxCreateString(
             "images.internal.coder.buildable.ImfilterBuildable"));
  mxSetCell(mxcell3p, 2, mxCreateString(
             "images.internal.coder.buildable.GetnumcoresBuildable"));
  mxSetCell(mxcell3p, 3, mxCreateString(
             "images.internal.coder.buildable.CannyThresholdingTbbBuildable"));
  mxSetCell(mxcell3p, 4, mxCreateString(
             "images.internal.coder.buildable.IppreconstructBuildable"));
  return(mxcell3p);
}

mxArray *sf_c9_flightControlSystem_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("ippfilter_real64");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c9_flightControlSystem_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c9_flightControlSystem(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiBWYGRgYAPSHEDMxAABrFA+IxKGiLPAxRWAuKSyIBUkXlyU7JkCpPMSc8H8xNI"
    "Kz7y0fLD5FgwI89kImM8JFYeAD/aU6RdxQNfPgkU/B5J+ASjfJTXdMS89J5UPKg4AuUIPUA=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c9_flightControlSystem_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sYvNII9A0TXRAWvHJZxmeXC";
}

static void sf_opaque_initialize_c9_flightControlSystem(void *chartInstanceVar)
{
  initialize_params_c9_flightControlSystem
    ((SFc9_flightControlSystemInstanceStruct*) chartInstanceVar);
  initialize_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c9_flightControlSystem(void *chartInstanceVar)
{
  enable_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c9_flightControlSystem(void *chartInstanceVar)
{
  disable_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c9_flightControlSystem(void *chartInstanceVar)
{
  sf_gateway_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c9_flightControlSystem(SimStruct*
  S)
{
  return get_sim_state_c9_flightControlSystem
    ((SFc9_flightControlSystemInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c9_flightControlSystem(SimStruct* S, const
  mxArray *st)
{
  set_sim_state_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_cleanup_runtime_resources_c9_flightControlSystem(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc9_flightControlSystemInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_flightControlSystem_optimization_info();
    }

    mdl_cleanup_runtime_resources_c9_flightControlSystem
      ((SFc9_flightControlSystemInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c9_flightControlSystem(void *chartInstanceVar)
{
  mdl_start_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
  if (chartInstanceVar) {
    sf_reset_warnings_ChartRunTimeInfo(((SFc9_flightControlSystemInstanceStruct*)
      chartInstanceVar)->S);
  }
}

static void sf_opaque_mdl_terminate_c9_flightControlSystem(void
  *chartInstanceVar)
{
  mdl_terminate_c9_flightControlSystem((SFc9_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c9_flightControlSystem(SimStruct *S)
{
  mdlProcessParamsCommon(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c9_flightControlSystem
      ((SFc9_flightControlSystemInstanceStruct*)sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c9_flightControlSystem_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [20] = {
    "eNrdWEtv20YQXhmukRSpmwJFk0OBBChQ9FLAjVEgAYomih6NCjsWQjlxfQlW5IhceLnL7EOP/qz",
    "+kh7bYy8Feuuxx85SlCzQqs2lgDgpAYoaUt/OzLfzokijd0jw2MXz5A4hO3i9gecWmR8fFHJj5Z",
    "zf3ybfFXL/Q0LChCrTEyNJ/I9QRhCDCOxoxKaeWGHTPlU01TX0CprCC9CSW8Ok8DOeiREoECEuk",
    "EllvPRqllrOxFnXitBp1q8SFiZBIi2PnuKCNDoSfPZfejNr+qixzRSEpgsQmURJGyddTuPLWVBm",
    "0kogPNM29eZKgwls5lzVh5YblnHoTCHsCW0osqCv8Dcw1EDLTL0jhOlggZZpxhkV1blOqA4gw+g",
    "wcJxF+HlkDbJXUS/qGzJBjVSM8k7KWy7CK2L7HO08xLDm3jyb1LRhaOOYidixq2wKAv3HOKnA1a",
    "glx6BoDEfCMwedd51pvsHLuKyegz0XlrVy0KbzXdG1sLnezhgZ0jX1dkPRopxrP+xAZgcwBp7rb",
    "1NDa2Dn+j3AWrNoIF9S5bLAM5OsYG8sFNiWFBGrvsPjEiovuM+xeFaAs9SFFERI89L05UJXxaTV",
    "RqYtTKP2wUFFfRexPWFAjWgIlWufokwDGpzHlafeiGk65A6NLJncy8orgKgNJXpkRXsi1Rly7Ft",
    "kz7lymeCHhiiGNhjIC0YHo/sl5baizanGCufC41hjxfLTi1iXP7XAIQ0TiFw/YRwOQbsFdOX6jH",
    "2kid6OmZm1QYeKZVUzyWqIsJE4lgazDI7FmZAT0VUyDYqJ4JK4AsCqQZXAtvAU25KaddH4alYre",
    "DNwkVVnPEup4XToYuMHENhZnK+uE9IQs6ojcHRDgzbBBuxnbO1CM21wnJp18hyI8nn0bsNvHv2k",
    "kPeXudTTA4U7RbENC5yUmsN82IMBSyG/EVCcKeZicTi9e+Rc782ty/Vu4bdGTRzZEPdsBbe9hp/",
    "PVnC3Czl89HrEWZy4ImyU5MEMeU8v2nGrAt/r7C/jyAXcOc+L61cr+MYavWTlusn+PFnBfVTSs1",
    "3C7RSc/f7g3pdfnMpfPv4rSf5kr//YRP+vnvG8W8ifL+azZQcbXyjyVeLhTikenKx/Gj/v9R419",
    "wYnL5qvxs9+PJ2mcNLK17vvae/i/n08DRa4vF6qsBcV71pOpnb+DuDWf7hi784V699ciSdC/n68",
    "Gf7TJ2X8Or5ulPhychvipog57L5H9eK66tN12lmlfjXeMo68Zdym/vnW5ff993uX1ANS+v3td9i",
    "P8rVuf37X/PqN+PWje4X8/fLduZUwHq2Z3ovHOGCP1j39n8T3P578LeaFjuOv+PPvdL8pKJ/huD",
    "5/HSpu95X732n5SAHV69+JrqMPkTXz37p+f6uU306eMBHJif76mwff7m/S1/4FyJICeA==",
    ""
  };

  static char newstr [1421] = "";
  newstr[0] = '\0';
  for (i = 0; i < 20; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c9_flightControlSystem(SimStruct *S)
{
  const char* newstr = sf_c9_flightControlSystem_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(639578841U));
  ssSetChecksum1(S,(2993642019U));
  ssSetChecksum2(S,(1751705871U));
  ssSetChecksum3(S,(3781126630U));
}

static void mdlRTW_c9_flightControlSystem(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c9_flightControlSystem(SimStruct *S)
{
  SFc9_flightControlSystemInstanceStruct *chartInstance;
  chartInstance = (SFc9_flightControlSystemInstanceStruct *)utMalloc(sizeof
    (SFc9_flightControlSystemInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc9_flightControlSystemInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c9_flightControlSystem;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c9_flightControlSystem;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c9_flightControlSystem;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c9_flightControlSystem;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c9_flightControlSystem;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c9_flightControlSystem;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c9_flightControlSystem;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c9_flightControlSystem;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c9_flightControlSystem;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c9_flightControlSystem;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c9_flightControlSystem;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c9_flightControlSystem;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c9_flightControlSystem(chartInstance);
}

void c9_flightControlSystem_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c9_flightControlSystem(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c9_flightControlSystem(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c9_flightControlSystem(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c9_flightControlSystem_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
